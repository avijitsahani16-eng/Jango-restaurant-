# Jango Restaurant & Bar — website

A premium, fully responsive food-ordering website for **Jango Restaurant Cum Bar**
(NH12, more, Hasadanga, Mayapur, Dhubulia, West Bengal 741140).

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 · Framer Motion ·
GSAP + ScrollTrigger · Lenis · Lucide icons.

> **Start with [`STRUCTURE.md`](./STRUCTURE.md).** It holds the site map, the design
> system and the data shapes that every screen inherits from.

---

## Quick start

```bash
npm install
npm run dev          # http://localhost:3000
```

Production:

```bash
npm run build
npm run start
```

Requires Node.js 20.9 or newer.

## Scripts

| Command              | What it does                                                        |
| -------------------- | ------------------------------------------------------------------- |
| `npm run dev`        | Development server                                                  |
| `npm run build`      | Production build (every page is prerendered)                        |
| `npm run start`      | Serve the production build                                          |
| `npm run lint`       | ESLint (Next.js core-web-vitals + TypeScript rules)                 |
| `npm run typecheck`  | Generate route types, then `tsc --noEmit`                           |
| `npm test`           | Unit and component tests (Vitest + Testing Library)                 |
| `npm run test:e2e`   | End-to-end tests (Playwright, desktop + phone). Run `build` first.  |
| `npm run test:all`   | Lint → typecheck → unit → build → end-to-end                        |
| `npm run images`     | Re-run the image pipeline (`scripts/process_images.py`)             |
| `npm run brand-assets` | Regenerate favicon, app icons and the social share image          |

First-time end-to-end setup: `npx playwright install --with-deps chromium`
(`npm run brand-assets` uses the same browser). `npm run images` needs Python 3
with `pillow`, `numpy` and `scipy`.

## Environment variables

| Variable               | Required          | Purpose                                                                                           |
| ---------------------- | ----------------- | ------------------------------------------------------------------------------------------------- |
| `NEXT_PUBLIC_SITE_URL` | **in production** | Public origin, e.g. `https://www.example.com`. Used for canonical URLs, Open Graph, sitemap, the QR code. |
| `FORM_WEBHOOK_URL`     | recommended       | Every order, reservation, contact message and newsletter sign-up is POSTed here as JSON.           |
| `RATE_LIMIT_MAX`       | no                | Overrides the per-minute API allowance (the end-to-end tests raise it).                            |

Without `FORM_WEBHOOK_URL`, submissions are written to the server log — nothing is
lost, but nobody is notified. Point it at Slack, Zapier, Make, a Google Apps
Script or your own backend. See `src/lib/server/api.ts`.

---

## What is real and what is sample content

**Real — taken from the restaurant's Google Maps listing**

- Name, address (word for word, plus the plus code), phone number (`+91 81675 05450`), opening hours (11 AM – 11 PM, daily)
- Map location and directions links (the embedded map and the pin coordinates are the listing's own)
- Google rating shown on the page (4.7 from 380+ reviews)

Last checked against the listing on 11 November 2026, when it showed 4.7 from 382 reviews.
All of these live in `src/config/site.ts`; update them there if the listing changes.

**Sample — confirm or replace with the owner before going live**

| What                                   | Where                              |
| -------------------------------------- | ---------------------------------- |
| Menu: dishes, prices, ratings, calories | `src/data/dishes.ts`               |
| Cocktail list and prices               | `src/data/content.ts`              |
| Customer testimonials (names and quotes are illustrative) | `src/data/content.ts` |
| FAQ answers, feature and "why choose us" claims | `src/data/content.ts`     |
| Delivery fee, free-delivery threshold, 30-minute promise, coupons | `src/config/site.ts` |
| Social links and app-store links       | `src/config/site.ts`               |
| Privacy policy and terms               | `src/app/privacy`, `src/app/terms` |
| Mobile-app section (no app exists yet) | `src/components/sections/app-promo.tsx` |

**Photography** is AI-generated for this project (no stock, no third-party
images) and is marked as representative in the footer. Swap in real photos of
the restaurant's dishes whenever they are available.

### Before launch

1. Set `NEXT_PUBLIC_SITE_URL` and `FORM_WEBHOOK_URL`.
2. Replace the sample content listed above.
3. Orders are **pay on delivery** (UPI, card or cash). To take payment online,
   create the gateway order at the marked point in `src/app/api/orders/route.ts`.
4. Accounts are **device-local** (favourites, saved details and recent orders
   live in `localStorage`). `src/stores/customer.ts` is the single place to swap
   in a real backend such as Supabase.
5. Structured data deliberately omits `aggregateRating` — see `src/lib/schema.ts`.

---

## Images

Raw generated photographs live outside the repo in `../raw-images` (in the source
download, that is the `raw-images` folder next to this one). The pipeline
(`npm run images`) turns them into:

- **cut-outs** — plates and ingredients shot on white become transparent WebP
  (hero, promo banner, newsletter garnish)
- **photographs** — resized progressive JPEGs (`src/assets/images/dishes`, `gallery`, …)
- **compositions** — original flat-lays assembled from the cut-outs

`next/image` then serves responsive WebP at the right size with blur-up placeholders.

### Photo status

Ten photographs have been generated so far. Everything else falls back to a
designed, photo-less variant until its image is added (no broken or empty slots).

| Area                 | Has photography now                                             | Still to generate                                        |
| -------------------- | --------------------------------------------------------------- | -------------------------------------------------------- |
| Hero + promo artwork | Butter chicken, biryani and pizza cut-outs, six ingredients     | —                                                        |
| Popular dishes       | 6 dishes (butter chicken, biryani, paneer tikka, mutton kosha, two pizzas) | noodles, burger, momos, lava cake → 8 cards   |
| Menu                 | 6 photo cards                                                   | 18 dishes currently shown as menu rows                   |
| Categories           | icon tiles                                                      | 10 category photos                                       |
| Why choose us        | 2 flat-lay compositions                                         | chef and delivery lifestyle shots                        |
| The bar              | typographic cocktail list                                       | 4 cocktail photos, bar interior                          |
| Gallery              | 8 images                                                        | interior, kitchen and guests                             |
| Testimonials         | 1 portrait + initials                                           | 5 portraits                                              |

### Adding a photo

- **Dish:** add the file to `src/assets/images/dishes`, import it in
  `src/data/dishes.ts`, set `image` + `imageAlt`. The dish switches from a menu
  row to a photo card automatically; give it a `popularRank` to feature it on the home page.
- **Category:** set `image` + `imageAlt` in `src/data/categories.ts` and the
  tile becomes a full-bleed photo card.
- **Cocktail:** set `image` + `imageAlt` in `src/data/content.ts`.
- **Testimonial avatar:** set `avatar`; otherwise initials are shown.

---

## Testing

| Layer        | Tool                         | Covers                                                                                                   |
| ------------ | ---------------------------- | -------------------------------------------------------------------------------------------------------- |
| Static       | TypeScript (strict), ESLint  | Types, hooks rules, accessibility lint                                                                    |
| Unit         | Vitest                       | Cart maths and coupons, formatting, opening hours across time zones, validation, search, stores, content integrity, JSON-LD, API route handlers, rate limiting |
| Component    | Testing Library              | Dish card, quantity stepper, FAQ accordion, newsletter form                                               |
| End-to-end   | Playwright (desktop + Pixel 7) | Ordering flow to a confirmed order, pickup, coupons in the cart and at checkout, cart persistence, menu filters, search, quick view, favourites, forms, reservation, gallery lightbox, navigation, 404s |
| Accessibility | axe-core (WCAG 2.2 A + AA)  | Home, menu, category, checkout (including error state), privacy, 404, and every dialog                    |
| Quality      | Playwright                   | No horizontal scroll from 320px to 1920px, 44px touch targets, works without JavaScript, reduced motion, LCP is reported and nothing auto-scrolls on load |
| SEO          | Playwright                   | Titles, canonicals, Open Graph, JSON-LD, robots.txt, sitemap.xml, manifest, security headers              |

```bash
npm run test:all
```

`scripts/screenshot.mjs` saves any page as viewport-sized slices for a visual check:

```bash
node scripts/screenshot.mjs --url http://localhost:3000 --name home --out ./shots
node scripts/screenshot.mjs --url http://localhost:3000 --name home-phone --width 390 --height 844 --mobile --scale 2
```

---

## How it is built

- **Static first.** Every page is prerendered (Cache Components); the four API
  routes are the only server code that runs per request.
- **Server Components by default.** Interactivity lives in small client islands
  (cart button, add-to-cart, forms, carousel). Overlays are separate chunks
  loaded on first use.
- **Animation off the critical path.** GSAP, ScrollTrigger and Lenis load when
  the browser is idle. Phones skip Lenis and ScrollTrigger entirely. Looping
  animations pause when their section is off screen. The headline and hero
  image paint immediately.
- **Accessible.** Skip link, landmarks, one `h1` per page, visible focus rings,
  focus-trapped dialogs that return focus, labelled form errors, reduced-motion
  support, and content that never depends on JavaScript to be visible.
- **Honest colours.** White on `#F97316` fails contrast (2.8:1), so text on the
  brand orange is always charcoal (6.3:1). See `STRUCTURE.md` § 2.

One development-only quirk to expect: in `next dev`, a category address that
does not exist (for example `/menu/nope`) returns the 404 page as it should, but
Next.js also reports errors for it — `InvariantError: Route "/menu/[category]"
did not produce a static shell…` in the terminal (the message describes itself
as a Next.js bug) and `Encountered a script tag while rendering React component`
in the browser overlay. Production builds return a clean 404 with neither, and
an address that matches no route at all is clean in development too.

## Deploying

Any Node host works (`npm run build && npm run start`). On Vercel, import the
repository and set the environment variables — no other configuration is needed.
Static export is not supported because of the API routes.

## Project layout

```
src/
├── app/            routes, layout, metadata files, API routes
├── assets/images/  optimised photography and cut-outs
├── components/     layout · sections · menu · cart · overlays · ui · providers · seo
├── config/site.ts  brand, contact, hours, delivery policy, coupons
├── data/           menu and marketing content
├── hooks/          store, cart, form and scroll hooks
├── lib/            pure logic: cart, hours, validation, search, schema, formatting
├── stores/         cart, customer, ui and toast stores
└── types/          shared data shapes
tests/
├── unit/           Vitest
└── e2e/            Playwright
```
