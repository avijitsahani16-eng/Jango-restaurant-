import AxeBuilder from "@axe-core/playwright";
import { expect, type Page } from "@playwright/test";

/** Navigates and waits until the app is hydrated and the animation engine is running. */
export async function open(page: Page, path = "/") {
  const response = await page.goto(path);
  await page.waitForFunction(() => document.documentElement.classList.contains("reveal-ready"));
  return response;
}

/**
 * Scrolls from top to bottom like a visitor would, so lazy content loads and reveals play.
 * Every step waits for real animation frames, which is what IntersectionObserver needs to notice it.
 */
export async function scrollThrough(page: Page) {
  await page.evaluate(async () => {
    const frames = (count = 3) =>
      new Promise<void>((resolve) => {
        const tick = (left: number) => (left <= 0 ? resolve() : requestAnimationFrame(() => tick(left - 1)));
        tick(count);
      });
    const settle = async () => {
      await frames();
      await new Promise((resolve) => setTimeout(resolve, 60));
    };

    const step = Math.round(window.innerHeight * 0.6);
    for (let y = 0; y < document.documentElement.scrollHeight; y += step) {
      window.scrollTo({ top: y, behavior: "instant" });
      await settle();
      // Swipe through any horizontal rail that is on screen (phones show carousels).
      for (const rail of document.querySelectorAll<HTMLElement>(".overflow-x-auto")) {
        const box = rail.getBoundingClientRect();
        // Only once the rail is comfortably on screen — its cards have to be able to intersect the viewport.
        const onScreen = box.top < window.innerHeight * 0.6 && box.bottom > window.innerHeight * 0.25;
        if (!onScreen || rail.scrollWidth <= rail.clientWidth + 8 || rail.dataset.swiped) continue;
        rail.dataset.swiped = "true";
        for (let x = 0; x <= rail.scrollWidth; x += Math.round(rail.clientWidth * 0.7)) {
          rail.scrollTo({ left: x, behavior: "instant" });
          await settle();
        }
        rail.scrollTo({ left: 0, behavior: "instant" });
        await settle();
      }
    }
    window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "instant" });
    await settle();
  });
  // Every image that started loading has finished, and the last reveal animations are done.
  await page.waitForFunction(() => Array.from(document.images).every((image) => image.complete), undefined, { timeout: 45_000 });
  await page.waitForFunction(() => document.querySelectorAll("[data-reveal]:not([data-revealed='done'])").length === 0, undefined, { timeout: 20_000 });
}

/** Collects console errors and uncaught exceptions (third-party map noise excluded). */
export function trackErrors(page: Page): string[] {
  const errors: string[] = [];
  const thirdParty = /google\.com|gstatic\.com|googleapis\.com/;
  page.on("console", (message) => {
    if (message.type() === "error" && !thirdParty.test(message.location().url) && !thirdParty.test(message.text())) errors.push(message.text());
  });
  page.on("pageerror", (error) => errors.push(error.message));
  return errors;
}

export async function expectNoHorizontalOverflow(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  expect(overflow, "page should not scroll sideways").toBeLessThanOrEqual(0);
}

/** WCAG 2.2 A + AA scan. The embedded Google Map is third-party and excluded. */
export async function expectAccessible(page: Page, context?: string) {
  let builder = new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"]).exclude("iframe");
  if (context) builder = builder.include(context);
  const { violations } = await builder.analyze();
  const summary = violations.map((violation) => ({
    rule: violation.id,
    impact: violation.impact,
    nodes: violation.nodes.slice(0, 4).map((node) => `${node.target.join(" ")} — ${node.failureSummary?.split("\n").slice(1, 2).join(" ").trim()}`),
  }));
  expect(summary, "axe found accessibility violations").toEqual([]);
}

/** Waits until transient notifications are gone (they fade, which confuses contrast checks). */
export async function toastsGone(page: Page) {
  await expect(page.getByRole("region", { name: "Notifications" }).getByRole("status")).toHaveCount(0, { timeout: 8_000 });
}

export const cartButton = (page: Page) => page.getByRole("banner").getByRole("button", { name: /^Open cart/ });

export async function addFirstDish(page: Page, name = "Smoky Butter Chicken") {
  await page.getByRole("button", { name: `Add ${name} to cart` }).first().click();
  await expect(cartButton(page)).toHaveAccessibleName(/1 item/);
}
