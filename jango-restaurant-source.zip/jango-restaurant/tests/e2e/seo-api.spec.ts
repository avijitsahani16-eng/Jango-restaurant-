import { expect, test } from "@playwright/test";

/* These checks talk to the server directly, so they run once (desktop project). */
test.beforeEach(({ isMobile }) => {
  test.skip(isMobile, "server-level checks run once");
});

async function jsonLd(page: import("@playwright/test").Page): Promise<Record<string, unknown>[]> {
  const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
  return blocks.flatMap((block) => {
    const parsed = JSON.parse(block) as Record<string, unknown> | Record<string, unknown>[];
    return Array.isArray(parsed) ? parsed : [parsed];
  });
}

test.describe("SEO", () => {
  test("home page has complete metadata and structured data", async ({ page }) => {
    await page.goto("/");
    await expect(page.locator("html")).toHaveAttribute("lang", "en-IN");

    const description = await page.locator('meta[name="description"]').getAttribute("content");
    expect(description?.length).toBeGreaterThan(80);
    expect(description?.length).toBeLessThan(200);

    await expect(page.locator('link[rel="canonical"]')).toHaveAttribute("href", /^https?:\/\/[^/]+\/?$/);
    await expect(page.locator('meta[property="og:type"]')).toHaveAttribute("content", "website");
    await expect(page.locator('meta[property="og:locale"]')).toHaveAttribute("content", "en_IN");
    await expect(page.locator('meta[property="og:image"]')).toHaveAttribute("content", /^https?:\/\/.+opengraph-image/);
    await expect(page.locator('meta[property="og:image:width"]')).toHaveAttribute("content", "1200");
    await expect(page.locator('meta[name="twitter:card"]')).toHaveAttribute("content", "summary_large_image");
    await expect(page.locator('link[rel="manifest"]')).toHaveAttribute("href", "/manifest.webmanifest");
    await expect(page.locator('link[rel="icon"][type="image/svg+xml"]')).toHaveCount(1);

    const data = await jsonLd(page);
    const types = data.map((entry) => entry["@type"]).flat();
    expect(types).toEqual(expect.arrayContaining(["Restaurant", "WebSite", "FAQPage"]));

    const restaurant = data.find((entry) => Array.isArray(entry["@type"]) && (entry["@type"] as string[]).includes("Restaurant"));
    expect(restaurant).toMatchObject({
      name: "Jango Restaurant Cum Bar",
      telephone: "+918167505450",
      address: { addressLocality: "Dhubulia", postalCode: "741140", addressCountry: "IN" },
    });
    const faq = data.find((entry) => entry["@type"] === "FAQPage") as { mainEntity: unknown[] };
    expect(faq.mainEntity).toHaveLength(8);
  });

  test("the hero image is prioritised and below-the-fold images are lazy", async ({ page }) => {
    await page.goto("/");
    const hero = page.getByRole("img", { name: /signature smoky butter chicken/ });
    await expect(hero).toHaveAttribute("fetchpriority", "high");
    await expect(hero).toHaveAttribute("loading", "eager");
    await expect(page.locator("#gallery img").first()).toHaveAttribute("loading", "lazy");
    await expect(page.locator("#popular img").first()).toHaveAttribute("srcset", /_next\/image.*w=/);
  });

  test("category pages have their own title, canonical and menu markup", async ({ page }) => {
    await page.goto("/menu/pizza");
    await expect(page).toHaveTitle("Pizza — Order Online | Jango Restaurant & Bar");
    await expect(page.locator('link[rel="canonical"]')).toHaveAttribute("href", /\/menu\/pizza$/);

    const data = await jsonLd(page);
    const menu = data.find((entry) => entry["@type"] === "Menu") as { hasMenuSection: { name: string; hasMenuItem: unknown[] }[] };
    expect(menu.hasMenuSection).toHaveLength(1);
    expect(menu.hasMenuSection[0]).toMatchObject({ name: "Pizza" });
    expect(menu.hasMenuSection[0].hasMenuItem).toHaveLength(2);
    expect(data.some((entry) => entry["@type"] === "BreadcrumbList")).toBe(true);
  });

  test("checkout is kept out of search results", async ({ page }) => {
    await page.goto("/checkout");
    await expect(page.locator('meta[name="robots"]')).toHaveAttribute("content", /noindex/);
  });

  test("robots.txt, sitemap.xml and the web manifest are served", async ({ request }) => {
    const robots = await request.get("/robots.txt");
    expect(robots.ok()).toBe(true);
    const robotsText = await robots.text();
    expect(robotsText).toContain("Disallow: /api/");
    expect(robotsText).toMatch(/Sitemap: https?:\/\/.+\/sitemap\.xml/);

    const sitemap = await request.get("/sitemap.xml");
    expect(sitemap.headers()["content-type"]).toContain("xml");
    const xml = await sitemap.text();
    expect(xml.match(/<loc>/g)).toHaveLength(14);
    expect(xml).toContain("/menu/pizza</loc>");
    expect(xml).not.toContain("/checkout");

    const manifest = await (await request.get("/manifest.webmanifest")).json();
    expect(manifest).toMatchObject({ short_name: "Jango", display: "standalone", theme_color: "#F97316" });
    for (const icon of manifest.icons) expect((await request.get(icon.src)).ok(), icon.src).toBe(true);
  });

  test("responses carry security headers and pages are served pre-rendered", async ({ request }) => {
    const response = await request.get("/");
    const headers = response.headers();
    expect(headers["x-content-type-options"]).toBe("nosniff");
    expect(headers["referrer-policy"]).toBe("strict-origin-when-cross-origin");
    expect(headers["x-powered-by"]).toBeUndefined();

    const html = await response.text();
    expect(html).toContain("Fresh off the");
    expect(html).toContain("Smoky Butter Chicken"); // dishes are in the HTML, not fetched later
    expect(html).toContain("Do you deliver alcohol?"); // FAQ answers are crawlable
  });
});

test.describe("API", () => {
  const customer = { name: "Api Tester", phone: "9876543210", address: "12 Station Road, Dhubulia" };

  test("orders are priced on the server", async ({ request }) => {
    const response = await request.post("/api/orders", {
      data: {
        lines: [{ dishId: "tandoori-chicken-pizza", quantity: 2, price: 1 }],
        couponCode: "TREAT50",
        fulfilment: "delivery",
        payment: "card",
        customer,
      },
    });
    expect(response.status()).toBe(201);
    const { data } = await response.json();
    // 2 × 349 = 698 − 50 = 648; GST 32.4 → 32; free delivery over ₹499
    expect(data.order.totals).toEqual({ itemCount: 2, subtotal: 698, discount: 50, deliveryFee: 0, tax: 32, total: 680 });
    expect(data.order.id).toMatch(/^JG-/);
  });

  test("invalid submissions are rejected with field errors", async ({ request }) => {
    const order = await request.post("/api/orders", { data: { lines: [], fulfilment: "delivery", payment: "upi", customer: {} } });
    expect(order.status()).toBe(422);
    expect((await order.json()).errors).toMatchObject({ lines: "Your cart is empty." });

    const contact = await request.post("/api/contact", { data: { name: "", phone: "", topic: "", message: "" } });
    expect(contact.status()).toBe(422);

    const reservation = await request.post("/api/reservations", {
      data: { name: "A B", phone: "9876543210", date: "2020-01-01", time: "20:00", guests: 2, occasion: "Birthday" },
    });
    expect(reservation.status()).toBe(422);
    expect((await reservation.json()).errors.date).toBe("That date has already passed.");
  });

  test("only POST with JSON is accepted", async ({ request }) => {
    expect((await request.get("/api/orders")).status()).toBe(405);
    const text = await request.post("/api/newsletter", { headers: { "content-type": "text/plain" }, data: "email=a@b.co" });
    expect(text.status()).toBe(400);
    const ok = await request.post("/api/newsletter", { data: { email: "guest@example.com" } });
    expect(ok.status()).toBe(200);
    expect(ok.headers()["cache-control"]).toContain("no-store");
  });
});
