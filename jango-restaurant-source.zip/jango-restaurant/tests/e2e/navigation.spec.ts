import { expect, test } from "@playwright/test";

import { open } from "./helpers";

test.describe("navigation", () => {
  test("desktop: the categories menu opens and leads to a category page", async ({ page, isMobile }) => {
    test.skip(isMobile, "desktop navigation");
    await open(page);

    const trigger = page.getByRole("button", { name: "Categories" });
    await expect(trigger).toHaveAttribute("aria-expanded", "false");
    await trigger.click();
    await expect(trigger).toHaveAttribute("aria-expanded", "true");

    const nav = page.getByRole("navigation", { name: "Primary" });
    await expect(nav.getByRole("link", { name: /Sushi/ })).toBeVisible();

    await page.keyboard.press("Escape");
    await expect(trigger).toHaveAttribute("aria-expanded", "false");
    await expect(trigger).toBeFocused();

    await trigger.click();
    await nav.getByRole("link", { name: /Pizza/ }).click();
    await expect(page).toHaveURL(/\/menu\/pizza$/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Pizza menu");
    await expect(page.getByRole("navigation", { name: "Breadcrumb" }).getByText("Pizza")).toHaveAttribute("aria-current", "page");
  });

  test("desktop: section links glide on the home page and navigate from elsewhere", async ({ page, isMobile }) => {
    test.skip(isMobile, "desktop navigation");
    await open(page);
    const nav = page.getByRole("navigation", { name: "Primary" });

    await nav.getByRole("link", { name: "Offers" }).click();
    await expect(page).toHaveURL(/#offers$/);
    await expect(page.locator("#offers")).toBeInViewport();

    await open(page, "/menu");
    await nav.getByRole("link", { name: "Contact" }).click();
    await expect(page).toHaveURL(/\/#contact$/);
    await expect(page.locator("#contact-title")).toBeInViewport();
  });

  test("mobile: the hamburger opens a full menu that navigates and closes", async ({ page, isMobile }) => {
    test.skip(!isMobile, "mobile navigation");
    await open(page);

    await expect(page.getByRole("navigation", { name: "Primary" })).toBeHidden();
    await page.getByRole("button", { name: "Open menu" }).click();
    const menu = page.getByRole("dialog", { name: "Site menu" });
    await expect(menu).toBeVisible();
    await expect(menu.getByRole("link", { name: "Order online" })).toBeVisible();

    await menu.getByRole("link", { name: /^Menu/ }).click();
    await expect(page).toHaveURL(/\/menu$/);
    await expect(menu).toBeHidden();

    await page.getByRole("button", { name: "Open menu" }).click();
    await page.getByRole("dialog", { name: "Site menu" }).getByRole("link", { name: /Desserts/ }).click();
    await expect(page).toHaveURL(/\/menu\/desserts$/);
  });

  test("mobile: a sticky order bar follows the visitor", async ({ page, isMobile }) => {
    test.skip(!isMobile, "mobile only");
    await open(page);
    const bar = page.getByRole("link", { name: "Order now" }).last();
    await page.evaluate(() => window.scrollTo({ top: 1400, behavior: "instant" }));
    await expect(bar).toBeInViewport();

    const popular = page.locator("#popular");
    await popular.scrollIntoViewIfNeeded();
    await popular.getByRole("button", { name: "Add Smoky Butter Chicken to cart" }).click();
    const summary = page.getByRole("button", { name: /1 item.*View cart/ });
    await expect(summary).toBeInViewport();
    await summary.click();
    await expect(page.getByRole("dialog", { name: "Your cart" })).toBeVisible();
  });

  test("keyboard users can skip straight to the content", async ({ page, isMobile }) => {
    test.skip(isMobile, "keyboard navigation");
    await open(page);
    await page.keyboard.press("Tab");
    const skip = page.getByRole("link", { name: "Skip to main content" });
    await expect(skip).toBeFocused();
    await expect(skip).toBeInViewport();
    await page.keyboard.press("Enter");
    await expect(page.locator("#main")).toBeFocused();
  });

  test("unknown pages get a helpful 404", async ({ page }) => {
    const response = await page.goto("/this-page-does-not-exist");
    expect(response?.status()).toBe(404);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("This plate is empty.");
    await page.getByRole("link", { name: "Browse the menu" }).click();
    await expect(page).toHaveURL(/\/menu$/);
  });

  test("unknown categories are a real 404", async ({ page }) => {
    const response = await page.goto("/menu/soup-of-the-day");
    expect(response?.status()).toBe(404);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("This plate is empty.");
  });
});
