import { expect, test } from "@playwright/test";

import { cartButton, open } from "./helpers";

const dishes = (page: import("@playwright/test").Page) => page.getByRole("main").getByRole("article");

test.describe("menu", () => {
  test("lists the whole menu, grouped by category", async ({ page }) => {
    await open(page, "/menu");
    await expect(dishes(page)).toHaveCount(24);
    await expect(page.getByRole("status").filter({ hasText: "Showing 24 dishes" })).toBeVisible();
    for (const name of ["Indian", "Chinese", "Asian", "Pizza", "Burgers", "Pasta", "Sushi", "Desserts", "Drinks", "Healthy Meals"]) {
      await expect(page.getByRole("heading", { level: 2, name, exact: true })).toBeVisible();
    }
  });

  test("category chips are real links with their own URL", async ({ page }) => {
    await open(page, "/menu");
    const chips = page.getByRole("navigation", { name: "Menu categories" });
    await chips.getByRole("link", { name: /Pizza/ }).click();

    await expect(page).toHaveURL(/\/menu\/pizza$/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Pizza menu");
    await expect(chips.getByRole("link", { name: /Pizza/ })).toHaveAttribute("aria-current", "page");
    await expect(dishes(page)).toHaveCount(2);
    await expect(page).toHaveTitle(/Pizza — Order Online/);

    await chips.getByRole("link", { name: /^All/ }).click();
    await expect(page).toHaveURL(/\/menu$/);
    await expect(dishes(page)).toHaveCount(24);
  });

  test("search, veg-only and sorting narrow the list", async ({ page }) => {
    await open(page, "/menu");
    const search = page.getByRole("searchbox", { name: "Search the menu" });

    await search.fill("biryani");
    await expect(dishes(page)).toHaveCount(1);
    await expect(page.getByRole("status").filter({ hasText: "1 dish found" })).toBeVisible();
    await expect(dishes(page).first()).toContainText("Kolkata-Style Chicken Biryani");

    await search.fill("zzzz");
    await expect(page.getByRole("heading", { name: "Nothing matches that — yet" })).toBeVisible();
    await page.getByRole("main").getByRole("button", { name: "Clear filters" }).first().click();
    await expect(dishes(page)).toHaveCount(24);

    const veg = page.getByRole("switch", { name: /Veg only/ });
    await veg.click();
    await expect(veg).toHaveAttribute("aria-checked", "true");
    await expect(dishes(page)).toHaveCount(13);
    await expect(page.getByRole("main").getByRole("img", { name: "Non-vegetarian" })).toHaveCount(0);
    await veg.click();

    await open(page, "/menu/indian");
    await page.getByLabel("Sort dishes").selectOption("price-asc");
    await expect(dishes(page).first()).toContainText("Tandoori Paneer Tikka"); // ₹249, the cheapest Indian dish
    await page.getByLabel("Sort dishes").selectOption("price-desc");
    await expect(dishes(page).first()).toContainText("Slow-Cooked Mutton Kosha"); // ₹389
  });

  test("quick view shows the details, adds to the cart and returns focus", async ({ page }) => {
    await open(page, "/menu/indian");
    const title = page.getByRole("button", { name: "Smoky Butter Chicken", exact: true });
    await title.click();

    const dialog = page.getByRole("dialog", { name: "Smoky Butter Chicken" });
    await expect(dialog).toBeVisible();
    await expect(dialog.getByText(/marinated overnight/)).toBeVisible();
    await expect(dialog.getByText("540 kcal")).toBeVisible();

    await page.keyboard.press("Escape");
    await expect(dialog).toBeHidden();
    await expect(title).toBeFocused();

    await title.click();
    await dialog.getByRole("button", { name: "Increase quantity of Smoky Butter Chicken" }).click();
    await expect(dialog.getByRole("button", { name: /Add to cart/ })).toContainText("₹658");
    await dialog.getByRole("button", { name: /Add to cart/ }).click();
    await expect(dialog).toBeHidden();
    await expect(cartButton(page)).toHaveAccessibleName(/2 items/);
  });

  test("dishes without a photo are fully orderable menu rows", async ({ page }) => {
    await open(page, "/menu/chinese");
    await expect(dishes(page)).toHaveCount(3);
    await page.getByRole("button", { name: "Add Chicken Hakka Noodles to cart" }).click();
    await expect(cartButton(page)).toHaveAccessibleName(/1 item/);

    await page.getByRole("button", { name: "Dry Chilli Chicken", exact: true }).click();
    const dialog = page.getByRole("dialog", { name: "Dry Chilli Chicken" });
    await expect(dialog.getByText("Hot", { exact: true })).toBeVisible();
    await expect(dialog.getByText("Non-vegetarian")).toBeVisible();
  });

  test("favourites are remembered and listed in the account", async ({ page, isMobile }) => {
    await open(page, "/menu/pizza");
    await page.getByRole("button", { name: "Save Classic Margherita to favourites" }).click();
    await expect(page.getByRole("button", { name: "Remove Classic Margherita from favourites" })).toHaveAttribute("aria-pressed", "true");

    await page.reload();
    await expect(page.getByRole("button", { name: "Remove Classic Margherita from favourites" })).toBeVisible();

    if (isMobile) {
      await page.getByRole("button", { name: "Open menu" }).click();
      await page.getByRole("dialog", { name: "Site menu" }).getByRole("button", { name: "Favourites" }).click();
    } else {
      await page.getByRole("button", { name: "Your account" }).click();
    }
    const account = page.getByRole("dialog", { name: "Your account" });
    await expect(account.getByRole("tab", { name: /Favourites \(1\)/ })).toHaveAttribute("aria-selected", "true");
    await expect(account.getByText("Classic Margherita")).toBeVisible();
  });
});

test.describe("search", () => {
  test("finds dishes from anywhere and opens them", async ({ page, isMobile }) => {
    await open(page);

    if (isMobile) await page.getByRole("button", { name: "Search the menu" }).first().click();
    else await page.keyboard.press("/");

    const dialog = page.getByRole("dialog", { name: "Search the menu" });
    const input = dialog.getByRole("combobox", { name: "Search dishes" });
    await expect(input).toBeFocused();

    await input.fill("momos");
    const option = dialog.getByRole("option", { name: /Steamed Chicken Momos/ });
    await expect(option).toHaveAttribute("aria-selected", "true");

    await input.fill("chicken");
    await expect(dialog.getByRole("option")).not.toHaveCount(0);
    await page.keyboard.press("ArrowDown");
    await expect(dialog.getByRole("option").nth(1)).toHaveAttribute("aria-selected", "true");
    await page.keyboard.press("ArrowUp");
    await page.keyboard.press("Enter");

    await expect(dialog).toBeHidden();
    await expect(page.getByRole("dialog").getByRole("heading", { level: 2 })).toContainText("Chicken");
  });

  test("says so when nothing matches and offers the categories", async ({ page }) => {
    await open(page, "/menu");
    await page.getByRole("button", { name: "Search the menu" }).first().click();
    const dialog = page.getByRole("dialog", { name: "Search the menu" });
    await dialog.getByRole("combobox").fill("unobtainium");
    await expect(dialog.getByText("No dishes match “unobtainium”")).toBeVisible();

    await dialog.getByRole("link", { name: "Desserts" }).click();
    await expect(page).toHaveURL(/\/menu\/desserts$/);
    await expect(dialog).toBeHidden();
  });

  test("desktop: Ctrl+K opens search and Escape closes it", async ({ page, isMobile }) => {
    test.skip(isMobile, "keyboard shortcut");
    await open(page);
    await page.keyboard.press("Control+k");
    const dialog = page.getByRole("dialog", { name: "Search the menu" });
    await expect(dialog).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(dialog).toBeHidden();
  });
});
