import { expect, test } from "@playwright/test";

import { addFirstDish, cartButton, open } from "./helpers";

test.describe("ordering", () => {
  test("a visitor can go from the menu to a confirmed order", async ({ page }) => {
    await open(page, "/menu/indian");

    // Add from a card; the button becomes a stepper and the header badge updates.
    await addFirstDish(page);
    await expect(page.getByRole("status").filter({ hasText: "Added to your cart" })).toBeVisible();
    await page.getByRole("button", { name: "Increase quantity of Smoky Butter Chicken" }).first().click();
    await expect(cartButton(page)).toHaveAccessibleName(/2 items/);

    // Cart drawer
    await cartButton(page).click();
    const drawer = page.getByRole("dialog", { name: "Your cart" });
    await expect(drawer).toBeVisible();
    await expect(drawer.getByText("2 items · ₹658")).toBeVisible();
    await expect(drawer.getByText("You’ve unlocked free delivery.")).toBeVisible();

    // Coupon
    await drawer.getByLabel("Have a coupon?").fill("jango20");
    await drawer.getByRole("button", { name: "Apply" }).click();
    await expect(drawer.getByText("JANGO20 applied — you save ₹132")).toBeVisible();
    await expect(drawer.getByRole("link", { name: /Go to checkout/ })).toContainText("₹552");

    // Checkout
    await drawer.getByRole("link", { name: /Go to checkout/ }).click();
    await expect(page).toHaveURL(/\/checkout$/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Checkout");
    const summary = page.getByRole("complementary", { name: "Order summary" });
    await expect(summary.locator("dd").filter({ hasText: "₹132" })).toBeVisible();
    await expect(summary.getByText("₹552").first()).toBeVisible();

    // Validation first
    const placeOrder = page.getByRole("button", { name: /Place order/ });
    await placeOrder.click();
    await expect(page.getByText("Please tell us your name.")).toBeVisible();
    await expect(page.getByText("We need a phone number to reach you.")).toBeVisible();
    await expect(page.getByText("Where should we deliver?")).toBeVisible();
    await expect(page.getByLabel("Full name")).toBeFocused();

    // Then a real order
    await page.getByLabel("Full name").fill("Test Customer");
    await page.getByLabel("Mobile number").fill("98765 43210");
    await page.getByLabel("Delivery address").fill("12 Station Road, near the bus stand, Dhubulia");
    await page.getByLabel("Notes for the kitchen").fill("Less spicy please");
    await page.locator("label").filter({ hasText: "Pay the rider in cash" }).click();
    await placeOrder.click();

    await expect(page.getByRole("heading", { name: "Thank you, Test! Your order is in." })).toBeVisible();
    await expect(page.getByText(/^Order JG-[2-9A-Z]{6}$/)).toBeVisible();
    await expect(page.getByRole("list", { name: "Order progress" }).getByRole("listitem")).toHaveCount(4);
    await expect(page.getByText("Cash on arrival · ₹552")).toBeVisible();
    await expect(page.getByText("12 Station Road, near the bus stand, Dhubulia")).toBeVisible();

    // The cart is emptied, the order is remembered.
    await expect(cartButton(page)).toHaveAccessibleName("Open cart, empty");
    const orders = await page.evaluate(() => JSON.parse(localStorage.getItem("jango.orders.v1") ?? "[]"));
    expect(orders).toHaveLength(1);
    expect(orders[0].totals.total).toBe(552);
  });

  test("pickup removes the delivery fee and the address", async ({ page }) => {
    await open(page, "/menu/asian");
    await addFirstDish(page, "Steamed Chicken Momos");
    await page.goto("/checkout");

    const summary = page.getByRole("complementary", { name: "Order summary" });
    await expect(summary.getByText("₹195").first()).toBeVisible(); // 149 + GST 7 + delivery 39
    await expect(page.getByLabel("Delivery address")).toBeVisible();

    await page.locator("label").filter({ hasText: "always free" }).click();
    await expect(page.getByLabel("Delivery address")).toBeHidden();
    await expect(summary.getByText("₹156").first()).toBeVisible();
    await expect(summary.getByText("Free", { exact: true })).toBeVisible();
  });

  test("a coupon can be applied on the checkout page without leaving it", async ({ page }) => {
    await open(page, "/menu/indian");
    await addFirstDish(page);
    await page.getByRole("button", { name: "Increase quantity of Smoky Butter Chicken" }).first().click();
    await expect(cartButton(page)).toHaveAccessibleName(/2 items/);
    await page.goto("/checkout");

    const summary = page.getByRole("complementary", { name: "Order summary" });
    await expect(summary.getByText("₹691").first()).toBeVisible(); // 658 + GST 33, delivery is free
    // A form inside a form is invalid: the browser swallows the inner submit and reloads the page.
    await expect(page.locator("form form")).toHaveCount(0);

    await page.getByLabel("Full name").fill("Test Customer");

    // With the button…
    await summary.getByLabel("Have a coupon?").fill("jango20");
    await summary.getByRole("button", { name: "Apply" }).click();
    await expect(summary.getByText("JANGO20 applied — you save ₹132")).toBeVisible();
    await expect(summary.getByText("₹552").first()).toBeVisible();

    // …and with the Enter key.
    await summary.getByRole("button", { name: "Remove coupon JANGO20" }).click();
    await summary.getByLabel("Have a coupon?").fill("JANGO20");
    await summary.getByLabel("Have a coupon?").press("Enter");
    await expect(summary.getByText("JANGO20 applied — you save ₹132")).toBeVisible();

    // Applying a code is not placing the order: same page, nothing typed is lost, nothing is validated.
    await expect(page).toHaveURL(/\/checkout$/);
    await expect(page.getByLabel("Full name")).toHaveValue("Test Customer");
    await expect(page.getByText("We need a phone number to reach you.")).toBeHidden();

    // The discount is part of the order that gets placed.
    await page.getByLabel("Mobile number").fill("9876543210");
    await page.getByLabel("Delivery address").fill("12 Station Road, near the bus stand, Dhubulia");
    await page.getByRole("button", { name: /Place order/ }).click();
    await expect(page.getByRole("heading", { name: /Thank you, Test!/ })).toBeVisible();
    await expect(page.getByText("UPI on arrival · ₹552")).toBeVisible();
  });

  test("the cart survives a reload and can be edited in the drawer", async ({ page }) => {
    await open(page, "/menu/indian");
    await addFirstDish(page);
    await page.reload();
    await expect(cartButton(page)).toHaveAccessibleName(/1 item/);

    await cartButton(page).click();
    const drawer = page.getByRole("dialog", { name: "Your cart" });
    await drawer.getByRole("button", { name: "Increase quantity of Smoky Butter Chicken" }).click();
    await expect(drawer.getByText("2 items · ₹658")).toBeVisible();

    // A coupon that does not qualify explains why.
    await drawer.getByRole("button", { name: "Decrease quantity of Smoky Butter Chicken" }).click();
    await drawer.getByLabel("Have a coupon?").fill("JANGO20");
    await drawer.getByRole("button", { name: "Apply" }).click();
    await expect(drawer.getByText("Add ₹70 more to use JANGO20.")).toBeVisible();

    await drawer.getByRole("button", { name: "Remove Smoky Butter Chicken from cart" }).first().click();
    await expect(drawer.getByRole("heading", { name: "Your cart is hungry" })).toBeVisible();

    await page.keyboard.press("Escape");
    await expect(drawer).toBeHidden();
    await expect(cartButton(page)).toBeFocused();
  });

  test("checkout with an empty cart points back to the menu", async ({ page }) => {
    await page.goto("/checkout");
    await expect(page.getByRole("heading", { name: "Your cart is empty" })).toBeVisible();
    await page.getByRole("main").getByRole("link", { name: "Browse the menu" }).click();
    await expect(page).toHaveURL(/\/menu$/);
  });

  test("placed orders show up under the account, ready to reorder", async ({ page, isMobile }) => {
    await open(page, "/menu/asian");
    await addFirstDish(page, "Steamed Chicken Momos");
    await page.goto("/checkout");
    await page.locator("label").filter({ hasText: "always free" }).click();
    await page.getByLabel("Full name").fill("Riya Sen");
    await page.getByLabel("Mobile number").fill("9876543210");
    await page.getByRole("button", { name: /Place order/ }).click();
    await expect(page.getByRole("heading", { name: /Thank you, Riya!/ })).toBeVisible();

    if (isMobile) {
      await page.getByRole("button", { name: "Open menu" }).click();
      await page.getByRole("dialog", { name: "Site menu" }).getByRole("button", { name: "Your account" }).click();
    } else {
      await page.getByRole("button", { name: "Your account" }).click();
    }
    const account = page.getByRole("dialog", { name: "Hi, Riya" });
    await expect(account).toBeVisible();
    await account.getByRole("tab", { name: /Orders/ }).click();
    await expect(account.getByText(/Order JG-/)).toBeVisible();
    await expect(account.getByText("1 × Steamed Chicken Momos")).toBeVisible();

    await account.getByRole("button", { name: "Reorder" }).click();
    await expect(page.getByRole("dialog", { name: "Your cart" })).toBeVisible();
    await expect(page.getByRole("dialog", { name: "Your cart" }).getByText("1 item · ₹149")).toBeVisible();
  });
});
