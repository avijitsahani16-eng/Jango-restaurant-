import { expect, test } from "@playwright/test";

import { addFirstDish, cartButton, expectAccessible, expectNoHorizontalOverflow, open, scrollThrough, toastsGone } from "./helpers";

/* ── Accessibility (axe-core, WCAG 2.2 A + AA) ───────────────────────────── */
test.describe("accessibility", () => {
  test("home page has no detectable WCAG violations", async ({ page }) => {
    await open(page);
    await scrollThrough(page);
    await expectAccessible(page);
  });

  for (const path of ["/menu", "/menu/pizza", "/checkout", "/privacy", "/this-page-does-not-exist"]) {
    test(`${path} has no detectable WCAG violations`, async ({ page }) => {
      await page.goto(path);
      await page.waitForFunction(() => document.documentElement.classList.contains("reveal-ready"));
      await scrollThrough(page);
      await expectAccessible(page);
    });
  }

  test("checkout form and cart drawer are accessible with items in the cart", async ({ page }) => {
    await open(page, "/menu/indian");
    await addFirstDish(page);
    await toastsGone(page);
    await cartButton(page).click();
    await expect(page.getByRole("dialog", { name: "Your cart" })).toBeVisible();
    await page.waitForTimeout(600);
    await expectAccessible(page, "[role='dialog']");

    await page.getByRole("link", { name: /Go to checkout/ }).click();
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Checkout");
    await page.getByRole("button", { name: /Place order/ }).click(); // show the error state too
    await expect(page.getByText("Please tell us your name.")).toBeVisible();
    await expectAccessible(page);
  });

  test("dialogs are accessible: search, quick view, reservation, account", async ({ page, isMobile }) => {
    await open(page, "/menu/indian");

    await page.getByRole("button", { name: "Search the menu" }).first().click();
    await expect(page.getByRole("dialog", { name: "Search the menu" })).toBeVisible();
    await page.waitForTimeout(600);
    await expectAccessible(page, "[role='dialog']");
    await page.keyboard.press("Escape");

    await page.getByRole("button", { name: "Smoky Butter Chicken", exact: true }).click();
    await expect(page.getByRole("dialog", { name: "Smoky Butter Chicken" })).toBeVisible();
    await page.waitForTimeout(600);
    await expectAccessible(page, "[role='dialog']");
    await page.keyboard.press("Escape");

    if (isMobile) {
      await page.getByRole("button", { name: "Open menu" }).click();
      await expect(page.getByRole("dialog", { name: "Site menu" })).toBeVisible();
      await page.waitForTimeout(900);
      await expectAccessible(page, "[role='dialog']");
      await page.getByRole("dialog", { name: "Site menu" }).getByRole("button", { name: "Book a table" }).click();
    } else {
      await page.getByRole("button", { name: "Your account" }).click();
      await expect(page.getByRole("dialog", { name: "Your account" })).toBeVisible();
      await page.waitForTimeout(600);
      await expectAccessible(page, "[role='dialog']");
      await page.keyboard.press("Escape");
      await page.getByRole("contentinfo").getByRole("button", { name: "Table reservations" }).click();
    }
    await expect(page.getByRole("dialog", { name: "Reserve a table" })).toBeVisible();
    await page.waitForTimeout(600);
    await expectAccessible(page, "[role='dialog']");
  });

  test("respects reduced motion: content is visible immediately, no smooth scrolling", async ({ browser }) => {
    const context = await browser.newContext({ reducedMotion: "reduce" });
    const page = await context.newPage();
    await page.goto("/");
    await page.waitForFunction(() => document.documentElement.classList.contains("reveal-ready"));
    const hidden = await page.evaluate(
      () => Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]")).filter((element) => getComputedStyle(element).opacity !== "1").length,
    );
    expect(hidden).toBe(0);
    await context.close();
  });

  test("works without JavaScript: content is readable, nothing stays hidden", async ({ browser }) => {
    const context = await browser.newContext({ javaScriptEnabled: false });
    const page = await context.newPage();
    await page.goto("/");
    await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    await expect(page.getByRole("heading", { name: "The ones everybody orders twice." })).toBeVisible();
    const hidden = await page.evaluate(
      () => Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]")).filter((element) => getComputedStyle(element).opacity !== "1").length,
    );
    expect(hidden).toBe(0);
    await page.goto("/menu");
    await expect(page.getByRole("main").getByRole("article")).toHaveCount(24);
    await context.close();
  });
});

/* ── Loading behaviour ───────────────────────────────────────────────────── */
test.describe("loading", () => {
  for (const path of ["/", "/menu"]) {
    test(`${path} paints its main content at once and nothing scrolls by itself`, async ({ page }) => {
      await page.addInitScript(() => {
        const state = { lcp: [] as { time: number; tag: string }[], scrolls: 0 };
        (window as unknown as { __load: typeof state }).__load = state;
        new PerformanceObserver((list) => {
          for (const entry of list.getEntries() as (PerformanceEntry & { element?: Element })[]) {
            state.lcp.push({ time: Math.round(entry.startTime), tag: entry.element?.tagName ?? "?" });
          }
        }).observe({ type: "largest-contentful-paint", buffered: true });
        document.addEventListener("scroll", () => (state.scrolls += 1), true);
      });
      await page.goto(path, { waitUntil: "load" });
      await page.waitForTimeout(1500);

      const { lcp, scrolls } = await page.evaluate(() => (window as unknown as { __load: { lcp: { time: number; tag: string }[]; scrolls: number } }).__load);
      // A carousel that snaps on load would scroll here — and Chrome stops measuring LCP when anything scrolls.
      expect(scrolls, "nothing should scroll on its own during load").toBe(0);
      expect(lcp.length, "Largest Contentful Paint should be reported").toBeGreaterThan(0);
      expect(["P", "H1", "IMG"]).toContain(lcp.at(-1)?.tag);
      expect(lcp.at(-1)?.time).toBeLessThan(2500);
    });
  }
});

/* ── Responsive layout ───────────────────────────────────────────────────── */
test.describe("responsive layout", () => {
  const widths = [320, 360, 414, 768, 1024, 1280, 1440, 1920];

  for (const path of ["/", "/menu", "/checkout"]) {
    test(`${path} never scrolls sideways from 320px to 1920px`, async ({ page, isMobile }) => {
      test.skip(isMobile, "viewport sweep runs once, on the desktop project");
      test.setTimeout(120_000);
      for (const width of widths) {
        await page.setViewportSize({ width, height: 900 });
        await page.goto(path);
        await page.waitForFunction(() => document.documentElement.classList.contains("reveal-ready"));
        await page.evaluate(() => window.scrollTo({ top: document.documentElement.scrollHeight / 2, behavior: "instant" }));
        await expectNoHorizontalOverflow(page);
      }
    });
  }

  test("content is capped at 1440px on very wide screens", async ({ page, isMobile }) => {
    test.skip(isMobile, "desktop only");
    await page.setViewportSize({ width: 2200, height: 1000 });
    await open(page);
    const box = await page.locator("#popular > div").boundingBox();
    expect(box?.width).toBe(1440);
  });

  test("touch targets are at least 44px on phones", async ({ page, isMobile }) => {
    test.skip(!isMobile, "mobile only");
    await open(page);
    for (const name of ["Search the menu", /^Open cart/, "Open menu"]) {
      const box = await page.getByRole("banner").getByRole("button", { name }).first().boundingBox();
      expect(box?.width, String(name)).toBeGreaterThanOrEqual(44);
      expect(box?.height, String(name)).toBeGreaterThanOrEqual(44);
    }
  });
});
