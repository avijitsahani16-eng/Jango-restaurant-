import { expect, test } from "@playwright/test";

import { open } from "./helpers";

test.describe("forms", () => {
  test("newsletter: validates, subscribes and confirms", async ({ page }) => {
    await open(page);
    const section = page.locator("#newsletter");
    await section.scrollIntoViewIfNeeded();
    const email = section.getByLabel("Email address");

    await section.getByRole("button", { name: "Subscribe" }).click();
    await expect(section.getByRole("alert")).toHaveText("Enter your email address.");
    await expect(email).toBeFocused();

    await email.fill("not-an-email");
    await section.getByRole("button", { name: "Subscribe" }).click();
    await expect(section.getByRole("alert")).toHaveText("That email doesn’t look right.");
    await expect(email).toHaveAttribute("aria-invalid", "true");

    await email.fill("guest@example.com");
    await section.getByRole("button", { name: "Subscribe" }).click();
    await expect(section.getByRole("status")).toContainText("You’re on the list.");
    await expect(section.getByRole("status")).toContainText("guest@example.com");
  });

  test("footer newsletter works independently", async ({ page }) => {
    await open(page);
    const footer = page.getByRole("contentinfo");
    await footer.getByLabel("Email address").fill("regular@example.com");
    await footer.getByRole("button", { name: "Subscribe to the newsletter" }).click();
    await expect(footer.getByRole("status")).toContainText("You’re on the list.");
  });

  test("contact: shows field errors, then sends", async ({ page }) => {
    await open(page);
    const contact = page.locator("#contact");
    await contact.getByRole("button", { name: "Send message" }).scrollIntoViewIfNeeded();

    await contact.getByRole("button", { name: "Send message" }).click();
    await expect(contact.getByText("Please tell us your name.")).toBeVisible();
    await expect(contact.getByText("We need a phone number to reach you.")).toBeVisible();
    await expect(contact.getByText("Write a short message so we can help.")).toBeVisible();
    await expect(contact.getByLabel("Your name")).toBeFocused();

    await contact.getByLabel("Your name").fill("Riya Sen");
    await contact.getByLabel("Mobile number").fill("12345");
    await contact.getByLabel("What is it about?").selectOption("Party or group booking");
    await contact.getByLabel("Message").fill("We would like to book a birthday dinner for 14 people on Saturday.");
    await contact.getByRole("button", { name: "Send message" }).click();
    await expect(contact.getByText("Enter a valid 10-digit mobile number.")).toBeVisible();

    await contact.getByLabel("Mobile number").fill("98765 43210");
    await contact.getByRole("button", { name: "Send message" }).click();
    await expect(contact.getByRole("heading", { name: "Thanks, Riya — message received." })).toBeVisible();

    await contact.getByRole("button", { name: "Send another message" }).click();
    await expect(contact.getByLabel("Your name")).toHaveValue("");
  });

  test("reservation: books a table from the dialog", async ({ page }) => {
    await open(page);
    await page.getByRole("button", { name: "Book a table" }).first().click();
    const dialog = page.getByRole("dialog", { name: "Reserve a table" });
    await expect(dialog).toBeVisible();

    // Focus is trapped inside the dialog.
    await page.keyboard.press("Shift+Tab");
    await expect(dialog.locator(":focus")).toHaveCount(1);

    await dialog.getByRole("button", { name: "Request my table" }).click();
    await expect(dialog.getByText("Please tell us your name.")).toBeVisible();

    await dialog.getByLabel("Your name").fill("Arjun Mukherjee");
    await dialog.getByLabel("Mobile number").fill("9876543210");
    await dialog.getByLabel("Time").selectOption("21:00");
    await dialog.getByLabel("Guests").selectOption("6");
    await dialog.getByLabel("Occasion").selectOption("Anniversary");
    await dialog.getByLabel("Anything we should know?").fill("A quiet corner if possible.");
    await dialog.getByRole("button", { name: "Request my table" }).click();

    // The dialog takes its name from the confirmation heading once the request is in.
    const confirmation = page.getByRole("dialog", { name: "Request received, Arjun!" });
    await expect(confirmation).toBeVisible();
    await expect(confirmation.getByRole("status")).toContainText("A table for 6");
    await expect(confirmation.getByRole("status")).toContainText("9 PM");

    await confirmation.getByRole("button", { name: "Done" }).click();
    await expect(confirmation).toBeHidden();
  });

  test("forms survive a server error gracefully", async ({ page }) => {
    await page.route("**/api/newsletter", (route) => route.fulfill({ status: 500, contentType: "text/plain", body: "boom" }));
    await open(page);
    const section = page.locator("#newsletter");
    await section.getByLabel("Email address").fill("guest@example.com");
    await section.getByRole("button", { name: "Subscribe" }).click();
    await expect(section.getByRole("alert")).toContainText("couldn’t reach the kitchen");
    await expect(section.getByLabel("Email address")).toHaveValue("guest@example.com");
  });
});
