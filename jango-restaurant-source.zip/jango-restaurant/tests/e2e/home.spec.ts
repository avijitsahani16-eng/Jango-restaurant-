import { expect, test } from "@playwright/test";

import { expectNoHorizontalOverflow, open, scrollThrough, trackErrors } from "./helpers";

const SECTIONS = [
  "hero-title",
  "features-title",
  "categories",
  "popular",
  "offers",
  "about",
  "how-it-works",
  "bar",
  "reviews",
  "gallery",
  "app",
  "faq",
  "newsletter",
  "contact",
];

test.describe("home page", () => {
  test("renders every section, in order, without errors", async ({ page }) => {
    const errors = trackErrors(page);
    await open(page);

    await expect(page).toHaveTitle(/Jango Restaurant & Bar/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText(/Fresh off the\s+flame,\s+straight to your door\./);
    await expect(page.locator("h1")).toHaveCount(1);

    const order = await page.evaluate((ids) => {
      const found = ids.map((id) => document.getElementById(id));
      return found.map((element, index) => {
        if (!element) return "missing";
        const previous = found[index - 1];
        return !previous || previous.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_FOLLOWING ? "ok" : "out of order";
      });
    }, SECTIONS);
    expect(order).toEqual(SECTIONS.map(() => "ok"));

    await scrollThrough(page);
    await expectNoHorizontalOverflow(page);
    expect(errors).toEqual([]);
  });

  test("loads every image and reveals every section while scrolling", async ({ page }) => {
    await open(page);
    await scrollThrough(page);

    const broken = await page.evaluate(() =>
      Array.from(document.images)
        .filter((image) => !image.complete || image.naturalWidth === 0)
        .map((image) => image.currentSrc || image.src),
    );
    expect(broken).toEqual([]);

    const hidden = await page.evaluate(
      () => Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]")).filter((element) => getComputedStyle(element).opacity !== "1").length,
    );
    expect(hidden).toBe(0);
  });

  test("shows the restaurant's real details", async ({ page }) => {
    await open(page);
    const contact = page.locator("#contact");
    // Word for word as on the Google Maps listing.
    await expect(contact.getByText("NH12, more, Hasadanga, Mayapur")).toBeVisible();
    await expect(contact.getByText("Dhubulia, West Bengal 741140")).toBeVisible();
    await expect(contact.getByText("FF82+9P Dhubulia, West Bengal")).toBeVisible();
    await expect(contact.getByRole("link", { name: "+91 81675 05450" })).toHaveAttribute("href", "tel:+918167505450");
    await expect(contact.getByRole("listitem").filter({ hasText: "Sunday" })).toContainText("11 AM – 11 PM");
    // Live status is computed in the restaurant's time zone after hydration.
    await expect(contact.getByText(/^(Open now|Closed)$/).first()).toBeVisible();
    await expect(page.getByRole("link", { name: /4\.7 out of 5 stars.*380\+ reviews on Google/ })).toHaveAttribute("href", /google\.com/);
  });

  test("hero calls to action work", async ({ page }) => {
    await open(page);
    await page.getByRole("button", { name: "Book a table" }).first().click();
    const dialog = page.getByRole("dialog", { name: "Reserve a table" });
    await expect(dialog).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(dialog).toBeHidden();

    await page.getByRole("link", { name: "Order online" }).first().click();
    await expect(page).toHaveURL(/\/menu$/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("The full menu");
  });

  test("the sticky header shrinks and reports reading progress", async ({ page }) => {
    await open(page);
    const header = page.getByRole("banner");
    await expect(header).toHaveAttribute("data-scrolled", "false");
    const before = (await header.boundingBox())?.height ?? 0;

    await page.evaluate(() => window.scrollTo({ top: 900, behavior: "instant" }));
    await expect(header).toHaveAttribute("data-scrolled", "true");
    await expect.poll(async () => (await header.boundingBox())?.height ?? 0).toBeLessThan(before);
    expect((await header.boundingBox())?.y).toBe(0);
  });

  test("the offer code can be copied and waits in the cart", async ({ page, context, browserName }) => {
    if (browserName === "chromium") await context.grantPermissions(["clipboard-read", "clipboard-write"]);
    await open(page);
    const coupon = page.getByRole("button", { name: "Use code JANGO20 — copy it" });
    await coupon.scrollIntoViewIfNeeded();
    await coupon.click();
    await expect(page.getByRole("button", { name: "Use code JANGO20 — copied" })).toBeVisible();
    await expect(page.getByRole("status").filter({ hasText: "JANGO20 copied" })).toBeVisible();
    const saved = await page.evaluate(() => JSON.parse(localStorage.getItem("jango.cart.v1") ?? "{}").couponCode);
    expect(saved).toBe("JANGO20");
  });

  test("testimonials can be paged and paused", async ({ page }) => {
    await open(page);
    const carousel = page.getByRole("group", { name: "Customer reviews" });
    await carousel.scrollIntoViewIfNeeded();
    await expect(carousel.getByRole("group", { name: "1 of 6" })).toBeVisible();

    const reviews = page.locator("#reviews");
    await reviews.getByRole("button", { name: "Pause automatic sliding" }).click();
    await expect(reviews.getByRole("button", { name: "Resume automatic sliding" })).toHaveAttribute("aria-pressed", "true");

    await reviews.getByRole("button", { name: "Next review" }).click();
    await expect(reviews.getByRole("button", { name: "Go to review 2" })).toHaveAttribute("aria-current", "true");
    await reviews.getByRole("button", { name: "Previous review" }).click();
    await expect(reviews.getByRole("button", { name: "Go to review 1" })).toHaveAttribute("aria-current", "true");
  });

  test("the FAQ accordion opens one answer at a time", async ({ page }) => {
    await open(page);
    const faq = page.locator("#faq");
    const first = faq.getByRole("button", { name: "Where do you deliver, and how long does it take?" });
    const alcohol = faq.getByRole("button", { name: "Do you deliver alcohol?" });
    await expect(first).toHaveAttribute("aria-expanded", "true");

    await alcohol.click();
    await expect(alcohol).toHaveAttribute("aria-expanded", "true");
    await expect(first).toHaveAttribute("aria-expanded", "false");
    await expect(faq.getByText(/served only in-house at the bar/)).toBeVisible();
  });

  test("the gallery opens a keyboard-friendly lightbox", async ({ page }) => {
    await open(page);
    const thumbnail = page.getByRole("button", { name: /^View photo:/ }).first();
    await thumbnail.scrollIntoViewIfNeeded();
    await thumbnail.click();

    const lightbox = page.getByRole("dialog", { name: "Photo gallery" });
    await expect(lightbox).toBeVisible();
    const counter = lightbox.locator("p[aria-live]");
    await expect(counter).toHaveText(/^01\s*\/\s*08$/);
    await page.keyboard.press("ArrowRight");
    await expect(counter).toHaveText(/^02/);
    await page.keyboard.press("ArrowLeft");
    await expect(counter).toHaveText(/^01/);

    await page.keyboard.press("Escape");
    await expect(lightbox).toBeHidden();
    await expect(thumbnail).toBeFocused();
  });

  test("the map loads lazily with a directions link", async ({ page }) => {
    await open(page);
    await expect(page.locator("#contact iframe")).toHaveCount(0);
    await page.locator("#contact").getByRole("link", { name: /Get directions/ }).scrollIntoViewIfNeeded();
    const map = page.locator("#contact iframe");
    await expect(map).toHaveAttribute("title", /Map showing Jango Restaurant Cum Bar/);
    await expect(map).toHaveAttribute("src", /google\.com\/maps\/embed/);
    await expect(page.locator("#contact").getByRole("link", { name: /Get directions/ })).toHaveAttribute("href", /google\.com\/maps\/dir/);
  });
});
