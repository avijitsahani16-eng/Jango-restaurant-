import "@testing-library/jest-dom/vitest";

import { cleanup } from "@testing-library/react";
import type { ComponentProps } from "react";
import { afterEach, beforeEach, vi } from "vitest";

/* Next.js building blocks, reduced to plain HTML for unit tests. */
vi.mock("next/image", () => ({
  default: ({ src, alt, ...props }: { src: string | { src: string }; alt: string } & Record<string, unknown>) => {
    const { fill, placeholder, preload, quality, sizes, loading, ...rest } = props;
    void fill;
    void placeholder;
    void preload;
    void quality;
    void sizes;
    void loading;
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={typeof src === "string" ? src : src.src} alt={alt} {...rest} />;
  },
}));

vi.mock("next/link", () => ({
  default: ({ href, children, prefetch, scroll, ...props }: ComponentProps<"a"> & { prefetch?: boolean; scroll?: boolean }) => {
    void prefetch;
    void scroll;
    return (
      <a href={String(href)} {...props}>
        {children}
      </a>
    );
  },
}));

vi.mock("next/navigation", () => ({
  usePathname: () => "/",
  useRouter: () => ({ push: vi.fn(), replace: vi.fn(), prefetch: vi.fn(), back: vi.fn() }),
  useSearchParams: () => new URLSearchParams(),
  notFound: () => {
    throw new Error("NEXT_NOT_FOUND");
  },
}));

/* `server-only` throws outside a server bundle; the API tests import server code directly. */
vi.mock("server-only", () => ({}));

/* jsdom gaps */
if (typeof window !== "undefined") {
  window.matchMedia ??= ((query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    addListener: vi.fn(),
    removeListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })) as unknown as typeof window.matchMedia;

  class Observer {
    observe() {}
    unobserve() {}
    disconnect() {}
    takeRecords() {
      return [];
    }
  }
  window.IntersectionObserver ??= Observer as unknown as typeof IntersectionObserver;
  window.ResizeObserver ??= Observer as unknown as typeof ResizeObserver;
  window.scrollTo = vi.fn() as unknown as typeof window.scrollTo;
}

beforeEach(() => {
  if (typeof window !== "undefined") window.localStorage.clear();
});

afterEach(() => {
  cleanup();
});
