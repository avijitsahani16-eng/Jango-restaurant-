import { describe, expect, it } from "vitest";

import { formatClock, formatCompact, formatINR, formatRating, groupIndian, initials, pluralize } from "@/lib/format";
import { getOpenStatus, reservationSlots, zonedClock, zonedDateString, type DayHours } from "@/lib/hours";
import { getOrderProgress } from "@/lib/order-status";

describe("formatting", () => {
  it("formats rupees with Indian digit grouping", () => {
    expect(formatINR(0)).toBe("₹0");
    expect(formatINR(329)).toBe("₹329");
    expect(formatINR(1299)).toBe("₹1,299");
    expect(formatINR(123456)).toBe("₹1,23,456");
    expect(formatINR(12345678)).toBe("₹1,23,45,678");
    expect(formatINR(99.6)).toBe("₹100");
    expect(formatINR(-50)).toBe("-₹50");
  });

  it("groups digits the Indian way", () => {
    expect(groupIndian(999)).toBe("999");
    expect(groupIndian(1000)).toBe("1,000");
    expect(groupIndian(100000)).toBe("1,00,000");
    expect(groupIndian(-2500000)).toBe("-25,00,000");
  });

  it("pluralises", () => {
    expect(pluralize(1, "item")).toBe("1 item");
    expect(pluralize(2, "item")).toBe("2 items");
    expect(pluralize(0, "dish", "dishes")).toBe("0 dishes");
  });

  it("formats 24-hour times as a 12-hour clock", () => {
    expect(formatClock("11:00")).toBe("11 AM");
    expect(formatClock("23:00")).toBe("11 PM");
    expect(formatClock("12:30")).toBe("12:30 PM");
    expect(formatClock("00:15")).toBe("12:15 AM");
  });

  it("formats ratings, compact numbers and initials", () => {
    expect(formatRating(5)).toBe("5.0");
    expect(formatRating(4.66)).toBe("4.7");
    expect(formatCompact(380)).toBe("380");
    expect(formatCompact(1200)).toBe("1.2k");
    expect(formatCompact(12500)).toBe("13k");
    expect(initials("Ananya Roy")).toBe("AR");
    expect(initials("  sourav   mondal das ")).toBe("SM");
    expect(initials("")).toBe("");
  });
});

describe("opening hours (Asia/Kolkata, UTC+5:30)", () => {
  // 11 November 2026 is a Wednesday.
  const at = (iso: string) => getOpenStatus(new Date(iso));

  it("is closed one minute before opening", () => {
    expect(at("2026-11-11T05:29:00Z")).toEqual({ isOpen: false, label: "Closed", detail: "Opens 11 AM", today: 3 });
  });

  it("opens at 11:00 sharp", () => {
    expect(at("2026-11-11T05:30:00Z")).toEqual({ isOpen: true, label: "Open now", detail: "Closes 11 PM", today: 3 });
  });

  it("stays open until 22:59 and closes at 23:00", () => {
    expect(at("2026-11-11T17:29:00Z").isOpen).toBe(true);
    expect(at("2026-11-11T17:30:00Z")).toEqual({ isOpen: false, label: "Closed", detail: "Opens tomorrow, 11 AM", today: 3 });
  });

  it("uses the restaurant's date, not the visitor's", () => {
    // 20:00 UTC on Tuesday is already 01:30 on Wednesday in India.
    expect(at("2026-11-10T20:00:00Z")).toMatchObject({ isOpen: false, detail: "Opens 11 AM", today: 3 });
    expect(zonedDateString(new Date("2026-11-10T20:00:00Z"))).toBe("2026-11-11");
    expect(zonedClock(new Date("2026-11-10T20:00:00Z"), "Asia/Kolkata")).toEqual({ day: 3, minutes: 90 });
  });

  it("looks ahead to the next open day when today is closed", () => {
    const mondayOnly: DayHours[] = [{ day: 1, label: "Monday", open: "11:00", close: "23:00" }];
    expect(getOpenStatus(new Date("2026-11-11T08:00:00Z"), mondayOnly).detail).toBe("Opens Monday, 11 AM");
    // Sunday 15 November → Monday is "tomorrow".
    expect(getOpenStatus(new Date("2026-11-15T08:00:00Z"), mondayOnly).detail).toBe("Opens tomorrow, 11 AM");
    expect(getOpenStatus(new Date("2026-11-11T08:00:00Z"), [])).toMatchObject({ isOpen: false, detail: "" });
  });

  it("offers half-hourly table slots from 11:30 to 22:00", () => {
    const slots = reservationSlots();
    expect(slots[0]).toBe("11:30");
    expect(slots.at(-1)).toBe("22:00");
    expect(slots).toHaveLength(22);
  });
});

describe("order progress", () => {
  const delivery = { placedAt: "2026-11-11T12:00:00Z", etaMinutes: 30, fulfilment: "delivery" as const };
  const after = (minutes: number) => new Date(Date.parse(delivery.placedAt) + minutes * 60_000);

  it("walks a delivery through its four stages", () => {
    expect(getOrderProgress(delivery, after(0))).toMatchObject({ current: 0, minutesLeft: 30, done: false });
    expect(getOrderProgress(delivery, after(5)).stages[1].key).toBe("preparing");
    expect(getOrderProgress(delivery, after(5)).current).toBe(1);
    expect(getOrderProgress(delivery, after(17))).toMatchObject({ current: 2, minutesLeft: 13 });
    expect(getOrderProgress(delivery, after(31))).toMatchObject({ current: 3, minutesLeft: 0, done: true });
  });

  it("has three stages for pickup", () => {
    const pickup = { ...delivery, etaMinutes: 20, fulfilment: "pickup" as const };
    const progress = getOrderProgress(pickup, after(20));
    expect(progress.stages.map((stage) => stage.key)).toEqual(["confirmed", "preparing", "ready"]);
    expect(progress.done).toBe(true);
  });

  it("copes with clocks that are behind and with bad timestamps", () => {
    expect(getOrderProgress(delivery, after(-10))).toMatchObject({ current: 0, minutesLeft: 30 });
    expect(getOrderProgress({ ...delivery, placedAt: "not a date" }, after(0)).current).toBe(0);
  });
});
