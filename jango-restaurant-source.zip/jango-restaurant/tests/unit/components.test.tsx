import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { DishCard, DishRow } from "@/components/menu/dish-card";
import { QuantityStepper } from "@/components/menu/quantity-stepper";
import { Faq } from "@/components/sections/faq";
import { NewsletterForm } from "@/components/ui/newsletter-form";
import { DietMark, Price, Rating, Stars } from "@/components/ui/primitives";
import { faqs } from "@/data/content";
import { getDish } from "@/data/dishes";
import { cart, cartStore } from "@/stores/cart";
import { favoritesStore } from "@/stores/customer";
import { toastStore } from "@/stores/toast";
import { uiStore } from "@/stores/ui";

const butterChicken = getDish("smoky-butter-chicken")!;
const hakkaNoodles = getDish("chicken-hakka-noodles")!;

beforeEach(() => {
  cart.clear();
  favoritesStore.setState([]);
  toastStore.setState([]);
  uiStore.setState({ overlay: null, quickViewId: null });
});

describe("primitives", () => {
  it("labels diet marks, ratings and prices for screen readers", () => {
    render(
      <>
        <DietMark diet="veg" />
        <DietMark diet="non-veg" />
        <Rating value={4.8} count={412} />
        <Stars value={4} />
        <Price amount={329} compareAt={379} />
      </>,
    );
    expect(screen.getByRole("img", { name: "Vegetarian" })).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "Non-vegetarian" })).toBeInTheDocument();
    expect(screen.getByText("Rated 4.8 out of 5 by 412 customers")).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "Rated 4 out of 5" })).toBeInTheDocument();
    expect(screen.getByText("₹329")).toBeInTheDocument();
    expect(screen.getByText("₹379").tagName).toBe("S");
  });
});

describe("QuantityStepper", () => {
  it("steps up and down and respects its bounds", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(<QuantityStepper quantity={1} min={1} max={3} label="Momos" onChange={onChange} />);

    expect(screen.getByRole("group", { name: "Quantity of Momos" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Decrease quantity of Momos" })).toBeDisabled();

    await user.click(screen.getByRole("button", { name: "Increase quantity of Momos" }));
    expect(onChange).toHaveBeenLastCalledWith(2);

    rerender(<QuantityStepper quantity={3} min={1} max={3} label="Momos" onChange={onChange} />);
    expect(screen.getByRole("button", { name: "Increase quantity of Momos" })).toBeDisabled();
    await user.click(screen.getByRole("button", { name: "Decrease quantity of Momos" }));
    expect(onChange).toHaveBeenLastCalledWith(2);
  });

  it("offers to remove the item when one is left", () => {
    render(<QuantityStepper quantity={1} removable label="Momos" onChange={() => {}} />);
    expect(screen.getByRole("button", { name: "Remove Momos from cart" })).toBeEnabled();
  });
});

describe("DishCard", () => {
  it("shows the dish and adds it to the cart", async () => {
    const user = userEvent.setup();
    render(<DishCard dish={butterChicken} />);

    expect(screen.getByRole("heading", { name: "Smoky Butter Chicken" })).toBeInTheDocument();
    expect(screen.getByRole("img", { name: /smoky butter chicken in a dark bowl/i })).toBeInTheDocument();
    expect(screen.getByText("₹329")).toBeInTheDocument();
    expect(screen.getByText("Bestseller")).toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "Add Smoky Butter Chicken to cart" }));
    expect(cartStore.getState().lines).toEqual([{ dishId: "smoky-butter-chicken", quantity: 1 }]);

    // The button turns into a stepper.
    const stepper = await screen.findByRole("group", { name: "Quantity of Smoky Butter Chicken" });
    await user.click(within(stepper).getByRole("button", { name: /increase/i }));
    expect(cartStore.getState().lines[0].quantity).toBe(2);
  });

  it("toggles a favourite and opens the quick view from the title", async () => {
    const user = userEvent.setup();
    render(<DishCard dish={butterChicken} />);

    const heart = screen.getByRole("button", { name: "Save Smoky Butter Chicken to favourites" });
    expect(heart).toHaveAttribute("aria-pressed", "false");
    await user.click(heart);
    expect(favoritesStore.getState()).toEqual(["smoky-butter-chicken"]);
    expect(screen.getByRole("button", { name: "Remove Smoky Butter Chicken from favourites" })).toHaveAttribute("aria-pressed", "true");

    await user.click(screen.getByRole("button", { name: "Smoky Butter Chicken" }));
    expect(uiStore.getState()).toEqual({ overlay: "quick-view", quickViewId: "smoky-butter-chicken" });
  });

  it("falls back to a menu row for dishes without a photograph", () => {
    const { container } = render(<DishCard dish={hakkaNoodles} />);
    expect(screen.getByRole("heading", { name: "Chicken Hakka Noodles" })).toBeInTheDocument();
    expect(container.querySelector("img")).toBeNull();
    expect(screen.getByRole("button", { name: "Add Chicken Hakka Noodles to cart" })).toBeInTheDocument();
  });

  it("renders a row directly", () => {
    render(<DishRow dish={hakkaNoodles} />);
    expect(screen.getByText("₹189")).toBeInTheDocument();
  });
});

describe("Faq", () => {
  it("opens one answer at a time", async () => {
    const user = userEvent.setup();
    render(<Faq />);

    const [first, second] = faqs;
    const firstButton = screen.getByRole("button", { name: first.question });
    const secondButton = screen.getByRole("button", { name: second.question });

    expect(firstButton).toHaveAttribute("aria-expanded", "true");
    expect(secondButton).toHaveAttribute("aria-expanded", "false");

    await user.click(secondButton);
    expect(firstButton).toHaveAttribute("aria-expanded", "false");
    expect(secondButton).toHaveAttribute("aria-expanded", "true");
    expect(screen.getByRole("region", { name: second.question })).toHaveTextContent(second.answer);

    await user.click(secondButton);
    expect(secondButton).toHaveAttribute("aria-expanded", "false");
  });

  it("keeps every answer in the document for search engines", () => {
    render(<Faq />);
    for (const faq of faqs) expect(screen.getByText(faq.answer)).toBeInTheDocument();
  });
});

describe("NewsletterForm", () => {
  it("validates before it talks to the server", async () => {
    const user = userEvent.setup();
    const fetchMock = vi.spyOn(globalThis, "fetch");
    render(<NewsletterForm />);

    await user.click(screen.getByRole("button", { name: /subscribe/i }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Enter your email address.");

    await user.type(screen.getByLabelText("Email address"), "not-an-email");
    await user.click(screen.getByRole("button", { name: /subscribe/i }));
    expect(await screen.findByRole("alert")).toHaveTextContent("That email doesn’t look right.");
    expect(screen.getByLabelText("Email address")).toHaveAttribute("aria-invalid", "true");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("subscribes and confirms", async () => {
    const user = userEvent.setup();
    const fetchMock = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValue(new Response(JSON.stringify({ ok: true, message: "You’re on the list." }), { status: 200, headers: { "content-type": "application/json" } }));
    render(<NewsletterForm />);

    await user.type(screen.getByLabelText("Email address"), "guest@example.com");
    await user.click(screen.getByRole("button", { name: /subscribe/i }));

    expect(await screen.findByRole("status")).toHaveTextContent("You’re on the list.");
    expect(fetchMock).toHaveBeenCalledOnce();
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("/api/newsletter");
    expect(JSON.parse(String(init?.body))).toEqual({ email: "guest@example.com", company: "" });
  });

  it("shows the server's message when the request fails", async () => {
    const user = userEvent.setup();
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ ok: false, message: "Too many attempts. Please wait a minute and try again." }), { status: 429 }));
    render(<NewsletterForm variant="compact" />);

    await user.type(screen.getByLabelText("Email address"), "guest@example.com");
    await user.click(screen.getByRole("button", { name: "Subscribe to the newsletter" }));

    await waitFor(() => expect(screen.getByRole("alert")).toHaveTextContent("Too many attempts"));
  });
});
