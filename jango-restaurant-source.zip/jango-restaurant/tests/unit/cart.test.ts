import { describe, expect, it } from "vitest";

import {
  addLine,
  calculateTotals,
  countItems,
  couponDiscount,
  findCoupon,
  getQuantity,
  MAX_QUANTITY,
  removeLine,
  sanitizeLines,
  setLineQuantity,
  toOrderLines,
} from "@/lib/cart";
import type { CartLine, Coupon, Dish } from "@/types";

const BUTTER_CHICKEN = "smoky-butter-chicken"; // ₹329
const MOMOS = "steamed-chicken-momos"; // ₹149
const BIRYANI = "kolkata-chicken-biryani"; // ₹279

const line = (dishId: string, quantity: number): CartLine => ({ dishId, quantity });

describe("cart lines", () => {
  it("adds a new dish with quantity 1", () => {
    expect(addLine([], BUTTER_CHICKEN)).toEqual([line(BUTTER_CHICKEN, 1)]);
  });

  it("increments an existing dish instead of duplicating it", () => {
    const lines = addLine(addLine([], BUTTER_CHICKEN), BUTTER_CHICKEN, 2);
    expect(lines).toEqual([line(BUTTER_CHICKEN, 3)]);
  });

  it("never mutates the input", () => {
    const original = [line(MOMOS, 1)];
    addLine(original, MOMOS);
    setLineQuantity(original, MOMOS, 5);
    removeLine(original, MOMOS);
    expect(original).toEqual([line(MOMOS, 1)]);
  });

  it(`caps quantities at ${MAX_QUANTITY}`, () => {
    expect(addLine([], MOMOS, 99)).toEqual([line(MOMOS, MAX_QUANTITY)]);
    expect(setLineQuantity([line(MOMOS, 2)], MOMOS, 500)).toEqual([line(MOMOS, MAX_QUANTITY)]);
  });

  it("removes a line when its quantity drops to zero", () => {
    expect(setLineQuantity([line(MOMOS, 1), line(BIRYANI, 2)], MOMOS, 0)).toEqual([line(BIRYANI, 2)]);
    expect(removeLine([line(MOMOS, 1)], MOMOS)).toEqual([]);
  });

  it("reports quantities and item counts", () => {
    const lines = [line(MOMOS, 2), line(BIRYANI, 3)];
    expect(getQuantity(lines, BIRYANI)).toBe(3);
    expect(getQuantity(lines, "missing")).toBe(0);
    expect(countItems(lines)).toBe(5);
  });

  it("sanitises untrusted data from storage", () => {
    const dirty = [line(BUTTER_CHICKEN, 2), line("not-on-the-menu", 1), line(BUTTER_CHICKEN, 30), null, line(MOMOS, -4), { dishId: 42, quantity: 1 }, "junk"];
    expect(sanitizeLines(dirty)).toEqual([line(BUTTER_CHICKEN, MAX_QUANTITY)]);
    expect(sanitizeLines("nope")).toEqual([]);
    expect(sanitizeLines(undefined)).toEqual([]);
  });
});

describe("totals", () => {
  it("is all zeros for an empty cart", () => {
    const totals = calculateTotals([]);
    expect(totals).toMatchObject({ itemCount: 0, subtotal: 0, discount: 0, deliveryFee: 0, tax: 0, total: 0, freeDeliveryRemaining: 499, freeDeliveryProgress: 0 });
  });

  it("adds the delivery fee and GST below the free-delivery threshold", () => {
    const totals = calculateTotals([line(MOMOS, 1)]);
    // 149 + 5% GST (7.45 → 7) + ₹39 delivery
    expect(totals).toMatchObject({ subtotal: 149, tax: 7, deliveryFee: 39, total: 195, freeDeliveryRemaining: 350 });
    expect(totals.freeDeliveryProgress).toBeCloseTo(149 / 499);
  });

  it("delivers free once the subtotal reaches the threshold", () => {
    const totals = calculateTotals([line(BUTTER_CHICKEN, 2)]);
    expect(totals).toMatchObject({ subtotal: 658, deliveryFee: 0, tax: 33, total: 691, freeDeliveryRemaining: 0, freeDeliveryProgress: 1 });
  });

  it("treats exactly ₹499 as free delivery", () => {
    const menu = [{ id: "x", price: 499 }] as Dish[];
    expect(calculateTotals([line("x", 1)], { menu }).deliveryFee).toBe(0);
    const cheaper = [{ id: "x", price: 498 }] as Dish[];
    expect(calculateTotals([line("x", 1)], { menu: cheaper }).deliveryFee).toBe(39);
  });

  it("never charges delivery for pickup", () => {
    expect(calculateTotals([line(MOMOS, 1)], { fulfilment: "pickup" })).toMatchObject({ deliveryFee: 0, total: 156 });
  });

  it("ignores lines for dishes that are not on the menu", () => {
    expect(calculateTotals([line("ghost", 3), line(MOMOS, 1)])).toMatchObject({ itemCount: 1, subtotal: 149 });
  });
});

describe("coupons", () => {
  it("finds coupons case-insensitively and ignores whitespace", () => {
    expect(findCoupon("  jango20 ")?.code).toBe("JANGO20");
    expect(findCoupon("nope")).toBeNull();
    expect(findCoupon("")).toBeNull();
    expect(findCoupon(null)).toBeNull();
  });

  it("applies a percentage coupon before tax", () => {
    const totals = calculateTotals([line(BUTTER_CHICKEN, 2)], { couponCode: "JANGO20" });
    // 20% of 658 = 131.6 → 132; GST on 526 = 26.3 → 26
    expect(totals).toMatchObject({ subtotal: 658, discount: 132, tax: 26, deliveryFee: 0, total: 552, couponError: null });
    expect(totals.appliedCoupon?.code).toBe("JANGO20");
  });

  it("caps a percentage coupon at its maximum discount", () => {
    const totals = calculateTotals([line(BUTTER_CHICKEN, 4)], { couponCode: "JANGO20" });
    expect(totals).toMatchObject({ subtotal: 1316, discount: 150, tax: 58, total: 1224 });
  });

  it("applies a flat coupon", () => {
    const totals = calculateTotals([line(BUTTER_CHICKEN, 1)], { couponCode: "treat50" });
    // 329 − 50 = 279; GST 13.95 → 14; delivery ₹39 because the item total is under ₹499
    expect(totals).toMatchObject({ discount: 50, tax: 14, deliveryFee: 39, total: 332 });
  });

  it("explains how much more is needed when the order is too small", () => {
    const totals = calculateTotals([line(MOMOS, 2)], { couponCode: "JANGO20" });
    expect(totals.discount).toBe(0);
    expect(totals.appliedCoupon).toBeNull();
    expect(totals.couponError).toBe("Add ₹101 more to use JANGO20.");
  });

  it("rejects unknown codes without changing the total", () => {
    const totals = calculateTotals([line(BUTTER_CHICKEN, 2)], { couponCode: "FREEFOOD" });
    expect(totals.couponError).toBe("That code isn’t valid.");
    expect(totals.total).toBe(691);
  });

  it("never discounts more than the subtotal", () => {
    const generous: Coupon = { code: "BIG", title: "", description: "", kind: "flat", value: 500, minSubtotal: 0 };
    expect(couponDiscount(generous, 300)).toBe(300);
    expect(couponDiscount({ ...generous, minSubtotal: 400 }, 300)).toBe(0);
  });
});

describe("order snapshot", () => {
  it("freezes names and prices for the receipt", () => {
    expect(toOrderLines([line(BUTTER_CHICKEN, 2), line("ghost", 1)])).toEqual([
      { dishId: BUTTER_CHICKEN, name: "Smoky Butter Chicken", unitPrice: 329, quantity: 2 },
    ]);
  });
});
