import { describe, expect, it } from "vitest";

import {
  clean,
  cleanMultiline,
  isEmail,
  normalizePhone,
  validateContact,
  validateCustomer,
  validateNewsletter,
  validateOrder,
  validateReservation,
} from "@/lib/validation";

describe("primitives", () => {
  it("normalises Indian mobile numbers", () => {
    expect(normalizePhone("9876543210")).toBe("9876543210");
    expect(normalizePhone("+91 98765 43210")).toBe("9876543210");
    expect(normalizePhone("098765-43210")).toBe("9876543210");
    expect(normalizePhone("919876543210")).toBe("9876543210");
  });

  it("rejects numbers that cannot be Indian mobiles", () => {
    expect(normalizePhone("12345")).toBeNull();
    expect(normalizePhone("5876543210")).toBeNull();
    expect(normalizePhone("98765432101")).toBeNull();
    expect(normalizePhone("")).toBeNull();
  });

  it("recognises email addresses", () => {
    expect(isEmail("guest@example.com")).toBe(true);
    expect(isEmail("first.last+tag@sub.example.co.in")).toBe(true);
    expect(isEmail("guest@example")).toBe(false);
    expect(isEmail("guest example@x.com")).toBe(false);
    expect(isEmail("@example.com")).toBe(false);
  });

  it("cleans whitespace and enforces length limits", () => {
    expect(clean("  hello    world  ")).toBe("hello world");
    expect(clean("abcdef", 3)).toBe("abc");
    expect(clean(42)).toBe("");
    expect(cleanMultiline("a\r\n\r\n\r\n\r\nb   c")).toBe("a\n\nb c");
  });
});

describe("newsletter", () => {
  it("accepts and lower-cases a valid email", () => {
    expect(validateNewsletter({ email: "  Guest@Example.COM " })).toEqual({ ok: true, data: { email: "guest@example.com" } });
  });

  it("explains what is wrong", () => {
    expect(validateNewsletter({ email: "" })).toEqual({ ok: false, errors: { email: "Enter your email address." } });
    expect(validateNewsletter({ email: "nope" })).toEqual({ ok: false, errors: { email: "That email doesn’t look right." } });
    expect(validateNewsletter({})).toMatchObject({ ok: false });
  });
});

describe("contact form", () => {
  const valid = { name: "Riya Sen", phone: "98765 43210", email: "", topic: "General enquiry", message: "Do you host birthday parties on weekdays?" };

  it("accepts a complete message and normalises the phone number", () => {
    const result = validateContact(valid);
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.data.phone).toBe("9876543210");
  });

  it("reports every invalid field", () => {
    const result = validateContact({ name: "", phone: "123", email: "bad", topic: "Spam", message: "hi" });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(Object.keys(result.errors).sort()).toEqual(["email", "message", "name", "phone", "topic"]);
  });

  it("treats the email as optional", () => {
    expect(validateContact({ ...valid, email: "" }).ok).toBe(true);
    expect(validateContact({ ...valid, email: "riya@example.com" }).ok).toBe(true);
  });
});

describe("reservation", () => {
  // 11:30 on Wednesday 11 November 2026, India time.
  const now = new Date("2026-11-11T06:00:00Z");
  const valid = { name: "Arjun", phone: "9876543210", date: "2026-11-12", time: "20:00", guests: "4", occasion: "Birthday", notes: "" };

  it("accepts a valid request and coerces the guest count", () => {
    const result = validateReservation(valid, now);
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.data.guests).toBe(4);
  });

  it("allows booking for today, in the restaurant's time zone", () => {
    expect(validateReservation({ ...valid, date: "2026-11-11" }, now).ok).toBe(true);
  });

  it.each([
    ["a date in the past", { date: "2026-11-10" }, "date"],
    ["a date too far ahead", { date: "2027-02-01" }, "date"],
    ["a malformed date", { date: "tomorrow" }, "date"],
    ["a time outside the slots", { time: "10:00" }, "time"],
    ["zero guests", { guests: 0 }, "guests"],
    ["too many guests", { guests: 25 }, "guests"],
    ["an unknown occasion", { occasion: "Heist" }, "occasion"],
    ["a bad phone number", { phone: "12" }, "phone"],
  ])("rejects %s", (_label, patch, field) => {
    const result = validateReservation({ ...valid, ...patch }, now);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.errors).toHaveProperty(field);
  });
});

describe("checkout", () => {
  const customer = { name: "Test User", phone: "9876543210", address: "12 Station Road, Dhubulia" };

  it("requires an address for delivery but not for pickup", () => {
    expect(validateCustomer({ ...customer, address: "" }, "delivery").errors.address).toBe("Where should we deliver?");
    expect(validateCustomer({ ...customer, address: "Here" }, "delivery").errors.address).toBe("Add house number, street and area.");
    expect(validateCustomer({ ...customer, address: "" }, "pickup").errors).toEqual({});
  });

  it("accepts a well-formed order and tidies it up", () => {
    const result = validateOrder({
      lines: [
        { dishId: "smoky-butter-chicken", quantity: 2 },
        { dishId: "smoky-butter-chicken", quantity: 5 }, // duplicate → ignored
        { dishId: "not-a-dish", quantity: 1 }, // unknown → ignored
        { dishId: "warm-gulab-jamun", quantity: 999 }, // over the limit → ignored
      ],
      couponCode: " jango20 ",
      fulfilment: "delivery",
      payment: "upi",
      customer,
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.data.lines).toEqual([{ dishId: "smoky-butter-chicken", quantity: 2 }]);
      expect(result.data.couponCode).toBe("JANGO20");
    }
  });

  it("rejects an empty or malformed order with field errors", () => {
    const result = validateOrder({ lines: [], fulfilment: "teleport", payment: "iou", customer: {} });
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.errors).toMatchObject({
        lines: "Your cart is empty.",
        fulfilment: "Choose delivery or pickup.",
        payment: "Choose a payment method.",
        name: "Please tell us your name.",
      });
    }
    expect(validateOrder({}).ok).toBe(false);
  });
});
