// @vitest-environment node
import { beforeEach, describe, expect, it, vi } from "vitest";

import { POST as contact } from "@/app/api/contact/route";
import { POST as newsletter } from "@/app/api/newsletter/route";
import { POST as orders } from "@/app/api/orders/route";
import { POST as reservations } from "@/app/api/reservations/route";
import { zonedDateString } from "@/lib/hours";
import { rateLimited } from "@/lib/server/api";

let caller = 0;

/** Every request comes from a fresh "IP" so the rate limiter never interferes with other tests. */
function post(path: string, body: unknown, init: { ip?: string; contentType?: string } = {}) {
  caller += 1;
  return new Request(`http://localhost${path}`, {
    method: "POST",
    headers: { "content-type": init.contentType ?? "application/json", "x-forwarded-for": init.ip ?? `10.0.0.${caller}` },
    body: typeof body === "string" ? body : JSON.stringify(body),
  });
}

beforeEach(() => {
  vi.spyOn(console, "info").mockImplementation(() => {});
});

describe("POST /api/newsletter", () => {
  it("subscribes a valid email", async () => {
    const response = await newsletter(post("/api/newsletter", { email: "guest@example.com" }));
    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ ok: true, message: "You’re on the list." });
    expect(console.info).toHaveBeenCalledOnce();
  });

  it("rejects an invalid email with a field error", async () => {
    const response = await newsletter(post("/api/newsletter", { email: "nope" }));
    expect(response.status).toBe(422);
    expect(await response.json()).toMatchObject({ ok: false, errors: { email: "That email doesn’t look right." } });
  });

  it("rejects bodies that are not JSON objects", async () => {
    expect((await newsletter(post("/api/newsletter", "{broken"))).status).toBe(400);
    expect((await newsletter(post("/api/newsletter", [1, 2]))).status).toBe(400);
    expect((await newsletter(post("/api/newsletter", { email: "a@b.co" }, { contentType: "text/plain" }))).status).toBe(400);
  });

  it("quietly drops submissions that fill the honeypot", async () => {
    const response = await newsletter(post("/api/newsletter", { email: "bot@example.com", company: "Spam Ltd" }));
    expect(response.status).toBe(200);
    expect(console.info).not.toHaveBeenCalled();
  });
});

describe("POST /api/contact and /api/reservations", () => {
  it("accepts a valid contact message", async () => {
    const response = await contact(
      post("/api/contact", { name: "Riya", phone: "9876543210", email: "", topic: "Catering", message: "Can you cater lunch for forty people?" }),
    );
    expect(response.status).toBe(200);
  });

  it("returns every contact field error", async () => {
    const response = await contact(post("/api/contact", { name: "", phone: "1", topic: "?", message: "" }));
    expect(response.status).toBe(422);
    const body = await response.json();
    expect(Object.keys(body.errors).sort()).toEqual(["message", "name", "phone", "topic"]);
  });

  it("accepts a reservation for today and rejects one in the past", async () => {
    const today = zonedDateString(new Date());
    const base = { name: "Arjun", phone: "9876543210", time: "20:00", guests: 4, occasion: "Birthday", notes: "" };

    expect((await reservations(post("/api/reservations", { ...base, date: today }))).status).toBe(200);

    const past = await reservations(post("/api/reservations", { ...base, date: "2020-01-01" }));
    expect(past.status).toBe(422);
    expect((await past.json()).errors.date).toBe("That date has already passed.");
  });
});

describe("POST /api/orders", () => {
  const customer = { name: "Test User", phone: "+91 98765 43210", address: "12 Station Road, Dhubulia" };

  it("prices the order on the server, whatever the client claims", async () => {
    const response = await orders(
      post("/api/orders", {
        lines: [
          { dishId: "smoky-butter-chicken", quantity: 2, price: 1 }, // a tampered price is ignored
          { dishId: "free-lobster", quantity: 9 },
        ],
        couponCode: "jango20",
        fulfilment: "delivery",
        payment: "upi",
        customer,
        totals: { total: 1 },
      }),
    );
    expect(response.status).toBe(201);

    const { data } = await response.json();
    expect(data.order.id).toMatch(/^JG-[2-9A-HJ-NP-Z]{6}$/);
    expect(data.order.lines).toEqual([{ dishId: "smoky-butter-chicken", name: "Smoky Butter Chicken", unitPrice: 329, quantity: 2 }]);
    expect(data.order.totals).toEqual({ itemCount: 2, subtotal: 658, discount: 132, deliveryFee: 0, tax: 26, total: 552 });
    expect(data.order.couponCode).toBe("JANGO20");
    expect(data.order.customer.phone).toBe("9876543210");
    expect(data.order.etaMinutes).toBe(30);
  });

  it("ignores a coupon the order does not qualify for", async () => {
    const response = await orders(
      post("/api/orders", { lines: [{ dishId: "steamed-chicken-momos", quantity: 1 }], couponCode: "JANGO20", fulfilment: "pickup", payment: "cash", customer }),
    );
    const { data } = await response.json();
    expect(data.order.totals).toMatchObject({ subtotal: 149, discount: 0, deliveryFee: 0, tax: 7, total: 156 });
    expect(data.order.couponCode).toBeNull();
    expect(data.order.etaMinutes).toBe(20);
  });

  it("rejects an empty cart and missing details", async () => {
    const response = await orders(post("/api/orders", { lines: [], fulfilment: "delivery", payment: "upi", customer: { name: "A" } }));
    expect(response.status).toBe(422);
    const body = await response.json();
    expect(body.message).toBe("Your cart is empty.");
    expect(body.errors).toHaveProperty("address");
  });
});

describe("rate limiting", () => {
  it("allows a burst, then blocks the same client on the same route", () => {
    const request = () => post("/api/anything", {}, { ip: "203.0.113.9" });
    const results = Array.from({ length: 5 }, () => rateLimited(request(), "burst", 3));
    expect(results).toEqual([false, false, false, true, true]);
    expect(rateLimited(request(), "another-route", 3)).toBe(false);
    expect(rateLimited(post("/api/anything", {}, { ip: "203.0.113.10" }), "burst", 3)).toBe(false);
  });

  it("answers 429 once a client exceeds the allowance", async () => {
    const statuses: number[] = [];
    for (let attempt = 0; attempt < 8; attempt += 1) {
      statuses.push((await newsletter(post("/api/newsletter", { email: "guest@example.com" }, { ip: "198.51.100.7" }))).status);
    }
    expect(statuses.slice(0, 6)).toEqual([200, 200, 200, 200, 200, 200]);
    expect(statuses.slice(6)).toEqual([429, 429]);
  });
});
