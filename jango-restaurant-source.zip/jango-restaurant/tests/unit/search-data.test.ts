import { describe, expect, it } from "vitest";

import { coupons, primaryNav, site } from "@/config/site";
import { categories, getCategory, isCategorySlug } from "@/data/categories";
import { cocktails, faqs, gallery, steps, testimonials, trustFeatures } from "@/data/content";
import { categoryCounts, dishes, getDish, getDishesByCategory, popularDishes, totalDishes } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { createQr } from "@/lib/qr";
import { breadcrumbSchema, faqSchema, menuSchema, restaurantSchema, websiteSchema } from "@/lib/schema";
import { searchDishes } from "@/lib/search";

const unique = <T,>(values: T[]) => new Set(values).size === values.length;

describe("menu search", () => {
  it("puts name matches first", () => {
    expect(searchDishes("biryani", dishes)[0].id).toBe("kolkata-chicken-biryani");
    expect(searchDishes("butter chicken", dishes)[0].id).toBe("smoky-butter-chicken");
  });

  it("is case- and punctuation-insensitive", () => {
    expect(searchDishes("  BIRYANI!! ", dishes)[0].id).toBe("kolkata-chicken-biryani");
  });

  it("matches categories as well as names", () => {
    const ids = searchDishes("pizza", dishes).map((dish) => dish.id);
    expect(ids).toEqual(expect.arrayContaining(["tandoori-chicken-pizza", "classic-margherita"]));
  });

  it("requires every word to match", () => {
    expect(searchDishes("chicken zzz", dishes)).toEqual([]);
    expect(searchDishes("xyzzy", dishes)).toEqual([]);
  });

  it("understands diet shortcuts", () => {
    expect(searchDishes("veg", dishes, 50).every((dish) => dish.diet === "veg")).toBe(true);
    expect(searchDishes("non-veg", dishes, 50).every((dish) => dish.diet === "non-veg")).toBe(true);
    expect(searchDishes("Vegetarian", dishes, 50).length).toBeGreaterThan(0);
  });

  it("returns nothing for an empty query and respects the limit", () => {
    expect(searchDishes("", dishes)).toEqual([]);
    expect(searchDishes("   ", dishes)).toEqual([]);
    expect(searchDishes("chicken", dishes, 3)).toHaveLength(3);
  });
});

describe("content integrity", () => {
  it("has ten uniquely named categories", () => {
    expect(categories).toHaveLength(10);
    expect(unique(categories.map((category) => category.slug))).toBe(true);
    expect(isCategorySlug("pizza")).toBe(true);
    expect(isCategorySlug("soup-of-the-day")).toBe(false);
    expect(getCategory("pizza")?.name).toBe("Pizza");
  });

  it("gives every dish a unique id, a real category and sane numbers", () => {
    expect(unique(dishes.map((dish) => dish.id))).toBe(true);
    for (const dish of dishes) {
      expect(dish.id, dish.id).toMatch(/^[a-z0-9]+(-[a-z0-9]+)*$/);
      expect(getCategory(dish.category), dish.id).toBeDefined();
      expect(Number.isInteger(dish.price) && dish.price > 0, dish.id).toBe(true);
      expect(dish.rating, dish.id).toBeGreaterThanOrEqual(1);
      expect(dish.rating, dish.id).toBeLessThanOrEqual(5);
      expect(dish.description.length, dish.id).toBeGreaterThan(20);
      expect(dish.description.length, dish.id).toBeLessThanOrEqual(110);
      if (dish.compareAtPrice !== undefined) expect(dish.compareAtPrice, dish.id).toBeGreaterThan(dish.price);
      if (dish.image) expect(dish.imageAlt?.length ?? 0, `${dish.id} needs alt text`).toBeGreaterThan(15);
    }
  });

  it("keeps every category stocked and the counts honest", () => {
    for (const category of categories) {
      const inCategory = getDishesByCategory(category.slug);
      expect(inCategory.length, category.slug).toBeGreaterThan(0);
      expect(categoryCounts[category.slug]).toBe(inCategory.length);
    }
    expect(Object.values(categoryCounts).reduce((sum, count) => sum + count, 0)).toBe(totalDishes);
  });

  it("only features popular dishes that have a photograph, in rank order", () => {
    expect(popularDishes.length).toBeGreaterThanOrEqual(4);
    expect(popularDishes.every((dish) => dish.image)).toBe(true);
    const ranks = popularDishes.map((dish) => dish.popularRank ?? 0);
    expect(unique(ranks)).toBe(true);
    expect([...ranks].sort((a, b) => a - b)).toEqual(ranks);
    expect(getDish("smoky-butter-chicken")?.popularRank).toBe(1);
  });

  it("has complete marketing content", () => {
    expect(trustFeatures).toHaveLength(8);
    expect(steps.map((step) => step.title)).toEqual(["Browse Menu", "Choose Food", "Secure Checkout", "Fast Delivery"]);
    expect(unique(faqs.map((faq) => faq.id))).toBe(true);
    expect(unique(testimonials.map((review) => review.id))).toBe(true);
    expect(testimonials.every((review) => review.rating >= 1 && review.rating <= 5)).toBe(true);
    expect(gallery.every((photo) => photo.alt.length > 15 && photo.caption.length > 3)).toBe(true);
    expect(unique(cocktails.map((cocktail) => cocktail.id))).toBe(true);
  });

  it("has coupons that are usable as typed", () => {
    for (const coupon of coupons) {
      expect(coupon.code).toBe(coupon.code.toUpperCase().trim());
      expect(coupon.value).toBeGreaterThan(0);
      if (coupon.kind === "percent") expect(coupon.value).toBeLessThanOrEqual(100);
    }
  });

  it("uses the real contact details from the Google listing", () => {
    expect(site.phone.href).toBe("tel:+918167505450");
    expect(site.address.postalCode).toBe("741140");
    expect(site.hours).toHaveLength(7);
    expect(site.hours.every((entry) => entry.open === "11:00" && entry.close === "23:00")).toBe(true);
    expect(primaryNav.every((item) => item.href.startsWith("/"))).toBe(true);
  });
});

describe("structured data", () => {
  it("describes the restaurant with the fields search engines need", () => {
    const schema = restaurantSchema();
    expect(schema["@type"]).toContain("Restaurant");
    expect(schema.telephone).toBe("+918167505450");
    expect(schema.address).toMatchObject({
      streetAddress: "NH12, more, Hasadanga, Mayapur",
      addressLocality: "Dhubulia",
      addressRegion: "West Bengal",
      postalCode: "741140",
      addressCountry: "IN",
    });
    // The listing's pin on Google Maps.
    expect(schema.geo.latitude).toBeCloseTo(23.46592, 4);
    expect(schema.geo.longitude).toBeCloseTo(88.45186, 4);
    expect(schema.openingHoursSpecification).toHaveLength(7);
    expect(schema.openingHoursSpecification[0]).toMatchObject({ opens: "11:00", closes: "23:00" });
    expect(schema).not.toHaveProperty("aggregateRating");
    expect(websiteSchema()["@type"]).toBe("WebSite");
  });

  it("lists the whole menu, or one section of it", () => {
    const full = menuSchema();
    expect(full.hasMenuSection).toHaveLength(10);
    expect(full.hasMenuSection.flatMap((section) => section.hasMenuItem)).toHaveLength(totalDishes);

    const pizza = menuSchema(getCategory("pizza"));
    expect(pizza.hasMenuSection).toHaveLength(1);
    const margherita = pizza.hasMenuSection[0].hasMenuItem.find((item) => item.name === "Classic Margherita");
    expect(margherita).toMatchObject({ suitableForDiet: "https://schema.org/VegetarianDiet", offers: { price: 249, priceCurrency: "INR" } });
  });

  it("builds FAQ and breadcrumb markup", () => {
    const faq = faqSchema(faqs);
    expect(faq.mainEntity).toHaveLength(faqs.length);
    expect(faq.mainEntity[0].acceptedAnswer.text).toBe(faqs[0].answer);

    const crumbs = breadcrumbSchema([
      { name: "Home", path: "/" },
      { name: "Menu", path: "/menu" },
    ]);
    expect(crumbs.itemListElement.map((item) => item.position)).toEqual([1, 2]);
    expect(crumbs.itemListElement[1].item).toMatch(/\/menu$/);
  });
});

describe("utilities", () => {
  it("builds a scannable QR matrix as one SVG path", () => {
    const qr = createQr("https://example.com/menu");
    expect(qr.size).toBeGreaterThanOrEqual(21);
    expect(qr.path).toMatch(/^M0 0h7v1h-7z/); // top-left finder pattern
    expect(createQr("a much longer piece of text that needs a bigger code ".repeat(3)).size).toBeGreaterThan(qr.size);
  });

  it("merges class names so the last conflicting utility wins", () => {
    expect(cn("inline-flex h-11", "hidden md:inline-flex")).toBe("h-11 hidden md:inline-flex");
    expect(cn("relative size-11", ["absolute", false, null, undefined, ["right-3"]])).toBe("size-11 absolute right-3");
    expect(cn("text-section mt-4", "text-white")).toBe("text-section mt-4 text-white");
    expect(cn("shadow-card rounded-card", "shadow-none rounded-2xl")).toBe("shadow-none rounded-2xl");
  });
});
