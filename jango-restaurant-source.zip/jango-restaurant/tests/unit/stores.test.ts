import { beforeEach, describe, expect, it, vi } from "vitest";

import { createPersistedStore, createStore } from "@/lib/store";
import { cart, CART_ADD_EVENT, cartStore } from "@/stores/cart";
import { favoritesStore, ordersStore, profileStore, rememberOrder, saveProfile, toggleFavorite } from "@/stores/customer";
import { dismissToast, showToast, toastStore } from "@/stores/toast";
import { ui, uiStore } from "@/stores/ui";
import type { Order } from "@/types";

describe("createStore", () => {
  it("notifies subscribers only when the state actually changes", () => {
    const store = createStore({ count: 0 });
    const listener = vi.fn();
    const unsubscribe = store.subscribe(listener);

    store.setState((state) => ({ count: state.count + 1 }));
    expect(store.getState()).toEqual({ count: 1 });
    expect(listener).toHaveBeenCalledTimes(1);

    store.setState((state) => state); // same reference → no notification
    expect(listener).toHaveBeenCalledTimes(1);

    unsubscribe();
    store.setState({ count: 5 });
    expect(listener).toHaveBeenCalledTimes(1);
    expect(store.getInitialState()).toEqual({ count: 0 });
  });
});

describe("createPersistedStore", () => {
  const parse = (raw: unknown) => (Array.isArray(raw) ? raw.filter((value): value is string => typeof value === "string") : []);

  it("writes to localStorage and restores from it", () => {
    const first = createPersistedStore<string[]>([], { key: "test.list", parse });
    first.setState(["a", "b"]);
    expect(JSON.parse(window.localStorage.getItem("test.list") ?? "null")).toEqual(["a", "b"]);

    const second = createPersistedStore<string[]>([], { key: "test.list", parse });
    expect(second.getInitialState()).toEqual([]); // what the server and hydration see
    expect(second.getState()).toEqual(["a", "b"]);
  });

  it("falls back to the initial state when storage is corrupt", () => {
    window.localStorage.setItem("test.corrupt", "{not json");
    expect(createPersistedStore<string[]>([], { key: "test.corrupt", parse }).getState()).toEqual([]);
  });

  it("runs stored data through the parser", () => {
    window.localStorage.setItem("test.dirty", JSON.stringify(["ok", 7, null, "fine"]));
    expect(createPersistedStore<string[]>([], { key: "test.dirty", parse }).getState()).toEqual(["ok", "fine"]);
  });

  it("follows changes made in another tab", () => {
    const store = createPersistedStore<string[]>([], { key: "test.sync", parse });
    expect(store.getState()).toEqual([]);
    window.localStorage.setItem("test.sync", JSON.stringify(["from-another-tab"]));
    window.dispatchEvent(new StorageEvent("storage", { key: "test.sync" }));
    expect(store.getState()).toEqual(["from-another-tab"]);
  });
});

describe("cart store", () => {
  beforeEach(() => {
    cart.clear();
    toastStore.setState([]);
  });

  it("adds dishes, announces it and persists", () => {
    const heard = vi.fn();
    window.addEventListener(CART_ADD_EVENT, heard);

    cart.add("smoky-butter-chicken");
    cart.add("smoky-butter-chicken", { quantity: 2 });

    expect(cartStore.getState().lines).toEqual([{ dishId: "smoky-butter-chicken", quantity: 3 }]);
    expect(heard).toHaveBeenCalledTimes(2);
    expect(toastStore.getState().at(-1)).toMatchObject({ title: "Added to your cart", description: "Smoky Butter Chicken" });
    expect(JSON.parse(window.localStorage.getItem("jango.cart.v1") ?? "{}").lines).toHaveLength(1);

    window.removeEventListener(CART_ADD_EVENT, heard);
  });

  it("ignores unknown dishes and can add silently", () => {
    cart.add("mystery-meat");
    cart.add("warm-gulab-jamun", { silent: true });
    expect(cartStore.getState().lines).toEqual([{ dishId: "warm-gulab-jamun", quantity: 1 }]);
    expect(toastStore.getState()).toHaveLength(0);
  });

  it("stops at the per-dish limit with a friendly message", () => {
    cart.add("warm-gulab-jamun", { quantity: 20, silent: true });
    cart.add("warm-gulab-jamun");
    expect(cartStore.getState().lines[0].quantity).toBe(20);
    expect(toastStore.getState().at(-1)?.title).toContain("limit");
  });

  it("changes quantities and removes lines", () => {
    cart.add("warm-gulab-jamun", { silent: true });
    cart.setQuantity("warm-gulab-jamun", 4);
    expect(cartStore.getState().lines[0].quantity).toBe(4);
    cart.setQuantity("warm-gulab-jamun", 0);
    expect(cartStore.getState().lines).toEqual([]);
  });

  it("only accepts coupons the order qualifies for", () => {
    expect(cart.applyCoupon("")).toEqual({ ok: false, message: "Enter a coupon code." });
    expect(cart.applyCoupon("nope")).toEqual({ ok: false, message: "That code isn’t valid." });

    cart.add("steamed-chicken-momos", { silent: true }); // ₹149
    expect(cart.applyCoupon("jango20")).toEqual({ ok: false, message: "Add ₹250 more to use JANGO20." });
    expect(cartStore.getState().couponCode).toBeNull();

    cart.add("smoky-butter-chicken", { silent: true }); // ₹478 in total
    expect(cart.applyCoupon("jango20")).toEqual({ ok: true, message: "JANGO20 applied — you save ₹96." });
    expect(cartStore.getState().couponCode).toBe("JANGO20");

    cart.removeCoupon();
    expect(cartStore.getState().couponCode).toBeNull();
  });
});

describe("customer stores", () => {
  beforeEach(() => {
    favoritesStore.setState([]);
    ordersStore.setState([]);
  });

  it("toggles favourites", () => {
    expect(toggleFavorite("classic-margherita")).toBe(true);
    expect(favoritesStore.getState()).toEqual(["classic-margherita"]);
    expect(toggleFavorite("classic-margherita")).toBe(false);
    expect(favoritesStore.getState()).toEqual([]);
  });

  it("merges profile updates", () => {
    saveProfile({ name: "Ananya", phone: "9876543210" });
    saveProfile({ address: "12 Station Road" });
    expect(profileStore.getState()).toMatchObject({ name: "Ananya", phone: "9876543210", address: "12 Station Road" });
  });

  it("keeps the ten most recent orders, newest first, without duplicates", () => {
    const order = (id: string): Order => ({
      id,
      placedAt: "2026-11-11T12:00:00Z",
      fulfilment: "delivery",
      payment: "upi",
      customer: { name: "Test", phone: "9876543210" },
      lines: [],
      totals: { itemCount: 0, subtotal: 0, discount: 0, deliveryFee: 0, tax: 0, total: 0 },
      couponCode: null,
      etaMinutes: 30,
    });
    for (let index = 1; index <= 12; index += 1) rememberOrder(order(`JG-${index}`));
    rememberOrder(order("JG-12"));
    const ids = ordersStore.getState().map((entry) => entry.id);
    expect(ids).toHaveLength(10);
    expect(ids[0]).toBe("JG-12");
    expect(new Set(ids).size).toBe(10);
  });
});

describe("ui + toasts", () => {
  it("opens one overlay at a time", () => {
    ui.open("cart");
    expect(uiStore.getState().overlay).toBe("cart");
    ui.openQuickView("classic-margherita");
    expect(uiStore.getState()).toEqual({ overlay: "quick-view", quickViewId: "classic-margherita" });
    ui.toggle("search");
    expect(uiStore.getState().overlay).toBe("search");
    ui.toggle("search");
    expect(uiStore.getState().overlay).toBeNull();
    ui.close();
    expect(uiStore.getState().overlay).toBeNull();
  });

  it("shows at most three toasts and dismisses them on a timer", () => {
    vi.useFakeTimers();
    toastStore.setState([]);
    const ids = [1, 2, 3, 4].map((n) => showToast({ title: `Toast ${n}` }));
    expect(toastStore.getState().map((toast) => toast.title)).toEqual(["Toast 2", "Toast 3", "Toast 4"]);
    dismissToast(ids[3]);
    expect(toastStore.getState()).toHaveLength(2);
    vi.advanceTimersByTime(4000);
    expect(toastStore.getState()).toHaveLength(0);
    vi.useRealTimers();
  });
});
