# Structure first — Jango Restaurant & Bar

This project was built with the **“structure before you build”** method: map the
whole site, lock the design system, fix the data shapes, and only then build one
section at a time. This file _is_ that structure. Every screen inherits from it;
none of them redefines colours, type or data on its own.

> **Rule of thumb:** if a change doesn't reference the map (§1), the design
> system (§2) and the data shapes (§3), stop — that is where drift starts.

---

## 1 · The map

### Pages

| Route              | Purpose                                          | Rendering            |
| ------------------ | ------------------------------------------------ | -------------------- |
| `/`                | Home — every marketing section, in order         | static               |
| `/menu`            | Full menu: category chips, search, veg-only, sort | static               |
| `/menu/[category]` | One page per category (10), own title + schema   | static (all prebuilt) |
| `/checkout`        | Cart review → details → payment → confirmation   | static shell + client |
| `/privacy`, `/terms` | Legal                                          | static               |
| `not-found`, `error` | Friendly 404 / error boundary                  | —                    |
| `/api/*`           | `contact`, `newsletter`, `reservations`, `orders` | on demand (POST)     |
| metadata           | `sitemap.xml`, `robots.txt`, `manifest.webmanifest`, icons, OG image | static |

### Home page sections (top → bottom)

| #  | Section            | Anchor          | Component                         |
| -- | ------------------ | --------------- | --------------------------------- |
| 0  | Announcement bar + sticky header | —  | `layout/announcement-bar`, `layout/header` |
| 1  | Hero               | —               | `sections/hero`                   |
| 2  | Trust features (8) | —               | `sections/trust-features`         |
| 3  | Food categories (10) | `#categories` | `sections/categories`             |
| 4  | Popular dishes     | `#popular`      | `sections/popular-dishes`         |
| 5  | Promotional banner | `#offers`       | `sections/promo-banner`           |
| 6  | Why choose us + counters | `#about`  | `sections/why-choose-us`          |
| 7  | How it works (4 steps) | `#how-it-works` | `sections/how-it-works`       |
| 8  | The bar (dine-in)  | `#bar`          | `sections/bar-showcase`           |
| 9  | Testimonials       | `#reviews`      | `sections/testimonials`           |
| 10 | Gallery + lightbox | `#gallery`      | `sections/gallery`                |
| 11 | Mobile app         | `#app`          | `sections/app-promo`              |
| 12 | FAQ                | `#faq`          | `sections/faq`                    |
| 13 | Newsletter         | `#newsletter`   | `sections/newsletter`             |
| 14 | Contact + map      | `#contact`      | `sections/contact`                |
| 15 | Footer             | —               | `layout/footer`                   |

### Site-wide overlays (one open at a time — `stores/ui.ts`)

`cart` drawer · `search` dialog (`/` or `Ctrl/⌘ K`) · `quick-view` dialog ·
`account` sheet (favourites, orders, saved details) · `reservation` dialog ·
`nav` (mobile menu). Each is its own lazily loaded chunk.

### How things connect

```
Header ─┬─ Menu ───────────────► /menu ─► /menu/[category]
        ├─ Categories ▾ ───────► /menu/[category]
        ├─ Offers / Bar / About / Contact ─► /#section (smooth scroll on home)
        ├─ Search ─► dish ─► quick view ─► add to cart
        ├─ Account ─► favourites · orders (reorder) · saved details
        └─ Cart ─► /checkout ─► POST /api/orders ─► confirmation + tracker

Any dish (card, row, search result, hero) ─► quick view ─► cart
Book a table (hero, bar, contact, footer, mobile menu) ─► reservation dialog ─► POST /api/reservations
```

---

## 2 · The design system

All tokens live in **`src/app/globals.css`** (`@theme`). Components use the
tokens — never raw hex values.

### Colour

| Token                 | Value     | Use                                               |
| --------------------- | --------- | ------------------------------------------------- |
| `brand-500`           | `#F97316` | Primary: fills, buttons, highlights               |
| `brand-600`           | `#EA580C` | Large text and icons on light surfaces (3.5:1)    |
| `brand-700`           | `#C2410C` | Small text and links on light surfaces (5.2:1)    |
| `ink`                 | `#111827` | Deep charcoal: headings, dark surfaces            |
| `ink-soft`            | `#1F2937` | Body text                                         |
| `ink-muted` / `ink-subtle` | `#4B5563` / `#6B7280` | Secondary / tertiary text            |
| `canvas`              | `#FFFDF9` | Page background                                   |
| `cream`               | `#FFF7ED` | Accent surface                                    |
| `line`                | `#E5E7EB` | Hairlines                                         |
| `field`               | `#8E95A1` | Form-control borders (3:1 on white)               |
| `success` / `success-ink` | `#22C55E` / `#15803D` | Status fill / status text             |

**Accessibility decision:** white on `#F97316` is only 2.8:1, so text on the
brand colour is always **charcoal** (6.3:1). That is why primary buttons are
orange with dark text.

Gradients are used sparingly: hero glow, promo banner, app panel, newsletter box.

### Type

| Role            | Utility           | Size                         | Face            |
| --------------- | ----------------- | ---------------------------- | --------------- |
| Hero heading    | `text-hero`       | 40 → 72px, 800               | Manrope         |
| Section heading | `text-section`    | 32 → 48px, 800               | Manrope         |
| Card title      | `text-card-title` | 20 → 22px, 700               | Manrope         |
| Lead paragraph  | `text-lead`       | 16 → 18px                    | Inter           |
| Body            | —                 | 16px / 1.65                  | Inter           |
| Eyebrow         | `eyebrow`         | 13px, 700, +0.14em, caps     | Manrope         |
| Buttons         | `buttonStyles()`  | 14–16px, medium, pill        | Inter           |

### Shape, depth, motion

- **Radius:** `rounded-tile` 20px · `rounded-card` 24px · `rounded-panel` 28px · feature panels 32px · buttons are pills.
- **Shadow:** `shadow-soft` → `shadow-card` → `shadow-lift` (hover) · `shadow-float` (floating cards) · `shadow-glow` (primary buttons).
- **Spacing:** `container-site` (max 1440px, 20/32/48px gutters) · `section-y` (72/88/120px).
- **Easing:** `ease-out-expo` for almost everything; `ease-spring` for pops.
- **Motion rules:** transforms and opacity only; everything honours `prefers-reduced-motion`; nothing is hidden without JavaScript.

### Shared components (`src/components/ui`)

`Button / ButtonLink / buttonStyles` · `Modal` (focus trap, Esc, scroll lock, inert page) ·
`SectionHeading` · `Eyebrow` · `Rating` · `Stars` · `DietMark` · `SpiceMeter` · `Price` ·
`DishTagBadge` · `Field` + `inputStyles` · `Icon` · `Logo` · `Magnetic` · `Counter` ·
`OpenStatus` · `SectionLink` · `Toaster` · `NewsletterForm` · `CouponCopy`.

Dish UI lives in `src/components/menu` (`DishCard`, `DishRow`, `DishTile`,
`AddToCartButton`, `FavoriteButton`, `QuantityStepper`, `MenuExplorer`).

### Animation toolkit

| Need                         | Tool                                                        |
| ---------------------------- | ----------------------------------------------------------- |
| Smooth scrolling             | Lenis, driven by GSAP's ticker (`providers/scroll-engine`)  |
| Scroll reveals, stagger      | GSAP ScrollTrigger via `data-reveal="up\|left\|right\|scale\|fade"` |
| Parallax / spin / wipe       | `data-parallax`, `data-spin`, `data-wipe` (same engine)     |
| Overlays, accordion, lists   | Framer Motion (`m.*` + `LazyMotion`, features loaded lazily) |
| Ripple                       | `data-ripple` (event delegation, `providers/interaction-effects`) |
| Magnetic buttons, counters   | `Magnetic`, `Counter`                                       |
| Floating elements            | CSS keyframes (`animate-float`, `animate-drift`, …)         |
| Page transitions             | `app/template.tsx`                                          |

---

## 3 · The data shapes

Defined once in **`src/types/index.ts`**. Every screen speaks this vocabulary.

```ts
Category  { slug, name, tagline, description, icon, image?, imageAlt? }
Dish      { id, name, category, description, details, price, compareAtPrice?,
            rating, ratingCount, diet, spice, prepMinutes, serves, calories,
            tags[], image?, imageAlt?, popularRank? }
CartLine  { dishId, quantity }                     // the cart only stores ids
CartState { lines: CartLine[], couponCode }
Coupon    { code, title, description, kind: "percent" | "flat", value, minSubtotal, maxDiscount? }
CartTotals{ itemCount, subtotal, discount, deliveryFee, tax, total,
            freeDeliveryRemaining, freeDeliveryProgress, appliedCoupon, couponError }
Order     { id, placedAt, fulfilment, payment, customer, lines: OrderLine[],
            totals, couponCode, etaMinutes }
```

Rules that keep the data honest:

- **Money is whole rupees** (integers). Formatting is `formatINR()` — identical on server and client.
- **One source of truth:** `src/config/site.ts` (brand, contact, hours, delivery policy, coupons), `src/data/*` (menu and content).
- **Derived, never duplicated:** category counts, totals and "popular dishes" are computed from the menu.
- **Prices are computed in one place** (`lib/cart.ts`) — used by the UI _and_ by `/api/orders`, which re-prices every order from dish ids.
- **Optional images:** a `Dish`, `Category` or `Cocktail` without an `image` falls back to a designed, photo-less variant. Adding the image upgrades it automatically.

### State

| Store (`src/stores`) | Persisted            | Holds                              |
| -------------------- | -------------------- | ---------------------------------- |
| `cartStore`          | `jango.cart.v1`      | lines + coupon                     |
| `favoritesStore`     | `jango.favorites.v1` | dish ids                           |
| `profileStore`       | `jango.profile.v1`   | name, phone, address (this device) |
| `ordersStore`        | `jango.orders.v1`    | last 10 orders                     |
| `uiStore`            | —                    | which overlay is open              |
| `toastStore`         | —                    | notifications                      |

Stores are tiny external stores read with `useSyncExternalStore`; the server and
the hydration pass always see the empty state, so there are no hydration mismatches.

---

## 4 · Build order

1. Tokens (`globals.css`) → types → `config/site.ts` → `data/*`
2. Pure logic (`lib/*`) with unit tests
3. Primitives (`components/ui`) → dish components → overlays
4. Layout (header, footer) → sections, one at a time, in the order of §1
5. Pages → API routes → SEO files
6. End-to-end tests, accessibility scan, responsive sweep

When adding a screen: place it in §1, build it from §2, feed it from §3.
