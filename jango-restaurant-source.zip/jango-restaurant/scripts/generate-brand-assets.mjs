#!/usr/bin/env node
/**
 * Renders the brand assets that are derived from the logo and the hero cut-outs:
 *
 *   src/app/icon.svg                 favicon (vector)
 *   src/app/apple-icon.png           180×180 touch icon
 *   src/app/opengraph-image.jpg      1200×630 social share image
 *   public/icons/icon-{192,512}.png  PWA icons (+ maskable)
 *
 * Run with:  node scripts/generate-brand-assets.mjs   (needs Playwright's Chromium)
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { chromium } from "@playwright/test";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const asset = (file) => `data:image/webp;base64,${readFileSync(resolve(root, "src/assets/images/cutouts", file)).toString("base64")}`;

/** The Jango mark. `inset` adds safe-zone padding for maskable icons. */
const mark = ({ rounded = true, inset = 0 } = {}) => {
  const scale = 1 - inset * 2;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <rect width="48" height="48" rx="${rounded ? 15 : 0}" fill="#F97316"/>
  <g transform="translate(${24 * (1 - scale)} ${24 * (1 - scale)}) scale(${scale})">
    <path d="M28.9 6.6c3.2 2.7 4.9 5.3 4.9 7.8a5 5 0 0 1-10 0c0-1.7.7-3.3 2-4.7.3 1.1.9 1.9 1.7 2.4-.2-2.1.3-3.9 1.4-5.5Z" fill="#111827"/>
    <path d="M28.8 23v9.6A8.4 8.4 0 0 1 20.4 41h-2.6" fill="none" stroke="#111827" stroke-width="5.8" stroke-linecap="round"/>
  </g>
</svg>`;
};

const browser = await chromium.launch();

async function renderIcon(file, size, svg) {
  const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
  await page.setContent(`<style>*{margin:0}svg{display:block;width:${size}px;height:${size}px}</style>${svg}`);
  mkdirSync(dirname(resolve(root, file)), { recursive: true });
  await page.screenshot({ path: resolve(root, file), omitBackground: true });
  await page.close();
  console.log(`✓ ${file}`);
}

writeFileSync(resolve(root, "src/app/icon.svg"), `${mark()}\n`);
console.log("✓ src/app/icon.svg");

await renderIcon("src/app/apple-icon.png", 180, mark({ rounded: false }));
await renderIcon("public/icons/icon-192.png", 192, mark());
await renderIcon("public/icons/icon-512.png", 512, mark());
await renderIcon("public/icons/icon-maskable-512.png", 512, mark({ rounded: false, inset: 0.12 }));

/* ── Open Graph image ─────────────────────────────────────────────────────── */
const og = await browser.newPage({ viewport: { width: 1200, height: 630 }, deviceScaleFactor: 1 });
await og.setContent(`<!doctype html>
<html>
<head>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700;800&family=Inter:wght@500;600&display=swap" rel="stylesheet">
<style>
  * { margin: 0; box-sizing: border-box; }
  body { width: 1200px; height: 630px; overflow: hidden; position: relative; background: #FFFDF9; font-family: Inter, sans-serif; color: #111827; }
  .glow { position: absolute; right: -170px; top: -150px; width: 860px; height: 860px; border-radius: 50%; background: radial-gradient(closest-side, rgba(253,186,116,.75), rgba(255,237,213,.55) 60%, transparent); }
  .stage { position: absolute; right: -40px; top: 55px; width: 560px; height: 560px; border-radius: 50%; background: linear-gradient(135deg, #FED7AA, #FFF7ED 55%, #fff); }
  .ring { position: absolute; right: -72px; top: 23px; width: 624px; height: 624px; border-radius: 50%; border: 2px dashed rgba(249,115,22,.45); }
  img { position: absolute; }
  .dish { right: 10px; top: 105px; width: 460px; filter: drop-shadow(0 28px 30px rgba(17,24,39,.3)); }
  .biryani { right: 372px; top: 398px; width: 205px; filter: drop-shadow(0 16px 18px rgba(17,24,39,.3)); }
  .pizza { right: -62px; top: -48px; width: 215px; filter: drop-shadow(0 16px 18px rgba(17,24,39,.3)); }
  .basil { right: 442px; top: 62px; width: 96px; transform: rotate(-14deg); }
  .chili { right: 262px; top: 536px; width: 72px; transform: rotate(28deg); }
  .lime { right: 250px; top: 34px; width: 64px; }
  .copy { position: absolute; left: 72px; top: 0; bottom: 0; width: 600px; display: flex; flex-direction: column; justify-content: center; }
  .brand { display: flex; align-items: center; gap: 16px; }
  .brand svg { width: 68px; height: 68px; filter: drop-shadow(0 10px 16px rgba(249,115,22,.4)); }
  .name { font: 800 44px/1 Manrope, sans-serif; letter-spacing: -0.04em; }
  .tag { margin-top: 7px; font: 700 13px/1 Manrope, sans-serif; letter-spacing: .22em; text-transform: uppercase; color: #6B7280; }
  h1 { margin-top: 44px; font: 800 70px/1.04 Manrope, sans-serif; letter-spacing: -0.035em; }
  h1 span { color: #EA580C; }
  p { margin-top: 26px; font-size: 25px; font-weight: 500; line-height: 1.45; color: #4B5563; }
  .pills { margin-top: 34px; display: flex; gap: 12px; }
  .pill { height: 48px; padding: 0 22px; border-radius: 999px; display: flex; align-items: center; font: 700 19px/1 Manrope, sans-serif; }
  .pill.dark { background: #111827; color: #fff; }
  .pill.brand { background: #F97316; color: #111827; }
</style>
</head>
<body>
  <div class="glow"></div><div class="stage"></div><div class="ring"></div>
  <img class="pizza" src="${asset("pizza.webp")}">
  <img class="dish" src="${asset("butter-chicken.webp")}">
  <img class="biryani" src="${asset("biryani.webp")}">
  <img class="basil" src="${asset("basil.webp")}">
  <img class="lime" src="${asset("lime.webp")}">
  <img class="chili" src="${asset("chili.webp")}">
  <div class="copy">
    <div class="brand">${mark()}<div><div class="name">Jango</div><div class="tag">Restaurant &amp; Bar</div></div></div>
    <h1>Fresh off the <span>flame,</span> straight to your door.</h1>
    <p>Tandoori, biryani, Indo-Chinese &amp; more<br>NH12, Dhubulia · Open 11 AM – 11 PM</p>
    <div class="pills"><div class="pill brand">Order online</div><div class="pill dark">Book a table</div></div>
  </div>
</body>
</html>`);
await og.evaluate(() => document.fonts.ready);
await og.waitForTimeout(400);
await og.screenshot({ path: resolve(root, "src/app/opengraph-image.jpg"), type: "jpeg", quality: 88 });
writeFileSync(
  resolve(root, "src/app/opengraph-image.alt.txt"),
  "Jango Restaurant & Bar — smoky butter chicken, biryani and pizza beside the words “Fresh off the flame, straight to your door.”\n",
);
console.log("✓ src/app/opengraph-image.jpg");

await browser.close();
