#!/usr/bin/env node
/**
 * Visual QA helper: scrolls a page from top to bottom (so lazy images load and
 * scroll animations play), then saves it as a series of viewport-sized slices.
 *
 *   node scripts/screenshot.mjs --url http://localhost:3000 --out /tmp/shots --name home \
 *        --width 1440 --height 900 [--mobile] [--scale 1] [--max 20]
 */
import { mkdirSync } from "node:fs";
import { parseArgs } from "node:util";

import { chromium, devices } from "@playwright/test";

const { values } = parseArgs({
  options: {
    url: { type: "string", default: "http://localhost:3000" },
    out: { type: "string", default: "/tmp/shots" },
    name: { type: "string", default: "page" },
    width: { type: "string", default: "1440" },
    height: { type: "string", default: "900" },
    scale: { type: "string", default: "1" },
    max: { type: "string", default: "30" },
    mobile: { type: "boolean", default: false },
    reduced: { type: "boolean", default: false },
  },
});

const width = Number(values.width);
const height = Number(values.height);
mkdirSync(values.out, { recursive: true });

const browser = await chromium.launch();
const context = await browser.newContext({
  ...(values.mobile ? devices["Pixel 7"] : {}),
  viewport: { width, height },
  deviceScaleFactor: Number(values.scale),
  reducedMotion: values.reduced ? "reduce" : "no-preference",
});
const page = await context.newPage();

const problems = [];
page.on("console", (message) => {
  if (message.type() === "error") problems.push(`console: ${message.text()}`);
});
page.on("pageerror", (error) => problems.push(`pageerror: ${error.message}`));
page.on("requestfailed", (request) => {
  const url = request.url();
  if (!url.includes("google.com") && !url.includes("gstatic.com")) problems.push(`failed: ${url}`);
});

await page.goto(values.url, { waitUntil: "networkidle" });
await page.waitForTimeout(1200);

const total = await page.evaluate(() => document.documentElement.scrollHeight);
const slices = Math.min(Number(values.max), Math.ceil(total / height));

for (let index = 0; index < slices; index += 1) {
  const y = Math.min(index * height, Math.max(0, total - height));
  // Scroll in a few steps, like a person would, so ScrollTrigger sees the journey.
  for (let step = 1; step <= 3; step += 1) {
    await page.evaluate((top) => window.scrollTo({ top, behavior: "instant" }), y - height + (height * step) / 3);
    await page.waitForTimeout(140);
  }
  await page.waitForTimeout(950);
  const file = `${values.out}/${values.name}-${String(index + 1).padStart(2, "0")}.jpg`;
  await page.screenshot({ path: file, type: "jpeg", quality: 80 });
}

const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
console.log(JSON.stringify({ url: values.url, width, height, pageHeight: total, slices, horizontalOverflow: overflow, problems: problems.slice(0, 12) }, null, 2));

await browser.close();
