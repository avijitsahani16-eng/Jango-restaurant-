#!/usr/bin/env python3
"""
Image pipeline for the Jango website.

Turns the raw AI-generated photographs in ../raw-images into the optimised,
web-ready assets that live in src/assets/images:

  1. cut-outs      – plates / ingredients shot on white become transparent WebP
  2. photographs   – resized, colour-safe progressive JPEGs
  3. compositions  – original flat-lays built from the cut-outs

Run:  python3 scripts/process_images.py [--raw ../raw-images]
Requires: pillow, numpy, scipy
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage as ndi

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "src" / "assets" / "images"


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def load_rgb(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB")).astype(np.float32)


def disk(radius: int) -> np.ndarray:
    y, x = np.ogrid[-radius : radius + 1, -radius : radius + 1]
    return (x * x + y * y) <= radius * radius


def decontaminate(rgb: np.ndarray, solid: np.ndarray) -> np.ndarray:
    """Replace the colour of every non-solid pixel with its nearest solid pixel.

    Removes the white fringe that anti-aliased edges pick up from the studio
    backdrop, so the cut-out stays clean on light *and* dark backgrounds.
    """
    _, (iy, ix) = ndi.distance_transform_edt(~solid, return_indices=True)
    return rgb[iy, ix]


def to_rgba(rgb: np.ndarray, alpha: np.ndarray) -> Image.Image:
    out = np.dstack([np.clip(rgb, 0, 255), np.clip(alpha * 255.0, 0, 255)]).astype(np.uint8)
    return Image.fromarray(out, "RGBA")


def crop_to_alpha(img: Image.Image, pad: int = 6) -> Image.Image:
    bbox = img.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
    if not bbox:
        return img
    l, t, r, b = bbox
    return img.crop((max(l - pad, 0), max(t - pad, 0), min(r + pad, img.width), min(b + pad, img.height)))


def fit_square(img: Image.Image) -> Image.Image:
    """Centre a cut-out on a transparent square canvas (keeps round plates round)."""
    side = max(img.size)
    canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    canvas.alpha_composite(img, ((side - img.width) // 2, (side - img.height) // 2))
    return canvas


def save_webp(img: Image.Image, path: Path, max_side: int | None = None, quality: int = 90) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if max_side and max(img.size) > max_side:
        scale = max_side / max(img.size)
        img = img.resize((round(img.width * scale), round(img.height * scale)), Image.LANCZOS)
    img.save(path, "WEBP", quality=quality, method=6, exact=False)
    print(f"  ✓ {path.relative_to(ROOT)}  {img.size[0]}×{img.size[1]}  {path.stat().st_size // 1024} KB")


def save_jpeg(img: Image.Image, path: Path, quality: int = 86) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(path, "JPEG", quality=quality, optimize=True, progressive=True, subsampling=0)
    print(f"  ✓ {path.relative_to(ROOT)}  {img.size[0]}×{img.size[1]}  {path.stat().st_size // 1024} KB")


def cover(img: Image.Image, size: tuple[int, int], focus: tuple[float, float] = (0.5, 0.5)) -> Image.Image:
    """Resize + crop to exactly `size`, keeping `focus` (0-1, 0-1) in frame."""
    tw, th = size
    scale = max(tw / img.width, th / img.height)
    resized = img.resize((math.ceil(img.width * scale), math.ceil(img.height * scale)), Image.LANCZOS)
    left = round((resized.width - tw) * focus[0])
    top = round((resized.height - th) * focus[1])
    return resized.crop((left, top, left + tw, top + th))


# --------------------------------------------------------------------------- #
# 1. cut-outs
# --------------------------------------------------------------------------- #
def cutout_plate(path: Path) -> Image.Image:
    """A dark-rimmed round plate photographed on white → transparent cut-out.

    The dark rim is a closed ring, so: threshold the dark pixels, close small
    gaps, fill the interior, keep the biggest blob, smooth, feather.
    """
    rgb = load_rgb(path)
    mx = rgb.max(axis=2)
    dark = mx < 112
    dark = ndi.binary_closing(dark, structure=disk(3))
    filled = ndi.binary_fill_holes(dark)
    lab, n = ndi.label(filled)
    if n > 1:
        sizes = ndi.sum(filled, lab, index=range(1, n + 1))
        filled = lab == (int(np.argmax(sizes)) + 1)
    # smooth the silhouette (removes shadow nibbles / tiny protrusions)
    filled = ndi.binary_opening(filled, structure=disk(5))
    filled = ndi.binary_closing(filled, structure=disk(5))
    solid = ndi.binary_erosion(filled, structure=disk(2))
    alpha = ndi.gaussian_filter(filled.astype(np.float32), 1.1)
    alpha = np.clip((alpha - 0.45) / 0.5, 0, 1)
    clean = decontaminate(rgb, solid)
    return fit_square(crop_to_alpha(to_rgba(clean, alpha), pad=4))


def add_shadow(cut: Image.Image, offset=(0.05, 0.09), blur=0.05, opacity=0.28, pad=0.22) -> Image.Image:
    """Bake a soft, natural drop shadow underneath a cut-out."""
    side = max(cut.size)
    p = round(side * pad)
    canvas = Image.new("RGBA", (cut.width + 2 * p, cut.height + 2 * p), (0, 0, 0, 0))
    a = np.asarray(cut.getchannel("A")).astype(np.float32) / 255.0
    sh = np.zeros((canvas.height, canvas.width), dtype=np.float32)
    dx, dy = round(side * offset[0]), round(side * offset[1])
    sh[p + dy : p + dy + cut.height, p + dx : p + dx + cut.width] = a
    sh = ndi.gaussian_filter(sh, side * blur) * opacity
    shadow = np.zeros((canvas.height, canvas.width, 4), dtype=np.uint8)
    shadow[..., 0], shadow[..., 1], shadow[..., 2] = 40, 24, 12  # warm shadow
    shadow[..., 3] = np.clip(sh * 255, 0, 255).astype(np.uint8)
    canvas.alpha_composite(Image.fromarray(shadow, "RGBA"))
    canvas.alpha_composite(cut, (p, p))
    return crop_to_alpha(canvas, pad=2)


def cutout_ingredients(path: Path) -> list[Image.Image]:
    """Six ingredients spaced out on white → six individual cut-outs,
    ordered row by row (top-left → bottom-right)."""
    rgb = load_rgb(path)
    mx, mn = rgb.max(axis=2), rgb.min(axis=2)
    # Ingredients are colourful, studio shadows are neutral grey: key on saturation.
    sat = mx - mn
    fg = ((sat > 26) & (sat / (mx + 1.0) > 0.17)) | (mx < 70)
    fg = ndi.binary_opening(fg, structure=disk(1))
    fg = ndi.binary_closing(fg, structure=disk(2))
    # Fill only small holes (specular highlights); bigger ones are real gaps between leaves.
    holes = ndi.binary_fill_holes(fg) & ~fg
    hole_lab, hole_n = ndi.label(holes)
    if hole_n:
        hole_sizes = ndi.sum(holes, hole_lab, index=range(1, hole_n + 1))
        small = [i + 1 for i, size in enumerate(hole_sizes) if size <= 500]
        fg = fg | np.isin(hole_lab, small)
    lab, n = ndi.label(fg)
    sizes = ndi.sum(fg, lab, index=range(1, n + 1))
    keep = [i + 1 for i, s in enumerate(sizes) if s > fg.size * 0.0025]
    boxes = ndi.find_objects(lab)
    items = []
    for idx in keep:
        sl = boxes[idx - 1]
        cy = (sl[0].start + sl[0].stop) / 2
        cx = (sl[1].start + sl[1].stop) / 2
        items.append((idx, cy, cx, sl))
    # row-major order: split on the vertical midpoint, then sort by x
    mid = rgb.shape[0] / 2
    items.sort(key=lambda t: (0 if t[1] < mid else 1, t[2]))
    out = []
    for idx, _, _, sl in items:
        pad = 10
        ys = slice(max(sl[0].start - pad, 0), min(sl[0].stop + pad, rgb.shape[0]))
        xs = slice(max(sl[1].start - pad, 0), min(sl[1].stop + pad, rgb.shape[1]))
        mask = lab[ys, xs] == idx
        solid = ndi.binary_erosion(mask, structure=disk(1))
        alpha = ndi.gaussian_filter(mask.astype(np.float32), 0.9)
        alpha = np.clip((alpha - 0.4) / 0.5, 0, 1)
        clean = decontaminate(rgb[ys, xs], solid)
        out.append(crop_to_alpha(to_rgba(clean, alpha), pad=2))
    return out


# --------------------------------------------------------------------------- #
# 3. compositions (original flat-lays built from the cut-outs)
# --------------------------------------------------------------------------- #
def backdrop(size: tuple[int, int], base=(250, 238, 219), light=(0.2, 0.1), noise=2.6, seed=7, falloff=0.1) -> Image.Image:
    """A seamless studio backdrop: soft directional light + fine paper grain."""
    w, h = size
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.hypot((xx / w - light[0]), (yy / h - light[1]))
    shade = 1.0 - falloff * np.clip(d, 0, 1.3)
    grain = ndi.gaussian_filter(rng.normal(0, 1, (h, w)).astype(np.float32), 0.8) * noise
    cloud = ndi.gaussian_filter(rng.normal(0, 1, (h, w)).astype(np.float32), 42) * 14
    img = np.stack([(c * shade) + grain + cloud for c in base], axis=2)
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB").convert("RGBA")


def place(canvas: Image.Image, cut: Image.Image, center: tuple[float, float], width: float, rotate: float = 0.0,
          shadow: bool = True, shadow_opacity: float = 0.3) -> None:
    """Paste `cut` so it is `width` (fraction of canvas width) wide, centred at `center` (fractions)."""
    target_w = max(int(canvas.width * width), 8)
    scale = target_w / cut.width
    item = cut.resize((target_w, max(int(cut.height * scale), 8)), Image.LANCZOS)
    if rotate:
        item = item.rotate(rotate, resample=Image.BICUBIC, expand=True)
    if shadow:
        item = add_shadow(item, offset=(0.035, 0.06), blur=0.045, opacity=shadow_opacity, pad=0.2)
    x = round(canvas.width * center[0] - item.width / 2)
    y = round(canvas.height * center[1] - item.height / 2)
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    layer.paste(item, (x, y), item)
    canvas.alpha_composite(layer)


def glow(canvas: Image.Image, center: tuple[float, float], radius: float, color=(249, 115, 22), strength=0.5) -> None:
    w, h = canvas.size
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.hypot(xx - w * center[0], yy - h * center[1]) / (radius * w)
    a = np.clip(1 - d, 0, 1) ** 2 * strength
    layer = np.zeros((h, w, 4), dtype=np.uint8)
    layer[..., 0], layer[..., 1], layer[..., 2] = color
    layer[..., 3] = (a * 255).astype(np.uint8)
    canvas.alpha_composite(Image.fromarray(layer, "RGBA"))


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=str(ROOT.parent / "raw-images"))
    args = ap.parse_args()
    raw = Path(args.raw)

    print("1 · cut-outs")
    plates: dict[str, Image.Image] = {}
    for name, src, side in [("butter-chicken", "hero-main.png", 1120), ("biryani", "hero-biryani.png", 720), ("pizza", "hero-pizza.png", 900)]:
        plates[name] = cutout_plate(raw / src)
        save_webp(plates[name], OUT / "cutouts" / f"{name}.webp", max_side=side)

    names = ["basil", "tomatoes", "chili", "lime", "coriander", "star-anise"]
    parts = cutout_ingredients(raw / "hero-ingredients.png")
    assert len(parts) == len(names), f"expected {len(names)} ingredients, found {len(parts)}"
    ingredients = dict(zip(names, parts))
    for name, img in ingredients.items():
        save_webp(add_shadow(img, offset=(0.04, 0.07), blur=0.05, opacity=0.26, pad=0.22), OUT / "cutouts" / f"{name}.webp", quality=92)

    print("2 · photographs")
    for name in ["butter-chicken", "chicken-biryani", "paneer-tikka", "mutton-kosha"]:
        save_jpeg(cover(Image.open(raw / f"dish-{name}.jpg"), (1200, 900)), OUT / "dishes" / f"{name}.jpg")
    pizza_photo = Image.open(raw / "cat-pizza.jpg")
    save_jpeg(cover(pizza_photo.crop((0, 0, pizza_photo.width, int(pizza_photo.height * 0.66))), (1200, 900), focus=(0.5, 0.35)), OUT / "dishes" / "tandoori-chicken-pizza.jpg")
    save_jpeg(cover(Image.open(raw / "avatar-1.jpg"), (320, 320)), OUT / "avatars" / "ananya.jpg", quality=88)

    print("3 · compositions")
    bc, br, pz = plates["butter-chicken"], plates["biryani"], plates["pizza"]
    ing = ingredients

    # Margherita — studio shot on a cream backdrop (menu card, 4:3)
    c = backdrop((1200, 900), seed=3)
    place(c, pz, (0.5, 0.52), 0.7, rotate=-18)
    place(c, ing["basil"], (0.12, 0.2), 0.13, rotate=25)
    place(c, ing["tomatoes"], (0.9, 0.2), 0.14, rotate=-12)
    place(c, ing["basil"], (0.91, 0.84), 0.1, rotate=160)
    place(c, ing["chili"], (0.1, 0.83), 0.1, rotate=70)
    save_jpeg(c, OUT / "dishes" / "margherita-pizza.jpg")

    # Fresh ingredients flat-lay (portrait 4:5)
    c = backdrop((1000, 1250), seed=11, light=(0.15, 0.05))
    place(c, bc, (0.98, 0.99), 0.9, rotate=40)
    place(c, ing["tomatoes"], (0.3, 0.2), 0.36, rotate=-8)
    place(c, ing["basil"], (0.74, 0.17), 0.3, rotate=20)
    place(c, ing["lime"], (0.2, 0.52), 0.24, rotate=0)
    place(c, ing["chili"], (0.6, 0.45), 0.27, rotate=28)
    place(c, ing["coriander"], (0.2, 0.84), 0.3, rotate=-25)
    place(c, ing["star-anise"], (0.86, 0.36), 0.15, rotate=10)
    place(c, ing["star-anise"], (0.45, 0.66), 0.11, rotate=50)
    save_jpeg(c, OUT / "lifestyle" / "fresh-ingredients.jpg")

    # The feast (portrait 4:5) — three plates, overhead
    c = backdrop((1000, 1250), seed=19, light=(0.2, 0.1))
    place(c, bc, (0.3, 0.24), 0.7, rotate=-12)
    place(c, pz, (0.87, 0.6), 0.62, rotate=24)
    place(c, br, (0.22, 0.87), 0.5, rotate=8)
    place(c, ing["coriander"], (0.84, 0.13), 0.2, rotate=18)
    place(c, ing["chili"], (0.45, 0.6), 0.15, rotate=-35)
    place(c, ing["lime"], (0.62, 0.93), 0.14)
    place(c, ing["star-anise"], (0.93, 0.3), 0.09)
    place(c, ing["basil"], (0.06, 0.55), 0.15, rotate=95)
    save_jpeg(c, OUT / "lifestyle" / "feast.jpg")

    # Biryani on dark slate (square) — moody gallery frame
    c = backdrop((1100, 1100), base=(30, 31, 37), noise=2.2, seed=23, light=(0.3, 0.2), falloff=0.3)
    glow(c, (0.5, 0.52), 0.52, strength=0.34)
    place(c, br, (0.5, 0.52), 0.7, rotate=-10, shadow_opacity=0.55)
    place(c, ing["star-anise"], (0.12, 0.16), 0.1, rotate=15, shadow_opacity=0.5)
    place(c, ing["chili"], (0.88, 0.14), 0.14, rotate=-20, shadow_opacity=0.5)
    place(c, ing["coriander"], (0.1, 0.86), 0.17, rotate=-30, shadow_opacity=0.5)
    place(c, ing["lime"], (0.9, 0.87), 0.13, shadow_opacity=0.5)
    save_jpeg(c, OUT / "gallery" / "biryani-slate.jpg")

    # Gallery crops (different framing from the menu cards)
    save_jpeg(cover(pizza_photo, (1000, 1250)), OUT / "gallery" / "pizza-pull.jpg")
    save_jpeg(cover(Image.open(raw / "dish-paneer-tikka.jpg"), (1100, 1100), focus=(0.5, 0.5)), OUT / "gallery" / "paneer-tikka.jpg")
    save_jpeg(cover(Image.open(raw / "dish-mutton-kosha.jpg"), (1000, 1250), focus=(0.42, 0.5)), OUT / "gallery" / "mutton-kosha.jpg")
    save_jpeg(cover(Image.open(raw / "dish-chicken-biryani.jpg"), (1200, 900)), OUT / "gallery" / "chicken-biryani.jpg")
    save_jpeg(cover(Image.open(raw / "dish-butter-chicken.jpg"), (1200, 800), focus=(0.5, 0.6)), OUT / "gallery" / "butter-chicken.jpg")

    print("done")


if __name__ == "__main__":
    main()
