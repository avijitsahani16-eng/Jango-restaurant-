import { Bike, ChevronRight, Leaf, Timer } from "lucide-react";
import Link from "next/link";

import { JsonLd } from "@/components/seo/json-ld";
import { Eyebrow } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { totalDishes } from "@/data/dishes";
import { formatINR } from "@/lib/format";
import { breadcrumbSchema, menuSchema } from "@/lib/schema";
import type { Category } from "@/types";

import { MenuExplorer } from "./menu-explorer";

/** Shared shell for /menu and /menu/[category]. */
export function MenuPage({ category }: { category: Category | null }) {
  const trail = [
    { name: "Home", path: "/" },
    { name: "Menu", path: "/menu" },
    ...(category ? [{ name: category.name, path: `/menu/${category.slug}` }] : []),
  ];

  const perks = [
    { icon: Timer, text: `Delivered in about ${site.delivery.averageMinutes} minutes` },
    { icon: Bike, text: `Free delivery over ${formatINR(site.delivery.freeThreshold)}` },
    { icon: Leaf, text: "Veg and non-veg clearly marked" },
  ];

  return (
    <div className="relative">
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 -top-[4.75rem] -z-10 h-[30rem] bg-gradient-to-b from-brand-100/70 via-cream/60 to-transparent" />

      <div className="container-site pb-20 pt-6 lg:pb-28 lg:pt-10">
        <nav aria-label="Breadcrumb">
          <ol className="flex flex-wrap items-center gap-1.5 text-sm text-ink-muted">
            {trail.map((item, index) => {
              const last = index === trail.length - 1;
              return (
                <li key={item.path} className="flex items-center gap-1.5">
                  {index > 0 && <ChevronRight aria-hidden="true" className="size-4 text-ink-subtle" />}
                  {last ? (
                    <span aria-current="page" className="font-semibold text-ink">
                      {item.name}
                    </span>
                  ) : (
                    <Link href={item.path} className="link-underline hover:text-ink">
                      {item.name}
                    </Link>
                  )}
                </li>
              );
            })}
          </ol>
        </nav>

        <header className="mt-7 max-w-3xl">
          <Eyebrow>{category ? category.tagline : "Order online"}</Eyebrow>
          <h1 className="text-section mt-4 text-ink">
            {category ? (
              <>
                {category.name} <span className="text-brand-600">menu</span>
              </>
            ) : (
              <>
                The full <span className="text-brand-600">menu</span>
              </>
            )}
          </h1>
          <p className="text-lead mt-4 text-ink-muted">
            {category
              ? category.description
              : `${totalDishes} dishes across ten cuisines, all cooked to order. Add what you like to the cart — we will have it at your door while it is still hot.`}
          </p>
          <ul className="mt-6 flex flex-wrap gap-2.5">
            {perks.map(({ icon: PerkIcon, text }) => (
              <li
                key={text}
                className="inline-flex h-9 items-center gap-2 rounded-full bg-white px-3.5 text-sm font-medium text-ink shadow-soft ring-1 ring-ink/[0.05]"
              >
                <PerkIcon aria-hidden="true" className="size-4 text-brand-600" />
                {text}
              </li>
            ))}
          </ul>
        </header>

        <div className="mt-9">
          <MenuExplorer category={category?.slug ?? null} />
        </div>

        <p className="mt-14 rounded-2xl bg-cream px-5 py-4 text-sm text-ink-muted">
          Prices are in Indian rupees and include all charges except GST and delivery, which are shown at checkout. Please tell us about any
          allergies when you order — our kitchen handles nuts, dairy, gluten, eggs and shellfish.
        </p>
      </div>

      <JsonLd data={[menuSchema(category ?? undefined), breadcrumbSchema(trail)]} />
    </div>
  );
}
