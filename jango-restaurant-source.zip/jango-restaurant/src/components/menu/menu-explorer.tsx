"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { Search, SearchX, X } from "lucide-react";
import Link from "next/link";
import { useId, useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { DietMark } from "@/components/ui/primitives";
import { categories } from "@/data/categories";
import { categoryCounts, dishes, totalDishes } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { pluralize } from "@/lib/format";
import { searchDishes } from "@/lib/search";
import type { Category, CategorySlug, Dish } from "@/types";

import { DishCard, DishRow } from "./dish-card";

type SortKey = "popular" | "rating" | "price-asc" | "price-desc";

const SORTS: { value: SortKey; label: string }[] = [
  { value: "popular", label: "Most popular" },
  { value: "rating", label: "Top rated" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
];

const sorters: Record<SortKey, (a: Dish, b: Dish) => number> = {
  popular: (a, b) => b.ratingCount - a.ratingCount,
  rating: (a, b) => b.rating - a.rating || b.ratingCount - a.ratingCount,
  "price-asc": (a, b) => a.price - b.price,
  "price-desc": (a, b) => b.price - a.price,
};

const chip =
  "inline-flex h-11 shrink-0 snap-start items-center gap-2 whitespace-nowrap rounded-full px-4 text-[0.9375rem] font-medium transition-[background-color,color,box-shadow] duration-300";

/**
 * The menu browser: category chips (real links, so every category has its own
 * URL), plus instant search, a veg-only switch and sorting.
 */
export function MenuExplorer({ category }: { category: CategorySlug | null }) {
  const searchId = useId();
  const [query, setQuery] = useState("");
  const [vegOnly, setVegOnly] = useState(false);
  const [sort, setSort] = useState<SortKey>("popular");

  const trimmed = query.trim();

  const groups = useMemo(() => {
    const inCategory = category ? dishes.filter((dish) => dish.category === category) : dishes;
    const matched = trimmed ? searchDishes(trimmed, inCategory, inCategory.length) : [...inCategory];
    const visible = matched.filter((dish) => !vegOnly || dish.diet === "veg");
    // A search keeps its relevance order unless the visitor picks a sort explicitly.
    const ordered = trimmed && sort === "popular" ? visible : visible.sort(sorters[sort]);

    return categories
      .filter((entry) => (category ? entry.slug === category : true))
      .map((entry) => ({ category: entry, items: ordered.filter((dish) => dish.category === entry.slug) }))
      .filter((group) => group.items.length > 0);
  }, [category, trimmed, vegOnly, sort]);

  const count = groups.reduce((sum, group) => sum + group.items.length, 0);
  const filtering = Boolean(trimmed) || vegOnly;

  const reset = () => {
    setQuery("");
    setVegOnly(false);
    setSort("popular");
  };

  return (
    <div>
      {/* ── Filter bar ───────────────────────────────────────────────── */}
      <nav
        aria-label="Menu categories"
        className="sticky top-16 z-30 -mx-5 border-t border-ink/[0.06] bg-canvas/85 px-5 pb-1.5 pt-3 backdrop-blur-xl max-lg:border-b sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12"
      >
          <ul className="no-scrollbar -mx-1 flex snap-x scroll-px-1 gap-2 overflow-x-auto px-1 py-1">
            <li>
              <Link
                href="/menu"
                scroll={false}
                aria-current={category === null ? "page" : undefined}
                className={cn(chip, category === null ? "bg-ink text-white shadow-card" : "bg-white text-ink ring-1 ring-inset ring-ink/10 hover:bg-cream")}
              >
                All
                <span className={cn("text-xs", category === null ? "text-white/75" : "text-ink-subtle")}>{totalDishes}</span>
              </Link>
            </li>
            {categories.map((entry) => {
              const active = entry.slug === category;
              return (
                <li key={entry.slug}>
                  <Link
                    href={`/menu/${entry.slug}`}
                    scroll={false}
                    aria-current={active ? "page" : undefined}
                    className={cn(chip, active ? "bg-ink text-white shadow-card" : "bg-white text-ink ring-1 ring-inset ring-ink/10 hover:bg-cream")}
                  >
                    <Icon name={entry.icon} className={cn("size-[1.125rem]", active ? "text-brand-400" : "text-brand-600")} />
                    {entry.name}
                    <span className={cn("text-xs", active ? "text-white/75" : "text-ink-subtle")}>{categoryCounts[entry.slug]}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
      </nav>

      <div className="-mx-5 px-5 pb-3 pt-3 sm:-mx-8 sm:px-8 lg:sticky lg:top-[8.375rem] lg:z-30 lg:-mx-12 lg:border-b lg:border-ink/[0.06] lg:bg-canvas/85 lg:px-12 lg:pt-1.5 lg:backdrop-blur-xl">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-0 flex-1 basis-full sm:basis-64">
            <label htmlFor={searchId} className="sr-only">
              Search {category ? "this category" : "the menu"}
            </label>
            <Search aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 size-[1.125rem] -translate-y-1/2 text-ink-subtle" />
            <input
              id={searchId}
              type="search"
              inputMode="search"
              enterKeyHint="search"
              autoComplete="off"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={category ? "Search this category…" : "Search the menu…"}
              className="h-11 w-full rounded-full border border-field bg-white pl-11 pr-11 text-base text-ink placeholder:text-ink-subtle hover:border-ink-muted focus:border-ink focus:outline-none focus:ring-4 focus:ring-brand-500/25 [&::-webkit-search-cancel-button]:hidden"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                aria-label="Clear search"
                className="absolute right-1.5 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-full text-ink-muted hover:bg-ink/[0.06] hover:text-ink"
              >
                <X aria-hidden="true" className="size-4" />
              </button>
            )}
          </div>

          <button
            type="button"
            role="switch"
            aria-checked={vegOnly}
            onClick={() => setVegOnly((value) => !value)}
            className={cn(
              "inline-flex h-11 shrink-0 items-center gap-2.5 rounded-full pl-3.5 pr-4 text-[0.9375rem] font-medium transition-[background-color,box-shadow,color] duration-300",
              vegOnly ? "bg-veg text-white" : "bg-white text-ink ring-1 ring-inset ring-ink/10 hover:bg-cream",
            )}
          >
            <DietMark diet="veg" />
            Veg only
            <span
              aria-hidden="true"
              className={cn("relative ml-0.5 h-5 w-9 rounded-full transition-colors duration-300", vegOnly ? "bg-white/30" : "bg-ink/15")}
            >
              <span
                className={cn(
                  "absolute top-0.5 size-4 rounded-full bg-white shadow-soft transition-[left] duration-300 ease-out-expo",
                  vegOnly ? "left-[1.125rem]" : "left-0.5",
                )}
              />
            </span>
          </button>

          <div className="relative min-w-0 flex-1 sm:flex-none">
            <label htmlFor={`${searchId}-sort`} className="sr-only">
              Sort dishes
            </label>
            <select
              id={`${searchId}-sort`}
              value={sort}
              onChange={(event) => setSort(event.target.value as SortKey)}
              className="h-11 w-full rounded-full border border-field bg-white pl-4 pr-9 text-[0.9375rem] font-medium text-ink hover:border-ink-muted focus:border-ink focus:outline-none focus:ring-4 focus:ring-brand-500/25 sm:w-auto"
            >
              {SORTS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <p className="mt-6 text-[0.9375rem] text-ink-muted" role="status" aria-live="polite">
        {filtering ? `${pluralize(count, "dish", "dishes")} found` : `Showing ${pluralize(count, "dish", "dishes")}`}
        {filtering && (
          <button type="button" onClick={reset} className="link-underline ml-3 font-medium text-brand-700">
            Clear filters
          </button>
        )}
      </p>

      {/* ── Results ──────────────────────────────────────────────────── */}
      {count === 0 ? (
        <div className="mx-auto flex max-w-md flex-col items-center py-20 text-center">
          <span className="grid size-20 place-items-center rounded-full bg-cream text-brand-600">
            <SearchX aria-hidden="true" className="size-9" strokeWidth={1.5} />
          </span>
          <h2 className="mt-6 font-display text-2xl font-extrabold tracking-[-0.02em] text-ink">Nothing matches that — yet</h2>
          <p className="mt-2 text-ink-muted">Try a different word, switch off “Veg only”, or browse another category.</p>
          <Button variant="dark" className="mt-7" onClick={reset}>
            Clear filters
          </Button>
        </div>
      ) : (
        <div className="mt-8 space-y-14 lg:space-y-20">
          {groups.map((group) => (
            <MenuGroup key={group.category.slug} category={group.category} items={group.items} showHeading={category === null} />
          ))}
        </div>
      )}
    </div>
  );
}

function MenuGroup({ category, items, showHeading }: { category: Category; items: Dish[]; showHeading: boolean }) {
  const withPhoto = items.filter((dish) => dish.image);
  const withoutPhoto = items.filter((dish) => !dish.image);
  const headingId = `menu-${category.slug}`;

  return (
    <section aria-labelledby={showHeading ? headingId : undefined} aria-label={showHeading ? undefined : category.name}>
      {showHeading && (
        <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="grid size-14 shrink-0 place-items-center rounded-2xl bg-cream text-brand-600 ring-1 ring-brand-200/60">
              <Icon name={category.icon} className="size-7" strokeWidth={1.75} />
            </span>
            <div>
              <h2 id={headingId} className="font-display text-[1.75rem] font-extrabold leading-tight tracking-[-0.03em] text-ink">
                {category.name}
              </h2>
              <p className="text-[0.9375rem] text-ink-muted">{category.tagline}</p>
            </div>
          </div>
          <Link href={`/menu/${category.slug}`} scroll={false} className="link-underline text-sm font-medium text-brand-700">
            Only {category.name.toLowerCase()} · {pluralize(items.length, "dish", "dishes")}
          </Link>
        </div>
      )}

      {withPhoto.length > 0 && (
        <ul className="grid gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence initial={false} mode="popLayout">
            {withPhoto.map((dish) => (
              <m.li
                key={dish.id}
                layout
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              >
                <DishCard dish={dish} sizes="(min-width: 1280px) 23vw, (min-width: 1024px) 30vw, (min-width: 640px) 46vw, 92vw" />
              </m.li>
            ))}
          </AnimatePresence>
        </ul>
      )}

      {withoutPhoto.length > 0 && (
        <ul className={cn("grid gap-4 md:grid-cols-2 lg:gap-5", withPhoto.length > 0 && "mt-5 lg:mt-6")}>
          <AnimatePresence initial={false} mode="popLayout">
            {withoutPhoto.map((dish) => (
              <m.li
                key={dish.id}
                layout
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              >
                <DishRow dish={dish} />
              </m.li>
            ))}
          </AnimatePresence>
        </ul>
      )}
    </section>
  );
}
