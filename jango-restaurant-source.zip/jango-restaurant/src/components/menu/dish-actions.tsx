"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { Eye, Heart, Plus } from "lucide-react";
import type { MouseEvent, ReactNode } from "react";

import { useStore } from "@/hooks/use-store";
import { getQuantity } from "@/lib/cart";
import { cn } from "@/lib/cn";
import { cart, cartStore } from "@/stores/cart";
import { favoritesStore, toggleFavorite } from "@/stores/customer";
import { showToast } from "@/stores/toast";
import { ui } from "@/stores/ui";
import type { Dish } from "@/types";

import { QuantityStepper } from "./quantity-stepper";

/** The photo (or tile) inside the nearest dish card — the fly-to-cart animation starts there. */
function flyOrigin(event: MouseEvent<HTMLElement>): Element | null {
  return event.currentTarget.closest("[data-fly-root]")?.querySelector("[data-fly-image]") ?? null;
}

/* ── Add to cart ─────────────────────────────────────────────────────────── */
export function AddToCartButton({ dish, size = "md", className }: { dish: Pick<Dish, "id" | "name">; size?: "sm" | "md"; className?: string }) {
  const quantity = useStore(cartStore, (state) => getQuantity(state.lines, dish.id));
  const height = size === "sm" ? "h-9" : "h-11";

  return (
    <div className={cn("relative flex justify-end", height, className)}>
      <AnimatePresence mode="popLayout" initial={false}>
        {quantity === 0 ? (
          <m.button
            key="add"
            type="button"
            data-ripple=""
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.22 }}
            whileTap={{ scale: 0.94 }}
            aria-label={`Add ${dish.name} to cart`}
            onClick={(event) => cart.add(dish.id, { origin: flyOrigin(event) })}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full bg-brand-500 font-medium text-ink shadow-glow transition-colors duration-300 hover:bg-brand-400",
              height,
              size === "sm" ? "px-4 text-sm" : "px-5 text-[0.9375rem]",
            )}
          >
            <Plus aria-hidden="true" className="size-4" strokeWidth={2.5} />
            Add
          </m.button>
        ) : (
          <m.div
            key="stepper"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.22 }}
          >
            <QuantityStepper quantity={quantity} label={dish.name} size={size} onChange={(next) => cart.setQuantity(dish.id, next)} />
          </m.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** Icon-only "add" for tight spaces (hero card, compact lists). */
export function QuickAddButton({ dish, className }: { dish: Pick<Dish, "id" | "name">; className?: string }) {
  return (
    <button
      type="button"
      data-ripple=""
      onClick={(event) => cart.add(dish.id, { origin: flyOrigin(event) })}
      aria-label={`Add ${dish.name} to cart`}
      className={cn(
        "grid size-10 shrink-0 place-items-center rounded-full bg-brand-500 text-ink shadow-glow transition-[background-color,scale] duration-300 hover:bg-brand-400 active:scale-90",
        className,
      )}
    >
      <Plus aria-hidden="true" className="size-5" strokeWidth={2.5} />
    </button>
  );
}

/* ── Favourite ───────────────────────────────────────────────────────────── */
export function FavoriteButton({ dish, className, tone = "glass" }: { dish: Pick<Dish, "id" | "name">; className?: string; tone?: "glass" | "outline" }) {
  const active = useStore(favoritesStore, (ids) => ids.includes(dish.id));

  const onClick = () => {
    const added = toggleFavorite(dish.id);
    showToast({
      tone: "info",
      title: added ? "Saved to favourites" : "Removed from favourites",
      description: dish.name,
      action: added ? { label: "View", onClick: () => ui.open("account") } : undefined,
    });
  };

  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      aria-label={active ? `Remove ${dish.name} from favourites` : `Save ${dish.name} to favourites`}
      className={cn(
        "inline-grid size-11 place-items-center rounded-full transition-[background-color,scale] duration-300 ease-out-expo active:scale-90",
        tone === "glass" ? "glass shadow-soft hover:bg-white" : "bg-white ring-1 ring-inset ring-ink/15 hover:bg-cream",
        className,
      )}
    >
      <Heart
        key={active ? "on" : "off"}
        aria-hidden="true"
        className={cn("size-5", active ? "animate-pop fill-danger text-danger" : "text-ink")}
      />
    </button>
  );
}

/* ── Quick view triggers ─────────────────────────────────────────────────── */
/** Text button (usually the dish name). Keyboard and touch users open the quick view here. */
export function QuickViewTrigger({ dishId, className, children }: { dishId: string; className?: string; children: ReactNode }) {
  return (
    <button type="button" onClick={() => ui.openQuickView(dishId)} className={className}>
      {children}
    </button>
  );
}

/** Covers the photo; slides a "Quick view" pill up on hover. Mouse-only duplicate of the title button. */
export function QuickViewOverlay({ dishId }: { dishId: string }) {
  return (
    <button
      type="button"
      tabIndex={-1}
      aria-hidden="true"
      onClick={() => ui.openQuickView(dishId)}
      className="absolute inset-0 z-[1] flex cursor-pointer items-end justify-center p-3"
    >
      <span className="glass inline-flex h-10 translate-y-[160%] items-center gap-2 rounded-full px-4 text-sm font-medium text-ink opacity-0 shadow-soft transition-[translate,opacity] duration-500 ease-out-expo group-hover:translate-y-0 group-hover:opacity-100">
        <Eye className="size-4" />
        Quick view
      </span>
    </button>
  );
}
