"use client";

import { Minus, Plus, Trash2 } from "lucide-react";

import { MAX_QUANTITY } from "@/lib/cart";
import { cn } from "@/lib/cn";

interface QuantityStepperProps {
  quantity: number;
  onChange: (quantity: number) => void;
  /** What is being counted, for screen readers: "Smoky Butter Chicken". */
  label: string;
  min?: number;
  max?: number;
  size?: "sm" | "md";
  tone?: "brand" | "neutral";
  /** Show a bin instead of a minus when the next step removes the item. */
  removable?: boolean;
  className?: string;
}

export function QuantityStepper({
  quantity,
  onChange,
  label,
  min = 0,
  max = MAX_QUANTITY,
  size = "md",
  tone = "brand",
  removable = false,
  className,
}: QuantityStepperProps) {
  const willRemove = removable && quantity <= 1;
  const button = cn(
    "inline-grid place-items-center rounded-full transition-[background-color,scale] duration-200 active:scale-90 disabled:opacity-40",
    size === "sm" ? "size-9" : "size-11",
    tone === "brand" ? "hover:bg-ink/10" : "hover:bg-ink/[0.07]",
  );

  return (
    <div
      role="group"
      aria-label={`Quantity of ${label}`}
      className={cn(
        "inline-flex items-center rounded-full text-ink",
        tone === "brand" ? "bg-brand-500 shadow-glow" : "bg-white ring-1 ring-inset ring-ink/15",
        className,
      )}
    >
      <button
        type="button"
        className={button}
        onClick={() => onChange(quantity - 1)}
        disabled={quantity <= min}
        aria-label={willRemove ? `Remove ${label} from cart` : `Decrease quantity of ${label}`}
      >
        {willRemove ? <Trash2 aria-hidden="true" className="size-4" /> : <Minus aria-hidden="true" className="size-4" />}
      </button>
      <span
        aria-live="polite"
        aria-atomic="true"
        className={cn("min-w-7 text-center font-display font-bold tabular-nums", size === "sm" ? "text-sm" : "text-base")}
      >
        <span className="sr-only">Quantity: </span>
        {quantity}
      </span>
      <button
        type="button"
        className={button}
        onClick={() => onChange(quantity + 1)}
        disabled={quantity >= max}
        aria-label={`Increase quantity of ${label}`}
      >
        <Plus aria-hidden="true" className="size-4" />
      </button>
    </div>
  );
}
