import Image from "next/image";

import { Icon } from "@/components/ui/icon";
import { DietMark, DishTagBadge, Price, Rating } from "@/components/ui/primitives";
import { getCategory } from "@/data/categories";
import { cn } from "@/lib/cn";
import type { Dish } from "@/types";

import { AddToCartButton, FavoriteButton, QuickViewOverlay, QuickViewTrigger } from "./dish-actions";

const CARD_SIZES = "(min-width: 1280px) 30vw, (min-width: 640px) 46vw, 92vw";

/**
 * Premium product card for dishes that have a photograph.
 * Server-rendered shell with small client islands for the interactive bits.
 */
export function DishCard({ dish, className, sizes = CARD_SIZES, eager = false }: { dish: Dish; className?: string; sizes?: string; eager?: boolean }) {
  const category = getCategory(dish.category);
  if (!dish.image) return <DishRow dish={dish} className={className} />;

  return (
    <article
      data-fly-root=""
      className={cn(
        "group relative flex h-full flex-col rounded-card bg-white p-2 shadow-card ring-1 ring-ink/[0.04] transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1.5 hover:shadow-lift",
        className,
      )}
    >
      <div className="relative aspect-[4/3] overflow-hidden rounded-[1.125rem] bg-cream">
        <Image
          data-fly-image=""
          src={dish.image}
          alt={dish.imageAlt ?? dish.name}
          fill
          sizes={sizes}
          placeholder="blur"
          loading={eager ? "eager" : "lazy"}
          className="object-cover transition-transform duration-[900ms] ease-out-expo group-hover:scale-110"
        />
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/25 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

        <QuickViewOverlay dishId={dish.id} />

        {dish.tags.length > 0 && (
          <div className="pointer-events-none absolute left-3 top-3 z-[2] flex flex-wrap gap-1.5">
            {dish.tags.slice(0, 1).map((tag) => (
              <DishTagBadge key={tag} tag={tag} />
            ))}
          </div>
        )}
        <FavoriteButton dish={dish} className="absolute right-2.5 top-2.5 z-[2]" />
      </div>

      <div className="flex flex-1 flex-col px-3.5 pb-3.5 pt-4">
        <div className="flex items-center justify-between gap-3">
          <span className="flex min-w-0 items-center gap-2 text-sm text-ink-muted">
            <DietMark diet={dish.diet} />
            <span className="truncate">{category?.name}</span>
          </span>
          <Rating value={dish.rating} count={dish.ratingCount} />
        </div>

        <h3 className="text-card-title mt-2.5">
          <QuickViewTrigger
            dishId={dish.id}
            className="rounded-md text-left transition-colors duration-300 hover:text-brand-700"
          >
            {dish.name}
          </QuickViewTrigger>
        </h3>
        <p className="mt-2 line-clamp-2 text-[0.9375rem] leading-relaxed text-ink-muted">{dish.description}</p>

        <div className="mt-auto flex items-end justify-between gap-3 pt-5">
          <Price amount={dish.price} compareAt={dish.compareAtPrice} />
          <AddToCartButton dish={dish} />
        </div>
      </div>
    </article>
  );
}

/**
 * Classic menu row for dishes without a photograph —
 * the same information and actions as the card, in a compact line.
 */
export function DishRow({ dish, className }: { dish: Dish; className?: string }) {
  const category = getCategory(dish.category);

  return (
    <article
      data-fly-root=""
      className={cn(
        "group relative flex h-full gap-4 rounded-card bg-white p-4 shadow-soft ring-1 ring-ink/[0.04] transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1 hover:shadow-card sm:p-5",
        className,
      )}
    >
      <DishTile dish={dish} className="size-14 rounded-2xl sm:size-16" iconClassName="size-6 sm:size-7" fly />

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
          <DietMark diet={dish.diet} />
          <h3 className="font-display text-[1.0625rem] font-bold leading-snug tracking-[-0.01em] text-ink">
            <QuickViewTrigger dishId={dish.id} className="rounded-md text-left transition-colors duration-300 hover:text-brand-700">
              {dish.name}
            </QuickViewTrigger>
          </h3>
          {dish.tags.slice(0, 1).map((tag) => (
            <DishTagBadge key={tag} tag={tag} className="h-6 px-2.5 text-[0.625rem] shadow-none" />
          ))}
        </div>
        <p className="mt-1.5 line-clamp-2 text-[0.9375rem] leading-relaxed text-ink-muted">{dish.description}</p>

        <div className="mt-auto flex flex-wrap items-center justify-between gap-x-4 gap-y-2 pt-3.5">
          <div className="flex items-center gap-3.5">
            <Price amount={dish.price} compareAt={dish.compareAtPrice} size="sm" className="[&>span:first-child]:text-lg" />
            <Rating value={dish.rating} />
            <span className="sr-only">{category?.name}</span>
          </div>
          <AddToCartButton dish={dish} size="sm" />
        </div>
      </div>
    </article>
  );
}

/** Small square thumbnail: the dish photo when there is one, otherwise its category icon. */
export function DishTile({
  dish,
  className,
  iconClassName,
  fly = false,
}: {
  dish: Pick<Dish, "image" | "name" | "category">;
  className?: string;
  iconClassName?: string;
  /** Marks the tile as the origin of the fly-to-cart animation. */
  fly?: boolean;
}) {
  const category = getCategory(dish.category);
  const flyProps = fly ? { "data-fly-image": "" } : {};

  if (dish.image) {
    return (
      <span className={cn("relative block shrink-0 overflow-hidden bg-cream", className)}>
        <Image {...flyProps} src={dish.image} alt="" fill sizes="96px" className="object-cover" />
      </span>
    );
  }

  return (
    <span
      {...flyProps}
      aria-hidden="true"
      className={cn("grid shrink-0 place-items-center bg-gradient-to-br from-brand-50 to-brand-100 text-brand-600", className)}
    >
      <Icon name={category?.icon ?? "utensils"} className={cn("size-6", iconClassName)} strokeWidth={1.75} />
    </span>
  );
}
