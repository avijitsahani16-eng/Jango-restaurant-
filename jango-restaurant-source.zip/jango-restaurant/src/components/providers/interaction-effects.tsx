"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

import { prefersReducedMotion } from "@/lib/scroll";

/**
 * Page-wide micro-interactions, attached once with event delegation so that
 * buttons rendered by Server Components get them for free.
 *
 *   data-ripple        → material-style ripple from the pointer position
 *   data-scroll-root   → looping animations inside pause while the section is off screen
 *
 * `data-offscreen` is toggled on a scroll root from outside React, and that can
 * happen before React has hydrated the page content. Every element that carries
 * `data-scroll-root` therefore also needs `suppressHydrationWarning`, otherwise
 * the extra attribute is reported as a hydration mismatch in development.
 */
export function InteractionEffects() {
  const pathname = usePathname();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) entry.target.toggleAttribute("data-offscreen", !entry.isIntersecting);
      },
      { rootMargin: "160px 0px" },
    );
    document.querySelectorAll("[data-scroll-root]").forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [pathname]);

  useEffect(() => {
    if (prefersReducedMotion()) return;

    const onPointerDown = (event: PointerEvent) => {
      if (event.button !== 0 || !(event.target instanceof Element)) return;
      const host = event.target.closest<HTMLElement>("[data-ripple]");
      if (!host || host.matches(":disabled, [aria-disabled='true']")) return;

      const rect = host.getBoundingClientRect();
      const size = Math.hypot(rect.width, rect.height) * 2;
      const ripple = document.createElement("span");
      ripple.className = "ripple";
      ripple.setAttribute("aria-hidden", "true");
      ripple.style.width = ripple.style.height = `${size}px`;
      ripple.style.left = `${event.clientX - rect.left}px`;
      ripple.style.top = `${event.clientY - rect.top}px`;
      ripple.addEventListener("animationend", () => ripple.remove(), { once: true });
      host.appendChild(ripple);
    };

    document.addEventListener("pointerdown", onPointerDown, { passive: true });
    return () => document.removeEventListener("pointerdown", onPointerDown);
  }, []);

  return null;
}
