"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

import { prefersReducedMotion, registerLenis } from "@/lib/scroll";

type Gsap = typeof import("gsap").gsap;
type ScrollTriggerStatic = typeof import("gsap/ScrollTrigger").ScrollTrigger;

/* ----------------------------------------------------------------------------
 * Loading — everything here is off the critical path.
 *
 *   GSAP core        every device, when the main thread is idle
 *   ScrollTrigger    tablets and up (scrubbed parallax needs room to breathe)
 *   Lenis            devices with a mouse or trackpad (touch scrolling is
 *                    already smooth, so phones skip the per-frame work)
 * ------------------------------------------------------------------------- */

/** Resolves when the browser has a quiet moment (or after 1.5 s at the latest). */
function whenIdle(): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window.requestIdleCallback === "function") window.requestIdleCallback(() => resolve(), { timeout: 1500 });
    else window.setTimeout(resolve, 200);
  });
}

let gsapPromise: Promise<Gsap> | null = null;
function loadGsap(): Promise<Gsap> {
  gsapPromise ??= whenIdle()
    .then(() => import("gsap"))
    .then(({ gsap }) => {
      gsap.config({ nullTargetWarn: false });
      return gsap;
    });
  return gsapPromise;
}

let scrollTriggerPromise: Promise<{ gsap: Gsap; ScrollTrigger: ScrollTriggerStatic }> | null = null;
function loadScrollTrigger() {
  scrollTriggerPromise ??= Promise.all([loadGsap(), import("gsap/ScrollTrigger")]).then(([gsap, { ScrollTrigger }]) => {
    gsap.registerPlugin(ScrollTrigger);
    return { gsap, ScrollTrigger };
  });
  return scrollTriggerPromise;
}

const hasFinePointer = () => window.matchMedia("(hover: hover) and (pointer: fine)").matches;
const hasRoom = () => window.matchMedia("(min-width: 768px)").matches;

/* ----------------------------------------------------------------------------
 * Declarative scroll animation, driven by data attributes so that sections
 * can stay Server Components:
 *
 *   data-reveal="up|down|left|right|scale|fade"   staggered entrance on scroll
 *   data-wipe="x|y"                                draws itself in on scroll
 *   data-parallax="0.4"                            drifts while its root scrolls
 *   data-spin="60"                                 rotates (deg) while its root scrolls
 *
 * Parallax / spin are measured against the nearest [data-scroll-root].
 * ------------------------------------------------------------------------- */

const REVEAL_FROM: Record<string, { x?: number; y?: number; scale?: number }> = {
  up: { y: 32 },
  down: { y: -24 },
  left: { x: 44 },
  right: { x: -44 },
  scale: { scale: 0.92, y: 16 },
  fade: {},
};

const from = (element: Element) => REVEAL_FROM[(element as HTMLElement).dataset.reveal ?? "up"] ?? REVEAL_FROM.up;

const markAllRevealed = () => {
  document.querySelectorAll<HTMLElement>("[data-reveal], [data-wipe]").forEach((element) => element.setAttribute("data-revealed", "done"));
};

/**
 * Entrances. An IntersectionObserver decides *when* (no scroll listeners, no
 * layout reads), GSAP decides *how*. Elements that arrive together are
 * animated together, which gives the stagger for free.
 */
function observeReveals(gsap: Gsap): () => void {
  const observer = new IntersectionObserver(
    (entries) => {
      const arriving = entries.filter((entry) => entry.isIntersecting).map((entry) => entry.target as HTMLElement);
      if (arriving.length === 0) return;

      const reveals: HTMLElement[] = [];
      const wipes: HTMLElement[] = [];
      for (const element of arriving) {
        observer.unobserve(element);
        element.setAttribute("data-revealed", "true");
        (element.hasAttribute("data-wipe") ? wipes : reveals).push(element);
      }

      if (reveals.length > 0) {
        gsap.fromTo(
          reveals,
          { opacity: 0, x: (_, element) => from(element).x ?? 0, y: (_, element) => from(element).y ?? 0, scale: (_, element) => from(element).scale ?? 1 },
          {
            opacity: 1,
            x: 0,
            y: 0,
            scale: 1,
            duration: 0.95,
            ease: "expo.out",
            stagger: 0.08,
            clearProps: "opacity,transform",
            onComplete: () => reveals.forEach((element) => element.setAttribute("data-revealed", "done")),
          },
        );
      }

      if (wipes.length > 0) {
        gsap.fromTo(
          wipes,
          { clipPath: (_, element) => ((element as HTMLElement).dataset.wipe === "y" ? "inset(0% 0% 100% 0%)" : "inset(0% 100% 0% 0%)") },
          {
            clipPath: "inset(0% 0% 0% 0%)",
            duration: 0.9,
            delay: 0.35,
            ease: "power2.inOut",
            stagger: 0.22,
            clearProps: "clipPath",
            onComplete: () => wipes.forEach((element) => element.setAttribute("data-revealed", "done")),
          },
        );
      }
    },
    { rootMargin: "0px 0px -6% 0px", threshold: 0.01 },
  );

  document.querySelectorAll("[data-reveal]:not([data-revealed]), [data-wipe]:not([data-revealed])").forEach((element) => observer.observe(element));
  return () => observer.disconnect();
}

/** Scrubbed effects: these follow the scroll position, so they use ScrollTrigger. */
function scrubEffects(gsap: Gsap, ScrollTrigger: ScrollTriggerStatic): () => void {
  const context = gsap.context(() => {
    gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((element) => {
      const speed = Number(element.dataset.parallax) || 0.2;
      const root = element.closest<HTMLElement>("[data-scroll-root]") ?? element;
      gsap.to(element, {
        y: -speed * 160,
        ease: "none",
        scrollTrigger: { trigger: root, start: "top bottom", end: "bottom top", scrub: 0.6 },
      });
    });

    gsap.utils.toArray<HTMLElement>("[data-spin]").forEach((element) => {
      const degrees = Number(element.dataset.spin) || 45;
      const root = element.closest<HTMLElement>("[data-scroll-root]") ?? element;
      gsap.to(element, {
        rotation: degrees,
        ease: "none",
        scrollTrigger: { trigger: root, start: "top bottom", end: "bottom top", scrub: 0.8 },
      });
    });
  });

  // Web fonts can nudge the layout; measure once more when they have settled.
  let live = true;
  document.fonts?.ready.then(() => {
    if (live) ScrollTrigger.refresh();
  });

  return () => {
    live = false;
    context.revert();
  };
}

export function ScrollEngine() {
  const pathname = usePathname();

  /* Smooth scrolling (Lenis), driven by GSAP's ticker so both share one frame loop. */
  useEffect(() => {
    if (prefersReducedMotion() || !hasFinePointer()) return;

    let disposed = false;
    let teardown = () => {};

    Promise.all([loadScrollTrigger(), import("lenis")])
      .then(([{ gsap, ScrollTrigger }, { default: Lenis }]) => {
        if (disposed) return;
        const lenis = new Lenis({ lerp: 0.11, wheelMultiplier: 1, smoothWheel: true, syncTouch: false, stopInertiaOnNavigate: true });
        lenis.on("scroll", ScrollTrigger.update);
        const tick = (time: number) => lenis.raf(time * 1000);
        gsap.ticker.add(tick);
        gsap.ticker.lagSmoothing(0);
        registerLenis(lenis);
        teardown = () => {
          gsap.ticker.remove(tick);
          registerLenis(null);
          lenis.destroy();
        };
      })
      .catch(() => {
        /* Native scrolling keeps working if the bundle fails to load. */
      });

    return () => {
      disposed = true;
      teardown();
    };
  }, []);

  /* Scroll-driven animation, re-scanned on every route. */
  useEffect(() => {
    const root = document.documentElement;

    if (prefersReducedMotion()) {
      markAllRevealed();
      root.classList.add("reveal-ready");
      return;
    }

    let disposed = false;
    const cleanups: (() => void)[] = [];

    loadGsap()
      .then((gsap) => {
        if (disposed) return;
        cleanups.push(observeReveals(gsap));
        root.classList.add("reveal-ready");
      })
      .catch(() => {
        markAllRevealed();
        root.classList.add("reveal-ready");
      });

    if (hasRoom()) {
      loadScrollTrigger()
        .then(({ gsap, ScrollTrigger }) => {
          if (!disposed) cleanups.push(scrubEffects(gsap, ScrollTrigger));
        })
        .catch(() => {
          /* Parallax is decoration; the page is complete without it. */
        });
    }

    return () => {
      disposed = true;
      cleanups.forEach((cleanup) => cleanup());
    };
  }, [pathname]);

  return null;
}
