"use client";

import * as m from "framer-motion/m";
import { ArrowUpRight, CalendarCheck, Heart, Phone, UserRound, X } from "lucide-react";
import Link from "next/link";

import { Button, ButtonAnchor, buttonStyles, iconButtonStyles } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Logo } from "@/components/ui/logo";
import { Modal } from "@/components/ui/modal";
import { OpenStatus } from "@/components/ui/open-status";
import { SectionLink } from "@/components/ui/section-link";
import { SocialIcon } from "@/components/ui/social-icon";
import { primaryNav, site } from "@/config/site";
import { categories } from "@/data/categories";
import { categoryCounts } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { ui } from "@/stores/ui";

const EASE = [0.16, 1, 0.3, 1] as const;

export function MobileNav({ open }: { open: boolean }) {
  return (
    <Modal open={open} onClose={ui.close} variant="drawer" label="Site menu" className="max-w-full sm:max-w-[26rem]">
      <header className="flex h-[4.75rem] shrink-0 items-center justify-between px-5">
        <Link href="/" onClick={ui.close} aria-label={`${site.name} ${site.descriptor} — home`}>
          <Logo />
        </Link>
        <button type="button" onClick={ui.close} aria-label="Close menu" className={iconButtonStyles("light")}>
          <X aria-hidden="true" className="size-5" />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto overscroll-contain px-5 pb-8" data-lenis-prevent="">
        <nav aria-label="Mobile">
          <ul className="border-t border-line">
            {primaryNav.map((item, index) => (
              <m.li
                key={item.href}
                initial={{ opacity: 0, x: 28 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, ease: EASE, delay: 0.08 + index * 0.045 }}
                className="border-b border-line"
              >
                <SectionLink
                  href={item.href}
                  onClick={ui.close}
                  className="group flex h-[3.75rem] items-center justify-between font-display text-[1.375rem] font-bold tracking-[-0.02em] text-ink"
                >
                  {item.label}
                  <ArrowUpRight
                    aria-hidden="true"
                    className="size-5 text-ink-subtle transition-[translate,color] duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brand-600"
                  />
                </SectionLink>
              </m.li>
            ))}
          </ul>
        </nav>

        <m.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: EASE, delay: 0.32 }}
          className="mt-5 grid grid-cols-2 gap-2"
        >
          <button
            type="button"
            onClick={() => ui.open("account")}
            className="flex h-12 items-center justify-center gap-2 rounded-2xl bg-white text-[0.9375rem] font-medium text-ink ring-1 ring-ink/[0.06] transition-colors hover:bg-cream"
          >
            <UserRound aria-hidden="true" className="size-[1.125rem] text-brand-600" />
            Your account
          </button>
          <button
            type="button"
            onClick={() => ui.open("account")}
            className="flex h-12 items-center justify-center gap-2 rounded-2xl bg-white text-[0.9375rem] font-medium text-ink ring-1 ring-ink/[0.06] transition-colors hover:bg-cream"
          >
            <Heart aria-hidden="true" className="size-[1.125rem] text-brand-600" />
            Favourites
          </button>
        </m.div>

        <m.section
          aria-labelledby="mobile-nav-categories"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: EASE, delay: 0.36 }}
          className="mt-7"
        >
          <h2 id="mobile-nav-categories" className="eyebrow text-ink-subtle">
            Categories
          </h2>
          <ul className="mt-3 grid grid-cols-2 gap-2">
            {categories.map((category) => (
              <li key={category.slug}>
                <Link
                  href={`/menu/${category.slug}`}
                  onClick={ui.close}
                  className="flex h-12 items-center gap-2.5 rounded-2xl bg-white px-3 text-[0.9375rem] font-medium text-ink ring-1 ring-ink/[0.06] transition-colors hover:bg-cream"
                >
                  <span className="grid size-8 shrink-0 place-items-center rounded-xl bg-cream text-brand-600">
                    <Icon name={category.icon} className="size-4" />
                  </span>
                  <span className="truncate">{category.name}</span>
                  <span className="ml-auto text-xs text-ink-subtle">{categoryCounts[category.slug]}</span>
                </Link>
              </li>
            ))}
          </ul>
        </m.section>

        <m.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: EASE, delay: 0.44 }}
          className="mt-7 rounded-card bg-ink p-5 text-white on-dark"
        >
          <OpenStatus tone="dark" className="text-sm" />
          <p className="mt-1.5 text-sm text-white/70">{site.address.short}</p>
          <div className="mt-4 grid grid-cols-2 gap-2.5">
            <ButtonAnchor href={site.phone.href} variant="glass" size="sm">
              <Phone aria-hidden="true" className="size-4" />
              Call us
            </ButtonAnchor>
            <Button variant="primary" size="sm" onClick={() => ui.open("reservation")}>
              <CalendarCheck aria-hidden="true" className="size-4" />
              Book a table
            </Button>
          </div>
        </m.div>

        <ul className="mt-6 flex items-center gap-2">
          {site.social.map((profile) => (
            <li key={profile.name}>
              <a
                href={profile.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`${site.name} on ${profile.name} (opens in a new tab)`}
                className={iconButtonStyles("light")}
              >
                <SocialIcon name={profile.icon} />
              </a>
            </li>
          ))}
        </ul>
      </div>

      <div className="shrink-0 border-t border-line bg-white px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-4">
        <Link href="/menu" onClick={ui.close} data-ripple="" className={cn(buttonStyles({ variant: "primary", size: "lg", fullWidth: true }))}>
          Order online
        </Link>
      </div>
    </Modal>
  );
}
