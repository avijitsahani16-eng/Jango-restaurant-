"use client";

import { Heart, MapPin, ReceiptText, RotateCcw, UserRound, X } from "lucide-react";
import Link from "next/link";
import { useId, useState, type FormEvent } from "react";

import { AddToCartButton, FavoriteButton, QuickViewTrigger } from "@/components/menu/dish-actions";
import { DishTile } from "@/components/menu/dish-card";
import { Button, buttonStyles, iconButtonStyles } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { DietMark, Field, fieldProps, inputStyles, textareaStyles } from "@/components/ui/primitives";
import { getDish } from "@/data/dishes";
import { useStore } from "@/hooks/use-store";
import { cn } from "@/lib/cn";
import { formatINR, initials, pluralize } from "@/lib/format";
import { getOrderProgress } from "@/lib/order-status";
import { isEmail, normalizePhone } from "@/lib/validation";
import { cart } from "@/stores/cart";
import { favoritesStore, ordersStore, profileStore, saveProfile } from "@/stores/customer";
import { showToast } from "@/stores/toast";
import { ui } from "@/stores/ui";
import type { Order, Profile } from "@/types";

type Tab = "favourites" | "orders" | "details";

const TABS: { id: Tab; label: string; icon: typeof Heart }[] = [
  { id: "favourites", label: "Favourites", icon: Heart },
  { id: "orders", label: "Orders", icon: ReceiptText },
  { id: "details", label: "Details", icon: MapPin },
];

export function AccountSheet({ open }: { open: boolean }) {
  const baseId = useId();
  const [tab, setTab] = useState<Tab>("favourites");
  const profile = useStore(profileStore);
  const favouriteIds = useStore(favoritesStore);
  const orders = useStore(ordersStore);
  const firstName = profile.name.trim().split(" ")[0];

  return (
    <Modal open={open} onClose={ui.close} variant="drawer" labelledBy="account-title">
      <header className="flex items-center justify-between gap-4 px-5 pb-4 pt-5 sm:px-6">
        <div className="flex min-w-0 items-center gap-3.5">
          <span className="grid size-12 shrink-0 place-items-center rounded-full bg-brand-500 font-display text-lg font-extrabold text-ink">
            {profile.name.trim() ? initials(profile.name) : <UserRound aria-hidden="true" className="size-6" />}
          </span>
          <div className="min-w-0">
            <h2 id="account-title" className="truncate font-display text-xl font-extrabold tracking-[-0.02em] text-ink">
              {firstName ? `Hi, ${firstName}` : "Your account"}
            </h2>
            <p className="text-sm text-ink-muted">Saved on this device</p>
          </div>
        </div>
        <button type="button" onClick={ui.close} aria-label="Close account" className={iconButtonStyles("light")}>
          <X aria-hidden="true" className="size-5" />
        </button>
      </header>

      <div role="tablist" aria-label="Account sections" className="mx-5 grid grid-cols-3 gap-1 rounded-full bg-ink/[0.06] p-1 sm:mx-6">
        {TABS.map(({ id, label, icon: TabIcon }) => {
          const count = id === "favourites" ? favouriteIds.length : id === "orders" ? orders.length : 0;
          return (
            <button
              key={id}
              type="button"
              role="tab"
              id={`${baseId}-tab-${id}`}
              aria-selected={tab === id}
              aria-controls={`${baseId}-panel-${id}`}
              tabIndex={tab === id ? 0 : -1}
              onClick={() => setTab(id)}
              onKeyDown={(event) => {
                if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
                const index = TABS.findIndex((item) => item.id === tab);
                const next = TABS[(index + (event.key === "ArrowRight" ? 1 : TABS.length - 1)) % TABS.length];
                setTab(next.id);
                document.getElementById(`${baseId}-tab-${next.id}`)?.focus();
              }}
              className={cn(
                "inline-flex h-10 items-center justify-center gap-1.5 rounded-full text-sm font-medium transition-[background-color,color,box-shadow] duration-300",
                tab === id ? "bg-white text-ink shadow-soft" : "text-ink-muted hover:text-ink",
              )}
            >
              <TabIcon aria-hidden="true" className="size-4" />
              {label}
              {count > 0 && <span className="text-ink-subtle">({count})</span>}
            </button>
          );
        })}
      </div>

      <div
        role="tabpanel"
        id={`${baseId}-panel-${tab}`}
        aria-labelledby={`${baseId}-tab-${tab}`}
        tabIndex={0}
        data-lenis-prevent=""
        className="mt-2 flex-1 overflow-y-auto overscroll-contain px-5 pb-8 pt-3 sm:px-6"
      >
        {tab === "favourites" && <Favourites ids={favouriteIds} />}
        {tab === "orders" && <Orders orders={orders} />}
        {tab === "details" && <Details key={open ? "open" : "closed"} profile={profile} />}
      </div>
    </Modal>
  );
}

function EmptyState({ icon: EmptyIcon, title, body }: { icon: typeof Heart; title: string; body: string }) {
  return (
    <div className="flex flex-col items-center px-4 py-14 text-center">
      <span className="grid size-20 place-items-center rounded-full bg-cream text-brand-600">
        <EmptyIcon aria-hidden="true" className="size-8" strokeWidth={1.5} />
      </span>
      <h3 className="mt-5 font-display text-lg font-bold text-ink">{title}</h3>
      <p className="mt-1.5 max-w-64 text-[0.9375rem] text-ink-muted">{body}</p>
      <Link href="/menu" onClick={ui.close} data-ripple="" className={cn(buttonStyles({ variant: "dark", size: "sm" }), "mt-6")}>
        Browse the menu
      </Link>
    </div>
  );
}

function Favourites({ ids }: { ids: readonly string[] }) {
  const items = ids.flatMap((id) => getDish(id) ?? []);
  if (items.length === 0) {
    return <EmptyState icon={Heart} title="No favourites yet" body="Tap the heart on any dish and it will be waiting for you here." />;
  }

  return (
    <ul className="space-y-3">
      {items.map((dish) => (
        <li key={dish.id} data-fly-root="" className="flex items-center gap-3.5 rounded-[1.25rem] bg-white p-2.5 ring-1 ring-ink/[0.06]">
          <DishTile dish={dish} className="size-16 rounded-2xl" fly />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-2">
              <DietMark diet={dish.diet} />
              <QuickViewTrigger dishId={dish.id} className="truncate rounded text-left font-display text-[0.9375rem] font-bold text-ink hover:text-brand-700">
                {dish.name}
              </QuickViewTrigger>
            </p>
            <p className="mt-0.5 text-sm font-medium text-ink-muted">{formatINR(dish.price)}</p>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <AddToCartButton dish={dish} size="sm" />
            <FavoriteButton dish={dish} tone="outline" className="size-9 [&_svg]:size-4" />
          </div>
        </li>
      ))}
    </ul>
  );
}

function Orders({ orders }: { orders: readonly Order[] }) {
  const [now] = useState(() => new Date());
  if (orders.length === 0) {
    return <EmptyState icon={ReceiptText} title="No orders yet" body="Your recent orders and their status will appear here." />;
  }

  const reorder = (order: Order) => {
    let added = 0;
    for (const line of order.lines) {
      if (getDish(line.dishId)) {
        cart.add(line.dishId, { quantity: line.quantity, silent: true });
        added += line.quantity;
      }
    }
    if (added > 0) {
      showToast({ title: "Added to your cart", description: pluralize(added, "item") });
      ui.open("cart");
    }
  };

  return (
    <ul className="space-y-3">
      {orders.map((order) => {
        const progress = getOrderProgress(order, now);
        const stage = progress.stages[progress.current];
        return (
          <li key={order.id} className="rounded-[1.25rem] bg-white p-4 ring-1 ring-ink/[0.06]">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-display font-bold text-ink">Order {order.id}</p>
                <p className="text-sm text-ink-subtle">
                  {new Date(order.placedAt).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}
                </p>
              </div>
              <span
                className={cn(
                  "inline-flex h-7 items-center rounded-full px-3 text-xs font-semibold",
                  progress.done ? "bg-success/15 text-success-ink" : "bg-brand-100 text-brand-800",
                )}
              >
                {stage.label}
              </span>
            </div>
            <p className="mt-3 line-clamp-2 text-sm text-ink-muted">
              {order.lines.map((line) => `${line.quantity} × ${line.name}`).join(", ")}
            </p>
            <div className="mt-3.5 flex items-center justify-between gap-3 border-t border-line pt-3.5">
              <p className="font-display font-bold tabular-nums text-ink">{formatINR(order.totals.total)}</p>
              <Button variant="outline" size="sm" className="h-9 px-4" onClick={() => reorder(order)}>
                <RotateCcw aria-hidden="true" className="size-4" />
                Reorder
              </Button>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function Details({ profile }: { profile: Profile }) {
  const [form, setForm] = useState<Profile>(profile);
  const [errors, setErrors] = useState<Partial<Record<keyof Profile, string>>>({});

  const set = (field: keyof Profile) => (event: { target: { value: string } }) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    const next: typeof errors = {};
    if (form.phone.trim() && !normalizePhone(form.phone)) next.phone = "Enter a valid 10-digit mobile number.";
    if (form.email.trim() && !isEmail(form.email.trim())) next.email = "That email doesn’t look right.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    saveProfile({
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      address: form.address.trim(),
      landmark: form.landmark.trim(),
    });
    showToast({ title: "Details saved", description: "We’ll fill these in at checkout." });
  };

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <p className="rounded-2xl bg-cream px-4 py-3 text-sm text-ink-muted">
        Save your details once and checkout fills itself in. They stay in this browser — nothing is sent to us until you place an order.
      </p>
      <Field id="acc-name" label="Name">
        <input id="acc-name" name="name" autoComplete="name" value={form.name} onChange={set("name")} className={inputStyles} />
      </Field>
      <Field id="acc-phone" label="Mobile number" error={errors.phone}>
        <input {...fieldProps("acc-phone", errors.phone)} name="phone" type="tel" inputMode="tel" autoComplete="tel" value={form.phone} onChange={set("phone")} className={inputStyles} />
      </Field>
      <Field id="acc-email" label="Email" optional error={errors.email}>
        <input {...fieldProps("acc-email", errors.email)} name="email" type="email" autoComplete="email" value={form.email} onChange={set("email")} className={inputStyles} />
      </Field>
      <Field id="acc-address" label="Delivery address">
        <textarea id="acc-address" name="address" rows={3} autoComplete="street-address" value={form.address} onChange={set("address")} className={textareaStyles} />
      </Field>
      <Field id="acc-landmark" label="Landmark" optional>
        <input id="acc-landmark" name="landmark" value={form.landmark} onChange={set("landmark")} className={inputStyles} />
      </Field>
      <Button type="submit" variant="dark" fullWidth>
        Save details
      </Button>
    </form>
  );
}
