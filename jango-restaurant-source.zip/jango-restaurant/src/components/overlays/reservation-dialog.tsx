"use client";

import { CalendarCheck, Phone, X } from "lucide-react";
import { useRef, useState, type FormEvent } from "react";

import { Button, ButtonAnchor, iconButtonStyles } from "@/components/ui/button";
import { Honeypot, SubmitButton, SuccessCheck } from "@/components/ui/form-bits";
import { Modal } from "@/components/ui/modal";
import { Eyebrow, Field, fieldProps, inputStyles, textareaStyles } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { focusFirstError, useFormSubmit } from "@/hooks/use-form-submit";
import { useStore } from "@/hooks/use-store";
import { cn } from "@/lib/cn";
import { formatClock } from "@/lib/format";
import { reservationSlots, zonedDateString } from "@/lib/hours";
import { MAX_ADVANCE_DAYS, MAX_GUESTS, OCCASIONS, validateReservation } from "@/lib/validation";
import { profileStore, saveProfile } from "@/stores/customer";
import { ui } from "@/stores/ui";
import type { ReservationInput } from "@/types";

const SLOTS = reservationSlots();
const GUEST_OPTIONS = Array.from({ length: MAX_GUESTS }, (_, index) => index + 1);

function addDays(date: string, days: number): string {
  const next = new Date(`${date}T00:00:00Z`);
  next.setUTCDate(next.getUTCDate() + days);
  return next.toISOString().slice(0, 10);
}

function prettyDate(date: string): string {
  return new Date(`${date}T00:00:00Z`).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", timeZone: "UTC" });
}

export function ReservationDialog({ open }: { open: boolean }) {
  return (
    <Modal open={open} onClose={ui.close} labelledBy="reservation-title" className="sm:max-w-2xl">
      <ReservationForm />
    </Modal>
  );
}

function ReservationForm() {
  const profile = useStore(profileStore);
  const [today] = useState(() => zonedDateString(new Date()));
  const [form, setForm] = useState(() => ({
    name: profile.name,
    phone: profile.phone,
    date: today,
    time: "20:00",
    guests: "2",
    occasion: OCCASIONS[0] as string,
    notes: "",
  }));
  const [trap, setTrap] = useState("");
  const formRef = useRef<HTMLFormElement>(null);
  const { status, message, errors, submit, clearError, reset } = useFormSubmit<ReservationInput>("/api/reservations");

  const set = (field: keyof typeof form) => (event: { target: { value: string } }) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    clearError(field);
  };

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    const result = await submit(validateReservation(form), { company: trap });
    if (result.status === "success") saveProfile({ name: form.name.trim(), phone: form.phone.trim() });
    else if (result.status === "error") focusFirstError(formRef.current);
  };

  const closeButton = (
    <button type="button" onClick={ui.close} aria-label="Close reservation form" className={cn(iconButtonStyles("light"), "absolute right-3.5 top-3.5")}>
      <X aria-hidden="true" className="size-5" />
    </button>
  );

  if (status === "success") {
    return (
      <div className="relative flex flex-col items-center px-6 py-12 text-center sm:px-12 sm:py-14" role="status">
        {closeButton}
        <SuccessCheck />
        <h2 id="reservation-title" className="mt-6 font-display text-[1.75rem] font-extrabold tracking-[-0.03em] text-ink">
          Request received, {form.name.trim().split(" ")[0]}!
        </h2>
        <p className="mt-3 max-w-md text-[1.0625rem] text-ink-muted">
          A table for <strong className="font-semibold text-ink">{form.guests}</strong> on{" "}
          <strong className="font-semibold text-ink">{prettyDate(form.date)}</strong> at{" "}
          <strong className="font-semibold text-ink">{formatClock(form.time)}</strong>. We will call{" "}
          <strong className="font-semibold text-ink">{form.phone}</strong> shortly to confirm it.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button variant="dark" onClick={ui.close}>
            Done
          </Button>
          <Button variant="outline" onClick={reset}>
            Book another table
          </Button>
        </div>
      </div>
    );
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="relative p-6 sm:p-9">
      {closeButton}
      <Eyebrow>Dine in</Eyebrow>
      <h2 id="reservation-title" className="mt-3 pr-12 font-display text-[1.75rem] font-extrabold leading-tight tracking-[-0.03em] text-ink sm:text-[2rem]">
        Reserve a table
      </h2>
      <p className="mt-2 text-ink-muted">
        {site.hoursSummary}. Tell us when you are coming and we will call to confirm.
      </p>

      <Honeypot value={trap} onChange={setTrap} />

      <div className="mt-7 grid gap-x-4 gap-y-5 sm:grid-cols-2">
        <Field id="res-name" label="Your name" error={errors.name}>
          <input {...fieldProps("res-name", errors.name)} name="name" autoComplete="name" value={form.name} onChange={set("name")} className={inputStyles} />
        </Field>
        <Field id="res-phone" label="Mobile number" error={errors.phone}>
          <input
            {...fieldProps("res-phone", errors.phone)}
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="98765 43210"
            value={form.phone}
            onChange={set("phone")}
            className={inputStyles}
          />
        </Field>
        <Field id="res-date" label="Date" error={errors.date}>
          <input
            {...fieldProps("res-date", errors.date)}
            name="date"
            type="date"
            min={today}
            max={addDays(today, MAX_ADVANCE_DAYS)}
            value={form.date}
            onChange={set("date")}
            className={inputStyles}
          />
        </Field>
        <div className="grid grid-cols-2 gap-4">
          <Field id="res-time" label="Time" error={errors.time}>
            <select {...fieldProps("res-time", errors.time)} name="time" value={form.time} onChange={set("time")} className={inputStyles}>
              {SLOTS.map((slot) => (
                <option key={slot} value={slot}>
                  {formatClock(slot)}
                </option>
              ))}
            </select>
          </Field>
          <Field id="res-guests" label="Guests" error={errors.guests}>
            <select {...fieldProps("res-guests", errors.guests)} name="guests" value={form.guests} onChange={set("guests")} className={inputStyles}>
              {GUEST_OPTIONS.map((count) => (
                <option key={count} value={count}>
                  {count}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field id="res-occasion" label="Occasion" error={errors.occasion} className="sm:col-span-2">
          <select {...fieldProps("res-occasion", errors.occasion)} name="occasion" value={form.occasion} onChange={set("occasion")} className={inputStyles}>
            {OCCASIONS.map((occasion) => (
              <option key={occasion} value={occasion}>
                {occasion}
              </option>
            ))}
          </select>
        </Field>
        <Field id="res-notes" label="Anything we should know?" optional className="sm:col-span-2">
          <textarea
            id="res-notes"
            name="notes"
            rows={3}
            maxLength={500}
            placeholder="High chair, a quiet corner, a cake to keep in the fridge…"
            value={form.notes}
            onChange={set("notes")}
            className={textareaStyles}
          />
        </Field>
      </div>

      {status === "error" && message && (
        <p role="alert" className="mt-5 rounded-2xl bg-danger/10 px-4 py-3 text-sm font-medium text-danger-ink">
          {message}
        </p>
      )}

      <div className="mt-7 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
        <ButtonAnchor href={site.phone.href} variant="ghost" className="justify-center">
          <Phone aria-hidden="true" className="size-4" />
          Or call {site.phone.display}
        </ButtonAnchor>
        <SubmitButton pending={status === "submitting"} pendingLabel="Sending request…" size="lg">
          <CalendarCheck aria-hidden="true" className="size-5" />
          Request my table
        </SubmitButton>
      </div>
      <p className="mt-4 text-xs text-ink-subtle">
        The bar serves guests aged {site.legalDrinkingAge} and above. Please carry a valid photo ID.
      </p>
    </form>
  );
}
