"use client";

import { ArrowRight, CornerDownLeft, Search, SearchX, X } from "lucide-react";
import Link from "next/link";
import { useMemo, useRef, useState, type KeyboardEvent } from "react";

import { DishTile } from "@/components/menu/dish-card";
import { Icon } from "@/components/ui/icon";
import { Modal } from "@/components/ui/modal";
import { DietMark, Rating } from "@/components/ui/primitives";
import { categories, getCategory } from "@/data/categories";
import { dishes, popularDishes } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { formatINR, pluralize } from "@/lib/format";
import { searchDishes } from "@/lib/search";
import { ui } from "@/stores/ui";
import type { Dish } from "@/types";

const QUICK_SEARCHES = ["Biryani", "Momos", "Pizza", "Veg", "Dessert"];

export function SearchDialog({ open }: { open: boolean }) {
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  const trimmed = query.trim();
  const results = useMemo<Dish[]>(
    () => (trimmed ? searchDishes(trimmed, dishes, 7) : popularDishes.slice(0, 4)),
    [trimmed],
  );
  const active = Math.min(activeIndex, Math.max(results.length - 1, 0));

  const close = () => {
    ui.close();
    setQuery("");
    setActiveIndex(0);
  };

  const choose = (dish: Dish) => {
    setQuery("");
    setActiveIndex(0);
    ui.openQuickView(dish.id);
  };

  const move = (delta: number) => {
    if (results.length === 0) return;
    const next = (active + delta + results.length) % results.length;
    setActiveIndex(next);
    listRef.current?.children[next]?.scrollIntoView({ block: "nearest" });
  };

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      move(1);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      move(-1);
    } else if (event.key === "Enter" && results[active]) {
      event.preventDefault();
      choose(results[active]);
    }
  };

  return (
    <Modal open={open} onClose={close} variant="top" label="Search the menu">
      <div role="search" className="flex max-h-[80dvh] flex-col">
        <div className="flex h-16 shrink-0 items-center gap-3 border-b border-line pl-5 pr-3">
          <Search aria-hidden="true" className="size-5 shrink-0 text-ink-subtle" />
          <input
            ref={inputRef}
            data-autofocus=""
            type="text"
            inputMode="search"
            enterKeyHint="search"
            role="combobox"
            aria-label="Search dishes"
            aria-expanded={results.length > 0}
            aria-controls="search-results"
            aria-autocomplete="list"
            aria-activedescendant={results[active] ? `search-option-${results[active].id}` : undefined}
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setActiveIndex(0);
            }}
            onKeyDown={onKeyDown}
            placeholder="Search biryani, momos, pizza…"
            className="h-full min-w-0 flex-1 bg-transparent text-lg text-ink placeholder:text-ink-subtle focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setActiveIndex(0);
                inputRef.current?.focus();
              }}
              aria-label="Clear search"
              className="grid size-9 shrink-0 place-items-center rounded-full text-ink-muted hover:bg-ink/[0.06] hover:text-ink"
            >
              <X aria-hidden="true" className="size-4" />
            </button>
          )}
          <button
            type="button"
            onClick={close}
            className="h-9 shrink-0 rounded-full px-3 text-sm font-medium text-ink-muted ring-1 ring-inset ring-ink/15 hover:bg-ink/[0.05] hover:text-ink"
          >
            <span aria-hidden="true">Esc</span>
            <span className="sr-only">Close search</span>
          </button>
        </div>

        <p className="sr-only" aria-live="polite">
          {trimmed ? (results.length ? `${pluralize(results.length, "dish", "dishes")} found` : "No dishes found") : ""}
        </p>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-3" data-lenis-prevent="">
          {!trimmed && (
            <div className="px-2 pb-1 pt-2">
              <p className="font-display text-xs font-bold uppercase tracking-[0.12em] text-ink-subtle">Try searching for</p>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {QUICK_SEARCHES.map((term) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() => {
                      setQuery(term);
                      setActiveIndex(0);
                      inputRef.current?.focus();
                    }}
                    className="h-9 rounded-full bg-cream px-4 text-sm font-medium text-ink ring-1 ring-inset ring-brand-200 transition-colors hover:bg-brand-100"
                  >
                    {term}
                  </button>
                ))}
              </div>
              <p className="mt-5 font-display text-xs font-bold uppercase tracking-[0.12em] text-ink-subtle">Popular right now</p>
            </div>
          )}

          {results.length > 0 ? (
            <ul ref={listRef} id="search-results" role="listbox" aria-label={trimmed ? "Matching dishes" : "Popular dishes"} className="mt-1">
              {results.map((dish, index) => (
                <li
                  key={dish.id}
                  id={`search-option-${dish.id}`}
                  role="option"
                  aria-selected={index === active}
                  onClick={() => choose(dish)}
                  onPointerMove={() => index !== active && setActiveIndex(index)}
                  className={cn(
                    "flex cursor-pointer items-center gap-3.5 rounded-2xl p-2.5 transition-colors duration-150",
                    index === active ? "bg-cream" : "bg-transparent",
                  )}
                >
                  <DishTile dish={dish} className="size-14 rounded-xl" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <DietMark diet={dish.diet} />
                      <span className="truncate font-display font-bold text-ink">{dish.name}</span>
                    </span>
                    <span className="mt-0.5 flex items-center gap-2.5 text-sm text-ink-muted">
                      <span>{getCategory(dish.category)?.name}</span>
                      <span aria-hidden="true">·</span>
                      <Rating value={dish.rating} className="text-sm font-medium" />
                    </span>
                  </span>
                  <span className="shrink-0 font-display font-bold tabular-nums text-ink">{formatINR(dish.price)}</span>
                  <CornerDownLeft
                    aria-hidden="true"
                    className={cn("hidden size-4 shrink-0 text-ink-subtle sm:block", index === active ? "opacity-100" : "opacity-0")}
                  />
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center px-6 py-12 text-center">
              <span className="grid size-16 place-items-center rounded-full bg-cream text-brand-600">
                <SearchX aria-hidden="true" className="size-7" strokeWidth={1.5} />
              </span>
              <p className="mt-4 font-display text-lg font-bold text-ink">No dishes match “{trimmed}”</p>
              <p className="mt-1 text-[0.9375rem] text-ink-muted">Check the spelling, or browse a category instead.</p>
            </div>
          )}

          <div className="mt-3 border-t border-line px-2 pb-1 pt-4">
            <p className="font-display text-xs font-bold uppercase tracking-[0.12em] text-ink-subtle">Browse by category</p>
            <ul className="mt-2.5 flex flex-wrap gap-2">
              {categories.map((category) => (
                <li key={category.slug}>
                  <Link
                    href={`/menu/${category.slug}`}
                    onClick={close}
                    className="inline-flex h-9 items-center gap-2 rounded-full px-3.5 text-sm font-medium text-ink ring-1 ring-inset ring-ink/15 transition-colors hover:bg-ink/[0.05]"
                  >
                    <Icon name={category.icon} className="size-4 text-brand-600" />
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="hidden shrink-0 items-center justify-between border-t border-line bg-canvas px-5 py-2.5 text-xs text-ink-subtle sm:flex">
          <span>
            <kbd className="rounded-md bg-white px-1.5 py-0.5 font-sans font-medium text-ink ring-1 ring-ink/10">↑</kbd>{" "}
            <kbd className="rounded-md bg-white px-1.5 py-0.5 font-sans font-medium text-ink ring-1 ring-ink/10">↓</kbd> to navigate ·{" "}
            <kbd className="rounded-md bg-white px-1.5 py-0.5 font-sans font-medium text-ink ring-1 ring-ink/10">↵</kbd> to open
          </span>
          <Link href="/menu" onClick={close} className="link-underline inline-flex items-center gap-1 font-medium text-ink">
            See the full menu <ArrowRight aria-hidden="true" className="size-3.5" />
          </Link>
        </div>
      </div>
    </Modal>
  );
}
