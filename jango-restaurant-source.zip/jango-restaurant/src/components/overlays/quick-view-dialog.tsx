"use client";

import { Clock, Flame as Calories, ShoppingBag, Users, X } from "lucide-react";
import Image from "next/image";
import { useState } from "react";

import { FavoriteButton } from "@/components/menu/dish-actions";
import { QuantityStepper } from "@/components/menu/quantity-stepper";
import { Button, iconButtonStyles } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Modal } from "@/components/ui/modal";
import { DietMark, DishTagBadge, Price, Rating, SpiceMeter } from "@/components/ui/primitives";
import { getCategory } from "@/data/categories";
import { getDish } from "@/data/dishes";
import { useStore } from "@/hooks/use-store";
import { getQuantity, MAX_QUANTITY } from "@/lib/cart";
import { cn } from "@/lib/cn";
import { formatINR } from "@/lib/format";
import { cart, cartStore } from "@/stores/cart";
import { ui, uiStore } from "@/stores/ui";
import type { Dish } from "@/types";

export function QuickViewDialog({ open }: { open: boolean }) {
  const dishId = useStore(uiStore, (state) => state.quickViewId);
  const dish = dishId ? getDish(dishId) : undefined;
  if (!dish) return null;

  return (
    <Modal open={open} onClose={ui.close} labelledBy="quick-view-title" className={dish.image ? "sm:max-w-[60rem]" : "sm:max-w-xl"}>
      <QuickViewContent key={dish.id} dish={dish} />
    </Modal>
  );
}

function QuickViewContent({ dish }: { dish: Dish }) {
  const [quantity, setQuantity] = useState(1);
  const inCart = useStore(cartStore, (state) => getQuantity(state.lines, dish.id));
  const category = getCategory(dish.category);
  const room = MAX_QUANTITY - inCart;

  const add = () => {
    cart.add(dish.id, { quantity });
    ui.close();
  };

  const facts = [
    { icon: Clock, label: "Ready in", value: `${dish.prepMinutes} min` },
    { icon: Users, label: "Portion", value: dish.serves },
    { icon: Calories, label: "Energy", value: `${dish.calories} kcal` },
  ];

  return (
    <div className={cn("relative grid", dish.image && "md:grid-cols-[1.02fr_1fr]")}>
      <button
        type="button"
        onClick={ui.close}
        aria-label="Close quick view"
        className={cn(iconButtonStyles("light"), "absolute right-3.5 top-3.5 z-10")}
      >
        <X aria-hidden="true" className="size-5" />
      </button>

      {dish.image ? (
        <div className="relative aspect-[4/3] bg-cream md:aspect-auto md:min-h-[32rem]">
          <Image
            src={dish.image}
            alt={dish.imageAlt ?? dish.name}
            fill
            sizes="(min-width: 768px) 480px, 100vw"
            placeholder="blur"
            className="object-cover"
          />
          {dish.tags.length > 0 && (
            <div className="absolute left-4 top-4 flex flex-wrap gap-1.5">
              {dish.tags.map((tag) => (
                <DishTagBadge key={tag} tag={tag} />
              ))}
            </div>
          )}
        </div>
      ) : null}

      <div className="flex flex-col p-6 sm:p-8">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-2 pr-12 text-sm text-ink-muted">
          {!dish.image && (
            <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-brand-50 to-brand-100 text-brand-600">
              <Icon name={category?.icon ?? "utensils"} className="size-5" />
            </span>
          )}
          <span className="inline-flex items-center gap-2">
            <DietMark diet={dish.diet} />
            {dish.diet === "veg" ? "Vegetarian" : "Non-vegetarian"}
          </span>
          <span aria-hidden="true">·</span>
          <span>{category?.name}</span>
          {!dish.image && dish.tags.map((tag) => <DishTagBadge key={tag} tag={tag} className="h-6 px-2.5 text-[0.625rem] shadow-none" />)}
        </div>

        <h2 id="quick-view-title" className="mt-3 font-display text-[1.75rem] font-extrabold leading-[1.1] tracking-[-0.03em] text-ink sm:text-[2rem]">
          {dish.name}
        </h2>

        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
          <Rating value={dish.rating} count={dish.ratingCount} />
          <SpiceMeter level={dish.spice} />
        </div>

        <p className="mt-5 text-[1.0625rem] leading-relaxed text-ink-muted">{dish.details}</p>

        <dl className="mt-6 grid grid-cols-3 gap-2.5">
          {facts.map(({ icon: FactIcon, label, value }) => (
            <div key={label} className="rounded-2xl bg-cream px-3 py-3.5 text-center">
              <FactIcon aria-hidden="true" className="mx-auto size-5 text-brand-600" />
              <dt className="mt-1.5 text-xs text-ink-muted">{label}</dt>
              <dd className="text-sm font-semibold text-ink">{value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-auto pt-7">
          <div className="flex items-end justify-between gap-4">
            <Price amount={dish.price} compareAt={dish.compareAtPrice} size="lg" />
            <QuantityStepper
              quantity={quantity}
              onChange={setQuantity}
              min={1}
              max={Math.max(1, room)}
              label={dish.name}
              tone="neutral"
            />
          </div>
          <div className="mt-4 flex items-center gap-3">
            <Button size="lg" onClick={add} disabled={room <= 0} className="min-w-0 flex-1 justify-between px-6">
              <span className="flex items-center gap-2.5">
                <ShoppingBag aria-hidden="true" className="size-5" />
                Add to cart
              </span>
              <span className="font-display font-bold tabular-nums">{formatINR(dish.price * quantity)}</span>
            </Button>
            <FavoriteButton dish={dish} tone="outline" className="size-14" />
          </div>
          <p className="mt-3 min-h-5 text-sm text-ink-subtle" aria-live="polite">
            {inCart > 0 ? `Already in your cart: ${inCart}` : "Freshly prepared after you order."}
          </p>
        </div>
      </div>
    </div>
  );
}
