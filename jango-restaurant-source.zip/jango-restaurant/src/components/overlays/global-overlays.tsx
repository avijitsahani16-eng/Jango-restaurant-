"use client";

import dynamic from "next/dynamic";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

import { FlyToCart } from "@/components/cart/fly-to-cart";
import { Toaster } from "@/components/ui/toaster";
import { useStore } from "@/hooks/use-store";
import { ui, uiStore, type Overlay } from "@/stores/ui";

/* Each overlay is its own chunk, fetched the first time it is opened. */
const CartDrawer = dynamic(() => import("@/components/cart/cart-drawer").then((module) => module.CartDrawer), { ssr: false });
const SearchDialog = dynamic(() => import("./search-dialog").then((module) => module.SearchDialog), { ssr: false });
const QuickViewDialog = dynamic(() => import("./quick-view-dialog").then((module) => module.QuickViewDialog), { ssr: false });
const AccountSheet = dynamic(() => import("./account-sheet").then((module) => module.AccountSheet), { ssr: false });
const MobileNav = dynamic(() => import("./mobile-nav").then((module) => module.MobileNav), { ssr: false });
const ReservationDialog = dynamic(() => import("./reservation-dialog").then((module) => module.ReservationDialog), { ssr: false });

/** Hosts every site-wide overlay, the toaster and the fly-to-cart layer. */
export function GlobalOverlays() {
  const overlay = useStore(uiStore, (state) => state.overlay);
  const pathname = usePathname();

  // Remember which overlays have been opened so they stay mounted for their exit animation.
  const [seen, setSeen] = useState<readonly Overlay[]>([]);
  if (overlay && !seen.includes(overlay)) setSeen([...seen, overlay]);

  // Navigating always dismisses whatever is open.
  useEffect(() => {
    ui.close();
  }, [pathname]);

  // "/" or Ctrl/⌘ + K opens search from anywhere.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.closest("input, textarea, select, [contenteditable='true']");
      const commandK = (event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k";
      const slash = event.key === "/" && !event.metaKey && !event.ctrlKey && !event.altKey && !typing;
      if (!commandK && !slash) return;
      event.preventDefault();
      ui.open("search");
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <>
      {seen.includes("cart") && <CartDrawer open={overlay === "cart"} />}
      {seen.includes("search") && <SearchDialog open={overlay === "search"} />}
      {seen.includes("quick-view") && <QuickViewDialog open={overlay === "quick-view"} />}
      {seen.includes("account") && <AccountSheet open={overlay === "account"} />}
      {seen.includes("nav") && <MobileNav open={overlay === "nav"} />}
      {seen.includes("reservation") && <ReservationDialog open={overlay === "reservation"} />}
      <Toaster />
      <FlyToCart />
    </>
  );
}
