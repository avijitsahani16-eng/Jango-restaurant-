"use client";

import { ArrowRight, Banknote, Bike, Check, CreditCard, LockKeyhole, Phone, ShoppingBag, Smartphone, Store } from "lucide-react";
import Link from "next/link";
import { useRef, useState, type FormEvent } from "react";

import { CartLines, CouponField, FreeDeliveryMeter, TotalsSummary } from "@/components/cart/cart-parts";
import { ButtonAnchor, buttonStyles } from "@/components/ui/button";
import { SubmitButton, SuccessCheck } from "@/components/ui/form-bits";
import { Eyebrow, Field, fieldProps, inputStyles, textareaStyles } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { useCart } from "@/hooks/use-cart";
import { focusFirstError, useFormSubmit } from "@/hooks/use-form-submit";
import { useNow } from "@/hooks/use-now";
import { useHydrated } from "@/hooks/use-store";
import { cn } from "@/lib/cn";
import { formatINR, pluralize } from "@/lib/format";
import { getOrderProgress } from "@/lib/order-status";
import { scrollToTarget } from "@/lib/scroll";
import { validateCustomer } from "@/lib/validation";
import { cart, cartStore } from "@/stores/cart";
import { profileStore, rememberOrder, saveProfile } from "@/stores/customer";
import type { Fulfilment, Order, OrderInput, PaymentMethod } from "@/types";

const card = "rounded-card bg-white p-6 shadow-card ring-1 ring-ink/[0.04] sm:p-8";

/** The Place order buttons sit outside the <form> and submit it through their `form` attribute. */
const FORM_ID = "checkout-form";

const FULFILMENTS: { value: Fulfilment; title: string; text: string; icon: typeof Bike }[] = [
  { value: "delivery", title: "Delivery", text: `About ${site.delivery.averageMinutes} min · free over ${formatINR(site.delivery.freeThreshold)}`, icon: Bike },
  { value: "pickup", title: "Pickup", text: `Ready in ${site.delivery.pickupMinutes} min · always free`, icon: Store },
];

const PAYMENTS: { value: PaymentMethod; title: string; text: string; icon: typeof Bike }[] = [
  { value: "upi", title: "UPI", text: "Scan and pay on arrival", icon: Smartphone },
  { value: "card", title: "Card", text: "Tap or swipe on arrival", icon: CreditCard },
  { value: "cash", title: "Cash", text: "Pay the rider in cash", icon: Banknote },
];

const PAYMENT_LABEL: Record<PaymentMethod, string> = { upi: "UPI on arrival", card: "Card on arrival", cash: "Cash on arrival" };

export function CheckoutFlow() {
  const hydrated = useHydrated();
  const [placed, setPlaced] = useState<Order | null>(null);

  return (
    <>
      <header className="mb-9 mt-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <Eyebrow>{placed ? "All done" : "Almost there"}</Eyebrow>
          <h1 className="text-section mt-4 text-ink">{placed ? "Order confirmed" : "Checkout"}</h1>
        </div>
        <p className="inline-flex h-10 items-center gap-2 rounded-full bg-white px-4 text-sm font-medium text-ink shadow-soft ring-1 ring-ink/[0.05]">
          <LockKeyhole aria-hidden="true" className="size-4 text-success-ink" />
          Your details stay private
        </p>
      </header>

      {/* The cart lives in the browser, so the first server render shows a skeleton. */}
      {!hydrated ? <CheckoutSkeleton /> : placed ? <OrderConfirmation order={placed} /> : <CheckoutForm onPlaced={setPlaced} />}
    </>
  );
}

/* ── Form ────────────────────────────────────────────────────────────────── */
function CheckoutForm({ onPlaced }: { onPlaced: (order: Order) => void }) {
  const [fulfilment, setFulfilment] = useState<Fulfilment>("delivery");
  const [payment, setPayment] = useState<PaymentMethod>("upi");
  const [form, setForm] = useState(() => {
    const profile = profileStore.getState();
    return { name: profile.name, phone: profile.phone, email: profile.email, address: profile.address, landmark: profile.landmark, notes: "" };
  });
  const formRef = useRef<HTMLFormElement>(null);
  const { lines, couponCode, totals, isEmpty } = useCart(fulfilment);
  const { status, message, errors, submit, clearError } = useFormSubmit<OrderInput, { order: Order }>("/api/orders");
  const pending = status === "submitting";

  const set = (field: keyof typeof form) => (event: { target: { value: string } }) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    clearError(field);
  };

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    const customer = validateCustomer(form, fulfilment);
    const state = cartStore.getState();

    const result = await submit(
      Object.keys(customer.errors).length > 0
        ? { ok: false, errors: customer.errors }
        : { ok: true, data: { lines: state.lines, couponCode: totals.appliedCoupon?.code ?? null, fulfilment, payment, customer: customer.data } },
    );

    if (result.status === "success" && result.data) {
      const { order } = result.data;
      rememberOrder(order);
      saveProfile({
        name: order.customer.name,
        phone: order.customer.phone,
        email: order.customer.email ?? "",
        address: order.customer.address ?? form.address,
        landmark: order.customer.landmark ?? "",
      });
      cart.clear();
      onPlaced(order);
      scrollToTarget(0, { immediate: true });
    } else if (result.status === "error") {
      focusFirstError(formRef.current);
    }
  };

  if (isEmpty) {
    return (
      <div className={cn(card, "mx-auto flex max-w-xl flex-col items-center py-14 text-center sm:py-16")}>
        <span className="relative grid size-24 place-items-center rounded-full bg-cream text-brand-600">
          <span aria-hidden="true" className="absolute inset-0 animate-pulse-ring rounded-full bg-brand-200" />
          <ShoppingBag aria-hidden="true" className="relative size-10" strokeWidth={1.5} />
        </span>
        <h2 className="mt-7 font-display text-2xl font-extrabold tracking-[-0.02em] text-ink">Your cart is empty</h2>
        <p className="mt-2 max-w-sm text-ink-muted">Add a few dishes first — checkout takes less than a minute once you have.</p>
        <Link href="/menu" data-ripple="" className={cn(buttonStyles({ variant: "primary", size: "lg" }), "mt-8")}>
          Browse the menu
          <ArrowRight aria-hidden="true" className="size-5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="grid items-start gap-7 lg:grid-cols-[minmax(0,1fr)_26.5rem] xl:gap-10">
      {/* Forms must never be nested. The summary below has a coupon form of its own; inside this
          one, its submit event would stop at the outer form before React sees it, and the browser
          would reload the page instead of applying the code. So this form holds the details only. */}
      <form id={FORM_ID} ref={formRef} onSubmit={onSubmit} noValidate className="space-y-6">
        {/* 1 — fulfilment */}
        <fieldset className={card}>
          <legend className="sr-only">How would you like your order?</legend>
          <StepTitle step={1} title="How would you like it?" />
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {FULFILMENTS.map((option) => (
              <ChoiceCard
                key={option.value}
                name="fulfilment"
                value={option.value}
                checked={fulfilment === option.value}
                onChange={() => setFulfilment(option.value)}
                icon={option.icon}
                title={option.title}
                text={option.text}
              />
            ))}
          </div>
          {fulfilment === "pickup" && (
            <p className="mt-4 rounded-2xl bg-cream px-4 py-3 text-sm text-ink-muted">
              Collect from <strong className="font-semibold text-ink">{site.legalName}</strong>, {site.address.short}.
            </p>
          )}
        </fieldset>

        {/* 2 — details */}
        <section aria-labelledby="checkout-details" className={card}>
          <StepTitle step={2} title="Your details" id="checkout-details" />
          <div className="mt-5 grid gap-x-4 gap-y-5 sm:grid-cols-2">
            <Field id="co-name" label="Full name" error={errors.name}>
              <input {...fieldProps("co-name", errors.name)} name="name" autoComplete="name" value={form.name} onChange={set("name")} className={inputStyles} />
            </Field>
            <Field id="co-phone" label="Mobile number" error={errors.phone} hint="For delivery updates only.">
              <input
                {...fieldProps("co-phone", errors.phone, "For delivery updates only.")}
                name="phone"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                placeholder="98765 43210"
                value={form.phone}
                onChange={set("phone")}
                className={inputStyles}
              />
            </Field>
            {fulfilment === "delivery" && (
              <>
                <Field id="co-address" label="Delivery address" error={errors.address} className="sm:col-span-2">
                  <textarea
                    {...fieldProps("co-address", errors.address)}
                    name="address"
                    rows={3}
                    autoComplete="street-address"
                    placeholder="House or flat number, street, area"
                    value={form.address}
                    onChange={set("address")}
                    className={textareaStyles}
                  />
                </Field>
                <Field id="co-landmark" label="Landmark" optional>
                  <input id="co-landmark" name="landmark" placeholder="Near the petrol pump" value={form.landmark} onChange={set("landmark")} className={inputStyles} />
                </Field>
              </>
            )}
            <Field id="co-email" label="Email for the receipt" optional error={errors.email}>
              <input
                {...fieldProps("co-email", errors.email)}
                name="email"
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={set("email")}
                className={inputStyles}
              />
            </Field>
            <Field id="co-notes" label="Notes for the kitchen" optional className="sm:col-span-2">
              <textarea
                id="co-notes"
                name="notes"
                rows={2}
                maxLength={300}
                placeholder="Less spicy, no onion, ring the bell twice…"
                value={form.notes}
                onChange={set("notes")}
                className={textareaStyles}
              />
            </Field>
          </div>
        </section>

        {/* 3 — payment */}
        <fieldset className={card}>
          <legend className="sr-only">How would you like to pay?</legend>
          <StepTitle step={3} title="Payment" />
          <p className="mt-1.5 flex items-center gap-2 pl-[3.25rem] text-[0.9375rem] text-ink-muted">
            <LockKeyhole aria-hidden="true" className="size-4 text-success-ink" />
            Nothing to pay now — you pay when your order arrives.
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {PAYMENTS.map((option) => (
              <ChoiceCard
                key={option.value}
                name="payment"
                value={option.value}
                checked={payment === option.value}
                onChange={() => setPayment(option.value)}
                icon={option.icon}
                title={option.title}
                text={option.text}
              />
            ))}
          </div>
        </fieldset>
      </form>

      {/* Summary */}
      <aside aria-labelledby="checkout-summary" className={cn(card, "lg:sticky lg:top-24")}>
        <div className="flex items-baseline justify-between gap-4">
          <h2 id="checkout-summary" className="font-display text-xl font-extrabold tracking-[-0.02em] text-ink">
            Order summary
          </h2>
          <p className="text-sm text-ink-muted">{pluralize(totals.itemCount, "item")}</p>
        </div>

        {fulfilment === "delivery" && <FreeDeliveryMeter totals={totals} className="mt-5" />}
        <CartLines lines={lines} className="mt-2" />
        <CouponField totals={totals} couponCode={couponCode} className="mt-6" />
        <TotalsSummary totals={totals} fulfilment={fulfilment} className="mt-6" />

        {status === "error" && message && (
          <p role="alert" className="mt-5 rounded-2xl bg-danger/10 px-4 py-3 text-sm font-medium text-danger-ink">
            {message}
          </p>
        )}

        <SubmitButton form={FORM_ID} pending={pending} pendingLabel="Placing your order…" size="lg" fullWidth className="mt-6 hidden justify-between lg:inline-flex">
          <span>Place order</span>
          <span className="font-display font-bold tabular-nums">{formatINR(totals.total)}</span>
        </SubmitButton>
        <p className="mt-4 hidden text-center text-xs text-ink-subtle lg:block">
          By placing this order you agree to our{" "}
          <Link href="/terms" className="link-underline font-medium text-ink-muted">
            terms
          </Link>
          .
        </p>
      </aside>

      {/* Phone / tablet: sticky place-order bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-md lg:hidden">
        <div className="mx-auto flex max-w-xl items-center gap-4">
          <p className="leading-tight">
            <span className="block text-xs text-ink-muted">To pay</span>
            <span className="block font-display text-xl font-extrabold tabular-nums text-ink">{formatINR(totals.total)}</span>
          </p>
          <SubmitButton form={FORM_ID} pending={pending} pendingLabel="Placing…" size="lg" className="min-w-0 flex-1">
            Place order
            <ArrowRight aria-hidden="true" className="size-5" />
          </SubmitButton>
        </div>
      </div>
    </div>
  );
}

function StepTitle({ step, title, id }: { step: number; title: string; id?: string }) {
  return (
    <h2 id={id} className="flex items-center gap-3.5 font-display text-xl font-extrabold tracking-[-0.02em] text-ink">
      <span aria-hidden="true" className="grid size-9 place-items-center rounded-full bg-ink font-display text-sm font-extrabold text-white">
        {step}
      </span>
      {title}
    </h2>
  );
}

function ChoiceCard({
  name,
  value,
  checked,
  onChange,
  icon: ChoiceIcon,
  title,
  text,
}: {
  name: string;
  value: string;
  checked: boolean;
  onChange: () => void;
  icon: typeof Bike;
  title: string;
  text: string;
}) {
  return (
    <label
      className={cn(
        "relative flex cursor-pointer items-center gap-3.5 rounded-2xl border-2 p-4 transition-[border-color,background-color,box-shadow] duration-300 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-ink",
        checked ? "border-brand-500 bg-cream shadow-soft" : "border-line bg-white hover:border-ink/25",
      )}
    >
      <input type="radio" name={name} value={value} checked={checked} onChange={onChange} className="sr-only" />
      <span
        className={cn(
          "grid size-11 shrink-0 place-items-center rounded-xl transition-colors duration-300",
          checked ? "bg-brand-500 text-ink" : "bg-cream text-brand-600",
        )}
      >
        <ChoiceIcon aria-hidden="true" className="size-5" />
      </span>
      <span className="min-w-0 flex-1 leading-snug">
        <span className="block font-display font-bold text-ink">{title}</span>
        <span className="block text-sm text-ink-muted">{text}</span>
      </span>
      <span
        aria-hidden="true"
        className={cn(
          "grid size-6 shrink-0 place-items-center rounded-full border-2 transition-colors duration-300",
          checked ? "border-ink bg-ink text-white" : "border-field bg-white text-transparent",
        )}
      >
        <Check className="size-3.5" strokeWidth={3.5} />
      </span>
    </label>
  );
}

/* ── Confirmation ────────────────────────────────────────────────────────── */
function OrderConfirmation({ order }: { order: Order }) {
  const now = useNow();
  const progress = getOrderProgress(order, new Date(now || Date.parse(order.placedAt)));
  const firstName = order.customer.name.split(" ")[0];
  const pickup = order.fulfilment === "pickup";

  return (
    <div className="mx-auto grid max-w-5xl items-start gap-7 lg:grid-cols-[minmax(0,1fr)_24rem]">
      <section aria-labelledby="order-placed" className={card}>
        <div role="status" className="flex flex-col items-center text-center">
          <SuccessCheck />
          <p className="eyebrow mt-6 text-brand-700">Order {order.id}</p>
          <h2 id="order-placed" className="mt-2 font-display text-[1.75rem] font-extrabold leading-tight tracking-[-0.03em] text-ink sm:text-[2.25rem]">
            Thank you, {firstName}! Your order is in.
          </h2>
          <p className="mt-3 max-w-md text-[1.0625rem] text-ink-muted">
            {progress.done
              ? pickup
                ? "It is packed and waiting at the counter."
                : "It should be with you by now — enjoy!"
              : pickup
                ? `It will be ready to collect in about ${progress.minutesLeft} minutes.`
                : `We will be at your door in about ${progress.minutesLeft} minutes.`}
          </p>
        </div>

        {/* Live tracker */}
        <ol aria-label="Order progress" className="mx-auto mt-9 max-w-md">
          {progress.stages.map((stage, index) => {
            const done = index < progress.current || (progress.done && index === progress.current);
            const active = index === progress.current && !progress.done;
            const last = index === progress.stages.length - 1;
            return (
              <li key={stage.key} aria-current={active ? "step" : undefined} className="relative flex gap-4 pb-7 last:pb-0">
                {!last && (
                  <span
                    aria-hidden="true"
                    className={cn("absolute left-[1.0625rem] top-9 h-[calc(100%-2.25rem)] w-0.5 rounded-full", done ? "bg-success" : "bg-line")}
                  />
                )}
                <span
                  className={cn(
                    "relative grid size-9 shrink-0 place-items-center rounded-full font-display text-sm font-extrabold transition-colors duration-500",
                    done && "bg-success text-ink",
                    active && "bg-brand-500 text-ink",
                    !done && !active && "bg-ink/[0.07] text-ink-subtle",
                  )}
                >
                  {active && <span aria-hidden="true" className="absolute inset-0 animate-pulse-ring rounded-full bg-brand-500" />}
                  {done ? <Check aria-hidden="true" className="size-[1.125rem]" strokeWidth={3} /> : <span className="relative">{index + 1}</span>}
                </span>
                <div className="pt-1 leading-snug">
                  <p className={cn("font-display font-bold", done || active ? "text-ink" : "text-ink-subtle")}>
                    {stage.label}
                    {active && <span className="ml-2 rounded-full bg-brand-100 px-2 py-0.5 text-xs font-semibold text-brand-800">Now</span>}
                  </p>
                  <p className="text-sm text-ink-muted">{stage.description}</p>
                </div>
              </li>
            );
          })}
        </ol>

        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Link href="/menu" data-ripple="" className={buttonStyles({ variant: "dark" })}>
            Order something else
          </Link>
          <ButtonAnchor href={site.phone.href} variant="outline">
            <Phone aria-hidden="true" className="size-4 text-brand-600" />
            Call the restaurant
          </ButtonAnchor>
        </div>
      </section>

      <aside aria-labelledby="order-receipt" className={card}>
        <h2 id="order-receipt" className="font-display text-xl font-extrabold tracking-[-0.02em] text-ink">
          Receipt
        </h2>
        <ul className="mt-4 divide-y divide-line">
          {order.lines.map((line) => (
            <li key={line.dishId} className="flex items-start justify-between gap-4 py-3 text-[0.9375rem]">
              <span className="text-ink">
                <span className="font-semibold tabular-nums">{line.quantity} ×</span> {line.name}
              </span>
              <span className="shrink-0 font-medium tabular-nums text-ink">{formatINR(line.unitPrice * line.quantity)}</span>
            </li>
          ))}
        </ul>
        <TotalsSummary
          totals={{ ...order.totals, freeDeliveryRemaining: 0, freeDeliveryProgress: 1, appliedCoupon: null, couponError: null }}
          fulfilment={order.fulfilment}
          className="mt-4 border-t border-line pt-4"
        />
        <dl className="mt-6 space-y-3 rounded-2xl bg-cream p-4 text-sm">
          <div>
            <dt className="font-semibold text-ink">{pickup ? "Collect from" : "Delivering to"}</dt>
            <dd className="mt-0.5 whitespace-pre-line text-ink-muted">
              {pickup ? `${site.legalName}, ${site.address.short}` : [order.customer.address, order.customer.landmark].filter(Boolean).join("\n")}
            </dd>
          </div>
          <div>
            <dt className="font-semibold text-ink">Payment</dt>
            <dd className="mt-0.5 text-ink-muted">
              {PAYMENT_LABEL[order.payment]} · {formatINR(order.totals.total)}
            </dd>
          </div>
        </dl>
        <p className="mt-4 text-xs text-ink-subtle">You can find this order any time under your account.</p>
      </aside>
    </div>
  );
}

/* ── Skeleton ────────────────────────────────────────────────────────────── */
function CheckoutSkeleton() {
  return (
    <div aria-busy="true" aria-label="Loading your cart" className="grid items-start gap-7 lg:grid-cols-[minmax(0,1fr)_26.5rem] xl:gap-10">
      <div className="space-y-6">
        {[9, 18, 9].map((rem, index) => (
          <div key={index} className={card}>
            <div className="skeleton h-8 w-56 rounded-full" />
            <div className="skeleton mt-5 rounded-2xl" style={{ height: `${rem}rem` }} />
          </div>
        ))}
      </div>
      <div className={card}>
        <div className="skeleton h-8 w-44 rounded-full" />
        <div className="mt-6 space-y-4">
          {[0, 1, 2].map((index) => (
            <div key={index} className="flex gap-4">
              <div className="skeleton size-[4.5rem] shrink-0 rounded-2xl" />
              <div className="flex-1 space-y-2.5 pt-1">
                <div className="skeleton h-4 w-3/4 rounded-full" />
                <div className="skeleton h-4 w-1/3 rounded-full" />
              </div>
            </div>
          ))}
        </div>
        <div className="skeleton mt-7 h-14 rounded-full" />
      </div>
    </div>
  );
}
