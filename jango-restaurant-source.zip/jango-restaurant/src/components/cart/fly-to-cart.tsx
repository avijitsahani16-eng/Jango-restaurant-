"use client";

import * as m from "framer-motion/m";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

import { prefersReducedMotion } from "@/lib/scroll";
import { CART_ADD_EVENT, type CartAddDetail } from "@/stores/cart";

interface Flight {
  id: number;
  src: string;
  left: number;
  top: number;
  width: number;
  height: number;
  dx: number;
  dy: number;
}

let flightId = 0;

/** The cart button that is actually on screen (desktop header or mobile bar). */
function cartTarget(): DOMRect | null {
  for (const element of document.querySelectorAll<HTMLElement>("[data-cart-target]")) {
    const rect = element.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) return rect;
  }
  return null;
}

/**
 * Cart micro-interaction: a thumbnail of the dish arcs from its card into the
 * cart button. Purely decorative — the toast and badge carry the information.
 */
export function FlyToCart() {
  const [flights, setFlights] = useState<readonly Flight[]>([]);

  useEffect(() => {
    const onAdd = (event: Event) => {
      const { from, imageSrc } = (event as CustomEvent<CartAddDetail>).detail;
      if (!from || !imageSrc || prefersReducedMotion()) return;
      const target = cartTarget();
      if (!target) return;

      const size = Math.min(from.width, from.height, 120);
      const left = from.left + (from.width - size) / 2;
      const top = from.top + (from.height - size) / 2;
      setFlights((current) => [
        ...current,
        {
          id: ++flightId,
          src: imageSrc,
          left,
          top,
          width: size,
          height: size,
          dx: target.left + target.width / 2 - (left + size / 2),
          dy: target.top + target.height / 2 - (top + size / 2),
        },
      ]);
    };

    window.addEventListener(CART_ADD_EVENT, onAdd);
    return () => window.removeEventListener(CART_ADD_EVENT, onAdd);
  }, []);

  if (flights.length === 0) return null;

  return createPortal(
    flights.map((flight) => (
      <m.div
        key={flight.id}
        aria-hidden="true"
        className="pointer-events-none fixed z-[95] overflow-hidden rounded-full bg-cream shadow-lift ring-2 ring-white"
        style={{ left: flight.left, top: flight.top, width: flight.width, height: flight.height }}
        initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
        animate={{
          x: flight.dx,
          y: [0, Math.min(flight.dy * 0.4, 0) - 70, flight.dy],
          scale: [1, 0.62, 0.16],
          opacity: [1, 1, 0.35],
        }}
        transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1], times: [0, 0.45, 1] }}
        onAnimationComplete={() => setFlights((current) => current.filter((item) => item.id !== flight.id))}
      >
        {/* eslint-disable-next-line @next/next/no-img-element -- re-uses the already-decoded card image */}
        <img src={flight.src} alt="" className="size-full object-cover" />
      </m.div>
    )),
    document.body,
  );
}
