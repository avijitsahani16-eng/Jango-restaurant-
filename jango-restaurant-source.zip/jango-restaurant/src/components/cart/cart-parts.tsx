"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { BadgeCheck, Bike, Tag, X } from "lucide-react";
import { useId, useState, type FormEvent } from "react";

import { DishTile } from "@/components/menu/dish-card";
import { QuickViewTrigger } from "@/components/menu/dish-actions";
import { QuantityStepper } from "@/components/menu/quantity-stepper";
import { DietMark } from "@/components/ui/primitives";
import { featuredCoupon, site } from "@/config/site";
import type { DetailedLine } from "@/hooks/use-cart";
import { cn } from "@/lib/cn";
import { formatINR } from "@/lib/format";
import { cart } from "@/stores/cart";
import type { CartTotals, Fulfilment } from "@/types";

/* ── Free-delivery meter ─────────────────────────────────────────────────── */
export function FreeDeliveryMeter({ totals, className }: { totals: CartTotals; className?: string }) {
  const unlocked = totals.freeDeliveryRemaining === 0;
  return (
    <div className={cn("rounded-2xl bg-cream p-4", className)}>
      <p className="flex items-center gap-2.5 text-sm font-medium text-ink">
        <span className={cn("grid size-8 shrink-0 place-items-center rounded-full", unlocked ? "bg-success text-ink" : "bg-white text-brand-600")}>
          {unlocked ? <BadgeCheck aria-hidden="true" className="size-[1.125rem]" /> : <Bike aria-hidden="true" className="size-[1.125rem]" />}
        </span>
        <span aria-live="polite">
          {unlocked ? (
            "You’ve unlocked free delivery."
          ) : (
            <>
              Add <strong className="font-bold">{formatINR(totals.freeDeliveryRemaining)}</strong> more for free delivery.
            </>
          )}
        </span>
      </p>
      <div
        role="progressbar"
        aria-label="Progress towards free delivery"
        aria-valuemin={0}
        aria-valuemax={site.delivery.freeThreshold}
        aria-valuenow={Math.min(totals.subtotal, site.delivery.freeThreshold)}
        className="mt-3 h-1.5 overflow-hidden rounded-full bg-ink/10"
      >
        <div
          className={cn("h-full rounded-full transition-[width,background-color] duration-700 ease-out-expo", unlocked ? "bg-success" : "bg-brand-500")}
          style={{ width: `${Math.round(totals.freeDeliveryProgress * 100)}%` }}
        />
      </div>
    </div>
  );
}

/* ── Lines ───────────────────────────────────────────────────────────────── */
export function CartLines({ lines, className }: { lines: DetailedLine[]; className?: string }) {
  return (
    <ul className={cn("flex flex-col", className)}>
      <AnimatePresence initial={false}>
        {lines.map(({ dish, quantity, lineTotal }) => (
          <m.li
            key={dish.id}
            layout
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden"
          >
            <div className="flex gap-3.5 border-b border-line py-4">
              <DishTile dish={dish} className="size-[4.5rem] rounded-2xl" />
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-start justify-between gap-3">
                  <p className="flex min-w-0 items-start gap-2 font-display text-[0.9375rem] font-bold leading-snug text-ink">
                    <DietMark diet={dish.diet} className="mt-0.5" />
                    <QuickViewTrigger dishId={dish.id} className="rounded text-left hover:text-brand-700">
                      {dish.name}
                    </QuickViewTrigger>
                  </p>
                  <p className="shrink-0 font-display text-[0.9375rem] font-bold tabular-nums text-ink">{formatINR(lineTotal)}</p>
                </div>
                <p className="mt-0.5 text-sm text-ink-subtle">{formatINR(dish.price)} each</p>
                <div className="mt-auto flex items-center justify-between pt-2">
                  <QuantityStepper
                    quantity={quantity}
                    label={dish.name}
                    size="sm"
                    tone="neutral"
                    removable
                    onChange={(next) => cart.setQuantity(dish.id, next)}
                  />
                  <button
                    type="button"
                    onClick={() => cart.remove(dish.id)}
                    aria-label={`Remove ${dish.name} from cart`}
                    className="link-underline h-9 text-sm font-medium text-ink-muted hover:text-danger-ink"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          </m.li>
        ))}
      </AnimatePresence>
    </ul>
  );
}

/* ── Coupon ──────────────────────────────────────────────────────────────── */
export function CouponField({ totals, couponCode, className }: { totals: CartTotals; couponCode: string | null; className?: string }) {
  const id = useId();
  const [code, setCode] = useState("");
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const result = cart.applyCoupon(code);
    setFeedback(result);
    if (result.ok) setCode("");
  };

  if (totals.appliedCoupon) {
    return (
      <div className={cn("flex items-center justify-between gap-3 rounded-2xl border border-dashed border-success-ink/50 bg-success/10 px-4 py-3", className)}>
        <p className="flex min-w-0 items-center gap-2.5 text-sm text-ink">
          <Tag aria-hidden="true" className="size-4 shrink-0 text-success-ink" />
          <span className="min-w-0">
            <strong className="font-bold">{totals.appliedCoupon.code}</strong> applied — you save {formatINR(totals.discount)}
          </span>
        </p>
        <button
          type="button"
          onClick={() => {
            cart.removeCoupon();
            setFeedback(null);
          }}
          aria-label={`Remove coupon ${totals.appliedCoupon.code}`}
          className="grid size-9 shrink-0 place-items-center rounded-full text-ink-muted hover:bg-ink/[0.06] hover:text-ink"
        >
          <X aria-hidden="true" className="size-4" />
        </button>
      </div>
    );
  }

  // A saved code that no longer qualifies (e.g. items were removed).
  const stale = couponCode && totals.couponError ? totals.couponError : null;
  const message = feedback && !feedback.ok ? feedback.message : stale;

  return (
    <form onSubmit={submit} noValidate className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold text-ink">
        Have a coupon?
      </label>
      <div className="flex gap-2">
        <input
          id={id}
          name="coupon"
          value={code}
          onChange={(event) => {
            setCode(event.target.value.toUpperCase());
            setFeedback(null);
          }}
          placeholder={featuredCoupon.code}
          autoComplete="off"
          autoCapitalize="characters"
          spellCheck={false}
          maxLength={24}
          aria-invalid={message ? true : undefined}
          aria-describedby={`${id}-help`}
          className="h-11 min-w-0 flex-1 rounded-full border border-field bg-white px-4 text-[0.9375rem] font-medium uppercase tracking-wide text-ink placeholder:font-normal placeholder:normal-case placeholder:tracking-normal placeholder:text-ink-subtle focus:border-ink focus:outline-none focus:ring-4 focus:ring-brand-500/25 aria-[invalid=true]:border-danger"
        />
        <button
          type="submit"
          data-ripple=""
          className="h-11 shrink-0 rounded-full bg-ink px-5 text-sm font-medium text-white transition-colors hover:bg-ink-soft"
        >
          Apply
        </button>
      </div>
      <p id={`${id}-help`} role={message ? "alert" : undefined} className={cn("mt-1.5 text-sm", message ? "font-medium text-danger-ink" : "text-ink-subtle")}>
        {message ?? `Try ${featuredCoupon.code} — ${featuredCoupon.description}`}
      </p>
    </form>
  );
}

/* ── Totals ──────────────────────────────────────────────────────────────── */
export function TotalsSummary({ totals, fulfilment = "delivery", className }: { totals: CartTotals; fulfilment?: Fulfilment; className?: string }) {
  const row = "flex items-center justify-between gap-4";
  return (
    <dl className={cn("space-y-2.5 text-[0.9375rem]", className)}>
      <div className={row}>
        <dt className="text-ink-muted">Item total</dt>
        <dd className="font-medium tabular-nums text-ink">{formatINR(totals.subtotal)}</dd>
      </div>
      {totals.discount > 0 && (
        <div className={row}>
          <dt className="text-ink-muted">Coupon{totals.appliedCoupon ? ` (${totals.appliedCoupon.code})` : ""}</dt>
          <dd className="font-medium tabular-nums text-success-ink">−{formatINR(totals.discount)}</dd>
        </div>
      )}
      <div className={row}>
        <dt className="text-ink-muted">{fulfilment === "pickup" ? "Pickup" : "Delivery"}</dt>
        <dd className={cn("font-medium tabular-nums", totals.deliveryFee === 0 ? "text-success-ink" : "text-ink")}>
          {totals.deliveryFee === 0 ? "Free" : formatINR(totals.deliveryFee)}
        </dd>
      </div>
      <div className={row}>
        <dt className="text-ink-muted">GST ({Math.round(site.taxRate * 100)}%)</dt>
        <dd className="font-medium tabular-nums text-ink">{formatINR(totals.tax)}</dd>
      </div>
      <div className={cn(row, "border-t border-line pt-3.5")}>
        <dt className="font-display text-base font-bold text-ink">To pay</dt>
        <dd className="font-display text-xl font-extrabold tabular-nums text-ink">{formatINR(totals.total)}</dd>
      </div>
    </dl>
  );
}
