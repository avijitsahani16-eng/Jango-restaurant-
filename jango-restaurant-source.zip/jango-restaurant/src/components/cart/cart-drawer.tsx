"use client";

import { ArrowRight, ShoppingBag, X } from "lucide-react";
import Link from "next/link";
import { useMemo } from "react";

import { DishTile } from "@/components/menu/dish-card";
import { buttonStyles, iconButtonStyles } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { dishes } from "@/data/dishes";
import { useCart } from "@/hooks/use-cart";
import { cn } from "@/lib/cn";
import { formatINR, pluralize } from "@/lib/format";
import { cart } from "@/stores/cart";
import { ui } from "@/stores/ui";

import { CartLines, CouponField, FreeDeliveryMeter, TotalsSummary } from "./cart-parts";

export function CartDrawer({ open }: { open: boolean }) {
  const { lines, couponCode, totals, isEmpty } = useCart();

  /* A gentle upsell: the best-rated dishes that are not in the cart yet. */
  const suggestions = useMemo(() => {
    const inCart = new Set(lines.map((line) => line.dish.id));
    return dishes
      .filter((dish) => !inCart.has(dish.id) && (dish.category === "desserts" || dish.category === "drinks" || dish.price < 200))
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 3);
  }, [lines]);

  return (
    <Modal open={open} onClose={ui.close} variant="drawer" labelledBy="cart-title">
      <header className="flex items-center justify-between gap-4 border-b border-line px-5 py-4 sm:px-6">
        <div>
          <h2 id="cart-title" className="font-display text-xl font-extrabold tracking-[-0.02em] text-ink">
            Your cart
          </h2>
          <p className="text-sm text-ink-muted" aria-live="polite">
            {isEmpty ? "Nothing here yet" : `${pluralize(totals.itemCount, "item")} · ${formatINR(totals.subtotal)}`}
          </p>
        </div>
        <button type="button" onClick={ui.close} aria-label="Close cart" className={iconButtonStyles("light")}>
          <X aria-hidden="true" className="size-5" />
        </button>
      </header>

      {isEmpty ? (
        <div className="flex flex-1 flex-col items-center justify-center px-8 pb-10 text-center">
          <span className="relative grid size-24 place-items-center rounded-full bg-cream text-brand-600">
            <span aria-hidden="true" className="absolute inset-0 animate-pulse-ring rounded-full bg-brand-200" />
            <ShoppingBag aria-hidden="true" className="relative size-10" strokeWidth={1.5} />
          </span>
          <h3 className="mt-6 font-display text-xl font-extrabold tracking-[-0.02em] text-ink">Your cart is hungry</h3>
          <p className="mt-2 max-w-64 text-[0.9375rem] text-ink-muted">Add a few favourites and they will show up here, ready for checkout.</p>
          <Link href="/menu" onClick={ui.close} data-ripple="" className={cn(buttonStyles({ variant: "primary" }), "mt-7")}>
            Browse the menu
            <ArrowRight aria-hidden="true" className="size-4" />
          </Link>
        </div>
      ) : (
        <>
          <div className="flex-1 overflow-y-auto overscroll-contain px-5 pb-6 sm:px-6" data-lenis-prevent="">
            <FreeDeliveryMeter totals={totals} className="mt-5" />
            <CartLines lines={lines} className="mt-1" />

            {suggestions.length > 0 && (
              <section aria-labelledby="cart-suggestions" className="mt-6">
                <h3 id="cart-suggestions" className="font-display text-sm font-bold uppercase tracking-[0.1em] text-ink-subtle">
                  Goes well with your order
                </h3>
                <ul className="mt-3 space-y-2">
                  {suggestions.map((dish) => (
                    <li key={dish.id} className="flex items-center gap-3 rounded-2xl bg-white p-2 pr-2.5 ring-1 ring-ink/[0.06]">
                      <DishTile dish={dish} className="size-11 rounded-xl" iconClassName="size-5" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-ink">{dish.name}</span>
                        <span className="block text-sm text-ink-subtle">{formatINR(dish.price)}</span>
                      </span>
                      <button
                        type="button"
                        data-ripple=""
                        onClick={() => cart.add(dish.id, { silent: true })}
                        aria-label={`Add ${dish.name} to cart`}
                        className="h-9 shrink-0 rounded-full bg-cream px-4 text-sm font-medium text-ink ring-1 ring-inset ring-brand-200 transition-colors hover:bg-brand-100"
                      >
                        Add
                      </button>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            <CouponField totals={totals} couponCode={couponCode} className="mt-7" />
          </div>

          <footer className="border-t border-line bg-white px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-5 shadow-[0_-12px_30px_-18px_rgb(17_24_39/0.25)] sm:rounded-bl-panel sm:px-6">
            <TotalsSummary totals={totals} />
            <Link
              href="/checkout"
              onClick={ui.close}
              data-ripple=""
              className={cn(buttonStyles({ variant: "primary", size: "lg", fullWidth: true }), "mt-5 justify-between")}
            >
              <span>Go to checkout</span>
              <span className="flex items-center gap-2 font-display font-bold tabular-nums">
                {formatINR(totals.total)}
                <ArrowRight aria-hidden="true" className="size-5" />
              </span>
            </Link>
            <p className="mt-3 text-center text-xs text-ink-subtle">Taxes included above. Pay by UPI, card or cash on delivery.</p>
          </footer>
        </>
      )}
    </Modal>
  );
}
