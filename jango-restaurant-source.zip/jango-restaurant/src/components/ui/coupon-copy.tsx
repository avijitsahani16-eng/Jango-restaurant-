"use client";

import { Check, Copy } from "lucide-react";
import { useRef, useState } from "react";

import { cn } from "@/lib/cn";
import { cartStore } from "@/stores/cart";
import { showToast } from "@/stores/toast";

/**
 * Coupon chip: copies the code to the clipboard and pre-loads it into the
 * cart, so the discount applies by itself as soon as the order qualifies.
 */
export function CouponCopy({ code, className }: { code: string; className?: string }) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<number | undefined>(undefined);

  const onClick = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      /* Clipboard can be blocked; the code is still saved to the cart below. */
    }
    cartStore.setState((state) => ({ ...state, couponCode: code }));
    setCopied(true);
    showToast({ title: `${code} copied`, description: "Saved to your cart — it applies at checkout." });
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setCopied(false), 2400);
  };

  return (
    <button
      type="button"
      onClick={onClick}
      data-ripple=""
      aria-label={copied ? `Use code ${code} — copied` : `Use code ${code} — copy it`}
      className={cn(
        "group inline-flex h-14 items-center gap-4 rounded-2xl border-2 border-dashed border-brand-400/70 bg-white/[0.06] pl-5 pr-3 text-white transition-[background-color,border-color] duration-300 hover:border-brand-400 hover:bg-white/10",
        className,
      )}
    >
      <span className="text-left leading-none">
        <span className="block text-[0.6875rem] font-semibold uppercase tracking-[0.14em] text-white/70">Use code</span>
        <span className="mt-1 block font-display text-xl font-extrabold tracking-[0.08em] text-brand-400">{code}</span>
      </span>
      <span
        className={cn(
          "grid size-9 place-items-center rounded-xl transition-colors duration-300",
          copied ? "bg-success text-ink" : "bg-white/10 text-white group-hover:bg-brand-500 group-hover:text-ink",
        )}
      >
        {copied ? <Check aria-hidden="true" className="size-[1.125rem] animate-pop" strokeWidth={3} /> : <Copy aria-hidden="true" className="size-[1.125rem]" />}
      </span>
      <span className="sr-only" aria-live="polite">
        {copied ? "Copied to clipboard" : ""}
      </span>
    </button>
  );
}
