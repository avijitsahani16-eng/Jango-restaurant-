"use client";

import * as m from "framer-motion/m";
import { LoaderCircle } from "lucide-react";
import type { ComponentProps } from "react";

import { cn } from "@/lib/cn";

import { Button, type ButtonStyleProps } from "./button";

/** Honeypot: invisible to people, irresistible to bots. The API silently drops anything that fills it. */
export function Honeypot({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div aria-hidden="true" className="absolute left-[-9999px] top-auto size-px overflow-hidden">
      <label>
        Company
        <input type="text" name="company" tabIndex={-1} autoComplete="off" value={value} onChange={(event) => onChange(event.target.value)} />
      </label>
    </div>
  );
}

type SubmitButtonProps = ComponentProps<"button"> & ButtonStyleProps & { pending: boolean; pendingLabel?: string };

export function SubmitButton({ pending, pendingLabel = "Sending…", children, className, ...props }: SubmitButtonProps) {
  return (
    <Button type="submit" aria-disabled={pending || undefined} className={cn(pending && "pointer-events-none", className)} {...props}>
      {pending ? (
        <>
          <LoaderCircle aria-hidden="true" className="size-5 animate-spin" />
          {pendingLabel}
        </>
      ) : (
        children
      )}
    </Button>
  );
}

/** A tick that draws itself — the shared success animation. */
export function SuccessCheck({ className, tone = "success" }: { className?: string; tone?: "success" | "brand" }) {
  return (
    <m.span
      aria-hidden="true"
      initial={{ scale: 0.4, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 260, damping: 16 }}
      className={cn(
        "relative grid size-16 place-items-center rounded-full",
        tone === "success" ? "bg-success text-ink" : "bg-ink text-brand-400",
        className,
      )}
    >
      <span className={cn("absolute inset-0 animate-pulse-ring rounded-full", tone === "success" ? "bg-success" : "bg-ink")} />
      <svg viewBox="0 0 24 24" className="relative size-8" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round">
        <m.path
          d="M5 12.5 10 17.5 19.5 7"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        />
      </svg>
    </m.span>
  );
}
