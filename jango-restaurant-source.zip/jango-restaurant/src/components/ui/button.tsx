import Link from "next/link";
import type { ComponentProps } from "react";

import { cn } from "@/lib/cn";

export type ButtonVariant = "primary" | "dark" | "outline" | "ghost" | "light" | "glass";
export type ButtonSize = "sm" | "md" | "lg";

const base =
  "inline-flex shrink-0 select-none items-center justify-center whitespace-nowrap rounded-full font-medium tracking-[-0.01em] transition-[background-color,box-shadow,translate,color,scale] duration-300 ease-out-expo active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50";

const variants: Record<ButtonVariant, string> = {
  // Charcoal on brand orange = 6.3:1 (white on #F97316 is only 2.8:1).
  primary: "bg-brand-500 text-ink shadow-glow hover:-translate-y-0.5 hover:bg-brand-400",
  dark: "bg-ink text-white shadow-card hover:-translate-y-0.5 hover:bg-ink-soft",
  outline: "bg-white text-ink ring-1 ring-inset ring-ink/15 hover:-translate-y-0.5 hover:bg-cream hover:ring-ink/30",
  ghost: "text-ink hover:bg-ink/[0.06]",
  light: "bg-white text-ink shadow-card hover:-translate-y-0.5 hover:bg-brand-50",
  glass: "bg-white/10 text-white ring-1 ring-inset ring-white/25 backdrop-blur hover:bg-white/[0.18]",
};

const sizes: Record<ButtonSize, string> = {
  sm: "h-11 gap-1.5 px-5 text-sm",
  md: "h-12 gap-2 px-6 text-[0.9375rem]",
  lg: "h-14 gap-2.5 px-8 text-base",
};

export interface ButtonStyleProps {
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
}

/** Class string for anything that should look like a button. */
export function buttonStyles({ variant = "primary", size = "md", fullWidth = false }: ButtonStyleProps = {}): string {
  return cn(base, variants[variant], sizes[size], fullWidth && "w-full");
}

type ButtonProps = ComponentProps<"button"> & ButtonStyleProps;

export function Button({ variant, size, fullWidth, className, type = "button", ...props }: ButtonProps) {
  return <button type={type} data-ripple="" className={cn(buttonStyles({ variant, size, fullWidth }), className)} {...props} />;
}

type ButtonLinkProps = ComponentProps<typeof Link> & ButtonStyleProps;

export function ButtonLink({ variant, size, fullWidth, className, ...props }: ButtonLinkProps) {
  return <Link data-ripple="" className={cn(buttonStyles({ variant, size, fullWidth }), className)} {...props} />;
}

type ButtonAnchorProps = ComponentProps<"a"> & ButtonStyleProps;

/** For external links, `tel:` and `mailto:`. */
export function ButtonAnchor({ variant, size, fullWidth, className, ...props }: ButtonAnchorProps) {
  return <a data-ripple="" className={cn(buttonStyles({ variant, size, fullWidth }), className)} {...props} />;
}

/** Square-ish icon button with a 44px touch target. */
export function iconButtonStyles(tone: "light" | "dark" | "plain" = "plain"): string {
  return cn(
    "relative inline-grid size-11 shrink-0 place-items-center rounded-full transition-[background-color,color,scale,box-shadow] duration-300 ease-out-expo active:scale-95",
    tone === "plain" && "text-ink hover:bg-ink/[0.06]",
    tone === "light" && "bg-white text-ink shadow-soft ring-1 ring-ink/5 hover:bg-cream",
    tone === "dark" && "bg-white/10 text-white ring-1 ring-inset ring-white/15 hover:bg-white/20",
  );
}
