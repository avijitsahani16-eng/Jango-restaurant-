"use client";

import { animate, useInView } from "framer-motion";
import { useEffect, useRef } from "react";

import { prefersReducedMotion } from "@/lib/scroll";

interface CounterProps {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}

/**
 * Counts up to `value` the first time it scrolls into view.
 * The final value is server-rendered (and read to assistive tech); only the
 * visual digits animate.
 */
export function Counter({ value, decimals = 0, prefix = "", suffix = "", duration = 1.8, className }: CounterProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -12% 0px" });
  const final = `${prefix}${value.toFixed(decimals)}${suffix}`;

  useEffect(() => {
    const node = ref.current;
    if (!inView || !node || prefersReducedMotion()) return;
    const controls = animate(0, value, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (latest) => {
        node.textContent = `${prefix}${latest.toFixed(decimals)}${suffix}`;
      },
    });
    return () => controls.stop();
  }, [inView, value, decimals, prefix, suffix, duration]);

  return (
    <span className={className}>
      <span ref={ref} aria-hidden="true" className="tabular-nums">
        {final}
      </span>
      <span className="sr-only">{final}</span>
    </span>
  );
}
