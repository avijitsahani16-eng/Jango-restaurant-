import { cn } from "@/lib/cn";

/**
 * Jango mark — a lower-case "j" whose dot is a flame.
 * Original artwork, drawn for this site.
 */
export function LogoMark({ className, title }: { className?: string; title?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={cn("size-10", className)}
      role={title ? "img" : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      focusable="false"
    >
      <rect width="48" height="48" rx="15" fill="#F97316" />
      {/* flame */}
      <path
        d="M28.9 6.6c3.2 2.7 4.9 5.3 4.9 7.8a5 5 0 0 1-10 0c0-1.7.7-3.3 2-4.7.3 1.1.9 1.9 1.7 2.4-.2-2.1.3-3.9 1.4-5.5Z"
        fill="#111827"
      />
      {/* stem + hook */}
      <path d="M28.8 23v9.6A8.4 8.4 0 0 1 20.4 41h-2.6" fill="none" stroke="#111827" strokeWidth="5.8" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({
  className,
  tone = "dark",
  compact = false,
}: {
  className?: string;
  /** `dark` text for light surfaces, `light` text for dark surfaces. */
  tone?: "dark" | "light";
  /** Hide the descriptor line. */
  compact?: boolean;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark className="size-10 shrink-0 drop-shadow-[0_6px_10px_rgb(249_115_22/0.35)]" />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[1.5rem] font-extrabold tracking-[-0.04em]",
            tone === "dark" ? "text-ink" : "text-white",
          )}
        >
          Jango
        </span>
        {!compact && (
          <span
            className={cn(
              "mt-1 font-display text-[0.5625rem] font-bold uppercase tracking-[0.2em] max-[359px]:hidden",
              tone === "dark" ? "text-ink-subtle" : "text-white/70",
            )}
          >
            Restaurant &amp; Bar
          </span>
        )}
      </span>
    </span>
  );
}
