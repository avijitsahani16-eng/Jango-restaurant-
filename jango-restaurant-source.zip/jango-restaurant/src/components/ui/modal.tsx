"use client";

import { AnimatePresence, type TargetAndTransition } from "framer-motion";
import * as m from "framer-motion/m";
import { useEffect, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";

import { useFocusTrap } from "@/hooks/use-focus-trap";
import { useHydrated } from "@/hooks/use-store";
import { cn } from "@/lib/cn";
import { lockScroll, unlockScroll } from "@/lib/scroll";

export type ModalVariant = "center" | "drawer" | "top" | "full";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  /** id of the element that titles the dialog. */
  labelledBy?: string;
  /** Use instead of `labelledBy` when there is no visible title. */
  label?: string;
  variant?: ModalVariant;
  /** Classes for the panel (width, background…). */
  className?: string;
  children: ReactNode;
}

const EASE = [0.16, 1, 0.3, 1] as const;

const layout: Record<ModalVariant, string> = {
  center: "items-end justify-center sm:items-center sm:p-6",
  drawer: "justify-end",
  top: "items-start justify-center px-3 pt-3 sm:px-6 sm:pt-[9vh]",
  full: "",
};

const panel: Record<ModalVariant, string> = {
  center:
    "max-h-[92dvh] w-full overflow-y-auto overscroll-contain rounded-t-panel bg-white shadow-lift sm:max-h-[90dvh] sm:rounded-panel",
  drawer: "flex h-full w-full max-w-[27.5rem] flex-col bg-canvas shadow-lift sm:rounded-l-panel",
  top: "max-h-[80dvh] w-full max-w-2xl overflow-hidden rounded-panel bg-white shadow-lift",
  full: "h-full w-full",
};

const motionFor: Record<ModalVariant, { initial: TargetAndTransition; animate: TargetAndTransition; exit: TargetAndTransition }> = {
  center: { initial: { opacity: 0, y: 48, scale: 0.97 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, y: 32, scale: 0.98 } },
  drawer: { initial: { x: "100%" }, animate: { x: 0 }, exit: { x: "100%" } },
  top: { initial: { opacity: 0, y: -24, scale: 0.98 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, y: -16, scale: 0.98 } },
  full: { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } },
};

/* Focus goes back to whatever opened the first overlay, even when one overlay hands over to another. */
let openCount = 0;
let returnFocusTo: HTMLElement | null = null;

/**
 * Accessible modal surface: portal, backdrop, focus trap, Escape to close,
 * scroll lock, inert page behind, and focus restored to the trigger.
 */
export function Modal({ open, onClose, labelledBy, label, variant = "center", className, children }: ModalProps) {
  const hydrated = useHydrated();
  const panelRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);

  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  useFocusTrap(panelRef, open);

  useEffect(() => {
    if (!open) return;

    const active = document.activeElement;
    if (openCount === 0 && active instanceof HTMLElement && !active.closest("[role='dialog']")) {
      returnFocusTo = active;
    }
    openCount += 1;
    lockScroll();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        onCloseRef.current();
      }
    };
    document.addEventListener("keydown", onKeyDown);

    return () => {
      document.removeEventListener("keydown", onKeyDown);
      unlockScroll();
      openCount -= 1;
      requestAnimationFrame(() => {
        if (openCount === 0 && returnFocusTo?.isConnected) {
          returnFocusTo.focus({ preventScroll: true });
          returnFocusTo = null;
        }
      });
    };
  }, [open]);

  if (!hydrated) return null;

  const transition = motionFor[variant];

  return createPortal(
    <AnimatePresence>
      {open && (
        <div key="modal" className={cn("fixed inset-0 z-[70] flex", layout[variant])}>
          <m.div
            aria-hidden="true"
            className="absolute inset-0 bg-ink/55 backdrop-blur-[3px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
          />
          <m.div
            ref={panelRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={labelledBy}
            aria-label={label}
            tabIndex={-1}
            data-lenis-prevent=""
            className={cn("relative outline-none", panel[variant], className)}
            initial={transition.initial}
            animate={transition.animate}
            exit={transition.exit}
            transition={{ duration: 0.45, ease: EASE }}
          >
            {children}
          </m.div>
        </div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
