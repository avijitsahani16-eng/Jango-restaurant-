"use client";

import { useSyncExternalStore } from "react";

import { site } from "@/config/site";
import { cn } from "@/lib/cn";
import { getOpenStatus } from "@/lib/hours";

/* The clock is an external store: it ticks every 30 s and only exists in the browser. */
const subscribe = (notify: () => void) => {
  const id = window.setInterval(notify, 30_000);
  return () => window.clearInterval(id);
};

const getSnapshot = () => {
  const status = getOpenStatus(new Date());
  return `${status.isOpen ? "1" : "0"}|${status.label}|${status.detail}|${status.today}`;
};

const getServerSnapshot = () => "";

export interface LiveStatus {
  isOpen: boolean;
  label: string;
  detail: string;
  today: number;
}

/** `null` until hydrated, then the live open/closed status in the restaurant's time zone. */
export function useOpenStatus(): LiveStatus | null {
  const snapshot = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  if (!snapshot) return null;
  const [open, label, detail, today] = snapshot.split("|");
  return { isOpen: open === "1", label, detail, today: Number(today) };
}

export function OpenStatus({ className, tone = "light" }: { className?: string; tone?: "light" | "dark" }) {
  const status = useOpenStatus();

  if (!status) {
    return <span className={cn("inline-flex items-center gap-2", className)}>{site.hoursSummary}</span>;
  }

  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <span aria-hidden="true" className="relative inline-flex size-2.5">
        {status.isOpen && <span className="absolute inset-0 animate-pulse-ring rounded-full bg-success" />}
        <span className={cn("relative size-2.5 rounded-full", status.isOpen ? "bg-success" : "bg-ink-subtle")} />
      </span>
      <span>
        <span className={cn("font-semibold", tone === "light" ? (status.isOpen ? "text-success-ink" : "text-ink") : "text-white")}>
          {status.label}
        </span>
        {status.detail && <span className={tone === "light" ? "text-ink-muted" : "text-white/70"}> · {status.detail}</span>}
      </span>
    </span>
  );
}
