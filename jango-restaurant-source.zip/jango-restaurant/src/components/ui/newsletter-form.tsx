"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { ArrowRight, LoaderCircle, Mail } from "lucide-react";
import { useId, useRef, useState, type FormEvent } from "react";

import { Honeypot, SuccessCheck } from "@/components/ui/form-bits";
import { Magnetic } from "@/components/ui/magnetic";
import { useFormSubmit } from "@/hooks/use-form-submit";
import { cn } from "@/lib/cn";
import { validateNewsletter } from "@/lib/validation";
import type { NewsletterInput } from "@/types";

/**
 * Email capture used in the newsletter section (`feature`) and the footer (`compact`).
 * Validates locally, posts to /api/newsletter and swaps to an animated confirmation.
 */
export function NewsletterForm({ variant = "feature", className }: { variant?: "feature" | "compact"; className?: string }) {
  const id = useId();
  const [email, setEmail] = useState("");
  const [trap, setTrap] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const { status, message, errors, submit, clearError } = useFormSubmit<NewsletterInput>("/api/newsletter");
  const feature = variant === "feature";
  const error = errors.email ?? (status === "error" && !errors.email ? message : "");
  const pending = status === "submitting";

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    const result = await submit(validateNewsletter({ email }), { company: trap });
    if (result.status === "error") inputRef.current?.focus();
  };

  return (
    <div className={cn("relative", className)}>
      <AnimatePresence mode="wait" initial={false}>
        {status === "success" ? (
          <m.div
            key="done"
            role="status"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className={cn("flex items-center gap-4", feature ? "min-h-[4.5rem]" : "min-h-12")}
          >
            <SuccessCheck tone={feature ? "brand" : "success"} className={feature ? "size-14" : "size-11 [&_svg]:size-6"} />
            <p className={cn("font-medium", feature ? "text-lg text-ink" : "text-[0.9375rem] text-white")}>
              You’re on the list.
              <span className={cn("block text-[0.9375rem] font-normal", feature ? "text-ink/80" : "text-white/70")}>
                Look out for this week’s offers at {email.trim()}.
              </span>
            </p>
          </m.div>
        ) : (
          <m.form key="form" onSubmit={onSubmit} noValidate initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, y: -10 }}>
            <Honeypot value={trap} onChange={setTrap} />
            <label htmlFor={id} className="sr-only">
              Email address
            </label>
            <div
              className={cn(
                "flex items-center gap-2 rounded-full p-1.5 transition-shadow duration-300 focus-within:ring-4",
                feature
                  ? "bg-white shadow-card focus-within:ring-ink/20"
                  : "bg-white/[0.08] ring-1 ring-inset ring-white/20 focus-within:ring-brand-500/40",
                error && (feature ? "ring-2 ring-danger-ink" : "ring-2 ring-inset ring-danger"),
              )}
            >
              <Mail aria-hidden="true" className={cn("ml-3.5 size-5 shrink-0", feature ? "text-ink-subtle" : "text-white/60")} />
              <input
                ref={inputRef}
                id={id}
                name="email"
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder="you@example.com"
                value={email}
                onChange={(event) => {
                  setEmail(event.target.value);
                  clearError("email");
                }}
                aria-invalid={error ? true : undefined}
                aria-describedby={error ? `${id}-error` : undefined}
                className={cn(
                  "h-11 min-w-0 flex-1 bg-transparent text-base focus:outline-none",
                  feature ? "text-ink placeholder:text-ink-subtle" : "text-white placeholder:text-white/55",
                )}
              />
              {feature ? (
                <Magnetic strength={0.2}>
                  <button
                    type="submit"
                    data-ripple=""
                    aria-disabled={pending || undefined}
                    className="inline-flex h-12 shrink-0 items-center gap-2 rounded-full bg-ink px-5 text-[0.9375rem] font-medium text-white transition-colors duration-300 hover:bg-ink-soft sm:px-7"
                  >
                    {pending ? <LoaderCircle aria-hidden="true" className="size-5 animate-spin" /> : null}
                    <span className={pending ? "sr-only sm:not-sr-only" : undefined}>{pending ? "Subscribing…" : "Subscribe"}</span>
                    {!pending && <ArrowRight aria-hidden="true" className="hidden size-4 text-brand-400 sm:block" />}
                  </button>
                </Magnetic>
              ) : (
                <button
                  type="submit"
                  data-ripple=""
                  aria-disabled={pending || undefined}
                  aria-label={pending ? "Subscribing" : "Subscribe to the newsletter"}
                  className="grid size-11 shrink-0 place-items-center rounded-full bg-brand-500 text-ink transition-colors duration-300 hover:bg-brand-400"
                >
                  {pending ? <LoaderCircle aria-hidden="true" className="size-5 animate-spin" /> : <ArrowRight aria-hidden="true" className="size-5" />}
                </button>
              )}
            </div>
            <p
              id={`${id}-error`}
              role={error ? "alert" : undefined}
              className={cn(
                "mt-2.5 min-h-5 pl-5 text-sm",
                error
                  ? feature
                    ? "font-semibold text-ink"
                    : "font-medium text-red-300"
                  : feature
                    ? "text-ink/80"
                    : "text-white/60",
              )}
            >
              {error || "One email a week. Unsubscribe any time."}
            </p>
          </m.form>
        )}
      </AnimatePresence>
    </div>
  );
}
