import { Flame, Star } from "lucide-react";
import type { ComponentProps, ReactNode } from "react";

import { cn } from "@/lib/cn";
import { formatINR, formatRating } from "@/lib/format";
import type { Diet, DishTag, SpiceLevel } from "@/types";

/* ── Section heading ─────────────────────────────────────────────────────── */
export function Eyebrow({ children, className, tone = "light" }: { children: ReactNode; className?: string; tone?: "light" | "dark" }) {
  return (
    <p
      className={cn(
        "eyebrow inline-flex items-center gap-2.5",
        tone === "light" ? "text-brand-700" : "text-brand-400",
        className,
      )}
    >
      <span aria-hidden="true" className={cn("h-px w-7", tone === "light" ? "bg-brand-600" : "bg-brand-400")} />
      {children}
    </p>
  );
}

interface SectionHeadingProps {
  id?: string;
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  align?: "left" | "center";
  tone?: "light" | "dark";
  className?: string;
}

export function SectionHeading({ id, eyebrow, title, description, align = "left", tone = "light", className }: SectionHeadingProps) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center", className)}>
      <div data-reveal="up">
        <Eyebrow tone={tone} className={align === "center" ? "justify-center" : undefined}>
          {eyebrow}
        </Eyebrow>
      </div>
      <h2 id={id} data-reveal="up" className={cn("text-section mt-4", tone === "dark" && "text-white")}>
        {title}
      </h2>
      {description && (
        <p data-reveal="up" className={cn("text-lead mt-5", tone === "light" ? "text-ink-muted" : "text-white/75")}>
          {description}
        </p>
      )}
    </div>
  );
}

/* ── Ratings ─────────────────────────────────────────────────────────────── */
/** Compact "★ 4.8 (412)" used on cards. */
export function Rating({ value, count, className }: { value: number; count?: number; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 text-sm font-semibold text-ink", className)}>
      <Star aria-hidden="true" className="size-4 fill-brand-500 text-brand-500" />
      <span aria-hidden="true">{formatRating(value)}</span>
      {count !== undefined && (
        <span aria-hidden="true" className="font-normal text-ink-subtle">
          ({count})
        </span>
      )}
      <span className="sr-only">
        Rated {formatRating(value)} out of 5{count !== undefined ? ` by ${count} customers` : ""}
      </span>
    </span>
  );
}

/** Row of five stars. */
export function Stars({ value, className, size = "size-4" }: { value: number; className?: string; size?: string }) {
  const rounded = Math.round(value);
  return (
    <span role="img" aria-label={`Rated ${value} out of 5`} className={cn("inline-flex items-center gap-0.5", className)}>
      {[1, 2, 3, 4, 5].map((index) => (
        <Star
          key={index}
          aria-hidden="true"
          className={cn(size, index <= rounded ? "fill-brand-500 text-brand-500" : "fill-ink/10 text-ink/10")}
        />
      ))}
    </span>
  );
}

/* ── Food markers ────────────────────────────────────────────────────────── */
/** India's familiar veg / non-veg mark. */
export function DietMark({ diet, className }: { diet: Diet; className?: string }) {
  const veg = diet === "veg";
  return (
    <span
      role="img"
      aria-label={veg ? "Vegetarian" : "Non-vegetarian"}
      title={veg ? "Vegetarian" : "Non-vegetarian"}
      className={cn(
        "inline-grid size-[1.125rem] shrink-0 place-items-center rounded-[5px] border-[1.5px] bg-white",
        veg ? "border-veg" : "border-nonveg",
        className,
      )}
    >
      {veg ? (
        <span className="size-2 rounded-full bg-veg" />
      ) : (
        <span className="size-0 border-x-[4.5px] border-b-[8px] border-x-transparent border-b-nonveg" />
      )}
    </span>
  );
}

const SPICE_LABEL: Record<SpiceLevel, string> = { 0: "Not spicy", 1: "Mild", 2: "Medium", 3: "Hot" };

export function SpiceMeter({ level, className }: { level: SpiceLevel; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-sm text-ink-muted", className)}>
      <span aria-hidden="true" className="inline-flex">
        {[1, 2, 3].map((index) => (
          <Flame key={index} className={cn("size-4", index <= level ? "fill-brand-500 text-brand-600" : "text-ink/20")} />
        ))}
      </span>
      {SPICE_LABEL[level]}
    </span>
  );
}

const TAG_LABEL: Record<DishTag, string> = {
  bestseller: "Bestseller",
  "chef-special": "Chef’s special",
  new: "New",
  spicy: "Spicy",
};

const TAG_STYLE: Record<DishTag, string> = {
  bestseller: "bg-ink text-white",
  "chef-special": "bg-brand-500 text-ink",
  new: "bg-success-ink text-white",
  spicy: "bg-danger-ink text-white",
};

export function DishTagBadge({ tag, className }: { tag: DishTag; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex h-7 items-center rounded-full px-3 font-display text-[0.6875rem] font-bold uppercase tracking-[0.08em] shadow-soft",
        TAG_STYLE[tag],
        className,
      )}
    >
      {TAG_LABEL[tag]}
    </span>
  );
}

/* ── Price ───────────────────────────────────────────────────────────────── */
export function Price({ amount, compareAt, className, size = "md" }: { amount: number; compareAt?: number; className?: string; size?: "sm" | "md" | "lg" }) {
  return (
    <span className={cn("inline-flex items-baseline gap-2", className)}>
      <span
        className={cn(
          "font-display font-extrabold tracking-[-0.02em] text-ink",
          size === "sm" && "text-base",
          size === "md" && "text-[1.375rem]",
          size === "lg" && "text-3xl",
        )}
      >
        <span className="sr-only">Price: </span>
        {formatINR(amount)}
      </span>
      {compareAt !== undefined && compareAt > amount && (
        <span className="text-sm text-ink-subtle">
          <span className="sr-only">Was </span>
          <s>{formatINR(compareAt)}</s>
        </span>
      )}
    </span>
  );
}

/* ── Form fields ─────────────────────────────────────────────────────────── */
export const inputStyles =
  "block h-12 w-full rounded-2xl border border-field bg-white px-4 text-base text-ink placeholder:text-ink-subtle transition-[border-color,box-shadow] duration-200 hover:border-ink-muted focus:border-ink focus:outline-none focus:ring-4 focus:ring-brand-500/25 aria-[invalid=true]:border-danger aria-[invalid=true]:focus:ring-danger/20 disabled:bg-ink/5";

export const textareaStyles = cn(inputStyles, "h-auto min-h-28 resize-y py-3 leading-relaxed");

interface FieldProps {
  id: string;
  label: string;
  error?: string;
  hint?: string;
  optional?: boolean;
  className?: string;
  children: ReactNode;
}

/** Label + control + inline error. Pair with `fieldProps()` on the control. */
export function Field({ id, label, error, hint, optional, className, children }: FieldProps) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 flex items-baseline justify-between gap-3 text-sm font-semibold text-ink">
        {label}
        {optional && <span className="text-xs font-normal text-ink-subtle">Optional</span>}
      </label>
      {children}
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-sm text-ink-subtle">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-sm font-medium text-danger-ink">
          {error}
        </p>
      )}
    </div>
  );
}

/** ARIA wiring for a control inside <Field>. */
export function fieldProps(id: string, error?: string, hint?: string): Pick<ComponentProps<"input">, "id" | "aria-invalid" | "aria-describedby"> {
  return {
    id,
    "aria-invalid": error ? true : undefined,
    "aria-describedby": error ? `${id}-error` : hint ? `${id}-hint` : undefined,
  };
}

/* ── Avatar ──────────────────────────────────────────────────────────────── */
const AVATAR_TONES = [
  "bg-brand-200 text-brand-900",
  "bg-emerald-100 text-emerald-900",
  "bg-sky-100 text-sky-900",
  "bg-rose-100 text-rose-900",
  "bg-amber-100 text-amber-900",
  "bg-violet-100 text-violet-900",
];

export function avatarTone(seed: string): string {
  let hash = 0;
  for (const char of seed) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return AVATAR_TONES[hash % AVATAR_TONES.length];
}
