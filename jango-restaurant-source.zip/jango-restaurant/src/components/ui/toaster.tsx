"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { Check, Info, TriangleAlert, X } from "lucide-react";
import Image from "next/image";
import { createPortal } from "react-dom";

import { useHydrated, useStore } from "@/hooks/use-store";
import { cn } from "@/lib/cn";
import { dismissToast, toastStore, type ToastTone } from "@/stores/toast";

const ICON: Record<ToastTone, typeof Check> = { success: Check, info: Info, error: TriangleAlert };
const ICON_STYLE: Record<ToastTone, string> = {
  success: "bg-success text-ink",
  info: "bg-brand-500 text-ink",
  error: "bg-danger text-white",
};

/** Bottom-centre notifications, announced politely to screen readers. */
export function Toaster() {
  const hydrated = useHydrated();
  const toasts = useStore(toastStore);
  if (!hydrated) return null;

  return createPortal(
    <div
      role="region"
      aria-label="Notifications"
      className="pointer-events-none fixed inset-x-0 bottom-[calc(5.5rem+env(safe-area-inset-bottom))] z-[90] flex flex-col items-center gap-2.5 px-4 lg:bottom-8"
    >
      <div aria-live="polite" aria-atomic="false" className="contents">
        <AnimatePresence initial={false}>
          {toasts.map((toast) => {
            const ToastIcon = ICON[toast.tone];
            return (
              <m.div
                key={toast.id}
                layout
                role="status"
                initial={{ opacity: 0, y: 28, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 12, scale: 0.96 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="on-dark pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-[1.25rem] bg-ink py-2.5 pl-2.5 pr-2 text-white shadow-lift"
              >
                {toast.image ? (
                  <span className="relative size-11 shrink-0 overflow-hidden rounded-xl">
                    <Image src={toast.image} alt="" fill sizes="48px" className="object-cover" />
                  </span>
                ) : (
                  <span className={cn("grid size-11 shrink-0 place-items-center rounded-xl", ICON_STYLE[toast.tone])}>
                    <ToastIcon aria-hidden="true" className="size-5" strokeWidth={2.5} />
                  </span>
                )}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{toast.title}</span>
                  {toast.description && <span className="block truncate text-sm text-white/75">{toast.description}</span>}
                </span>
                {toast.action && (
                  <button
                    type="button"
                    onClick={() => {
                      toast.action?.onClick();
                      dismissToast(toast.id);
                    }}
                    className="h-9 shrink-0 rounded-full bg-brand-500 px-3.5 text-sm font-medium text-ink transition-colors hover:bg-brand-400"
                  >
                    {toast.action.label}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => dismissToast(toast.id)}
                  aria-label="Dismiss notification"
                  className="grid size-9 shrink-0 place-items-center rounded-full text-white/75 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <X aria-hidden="true" className="size-4" />
                </button>
              </m.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>,
    document.body,
  );
}
