import type { SVGProps } from "react";

export type SocialIconName = "instagram" | "facebook" | "youtube" | "google";

/** Simple, hand-drawn glyphs for social links (lucide no longer ships brand icons). */
export function SocialIcon({ name, ...props }: { name: SocialIconName } & SVGProps<SVGSVGElement>) {
  const common = {
    viewBox: "0 0 24 24",
    width: 20,
    height: 20,
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
    focusable: false,
    ...props,
  };

  switch (name) {
    case "instagram":
      return (
        <svg {...common}>
          <rect x="3" y="3" width="18" height="18" rx="5.2" />
          <circle cx="12" cy="12" r="4.1" />
          <circle cx="17.3" cy="6.7" r="0.6" fill="currentColor" />
        </svg>
      );
    case "facebook":
      return (
        <svg {...common}>
          <path d="M14.5 21v-7.4h2.6l.5-3.2h-3.1V8.5c0-1 .4-1.7 1.8-1.7h1.4V4a17 17 0 0 0-2.3-.2c-2.4 0-4 1.5-4 4.2v2.4H8.8v3.2h2.6V21" />
        </svg>
      );
    case "youtube":
      return (
        <svg {...common}>
          <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
          <path d="m10.2 9.3 4.6 2.7-4.6 2.7V9.3Z" fill="currentColor" />
        </svg>
      );
    case "google":
      return (
        <svg {...common}>
          <path d="M12 21s-6.5-5.6-6.5-10.6a6.5 6.5 0 0 1 13 0C18.500 15.4 12 21 12 21Z" />
          <circle cx="12" cy="10.3" r="2.4" />
        </svg>
      );
  }
}
