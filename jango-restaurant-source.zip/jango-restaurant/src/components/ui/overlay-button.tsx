"use client";

import type { ComponentProps } from "react";

import { ui, type Overlay } from "@/stores/ui";

type OverlayButtonProps = Omit<ComponentProps<"button">, "onClick" | "type"> & {
  overlay: Exclude<Overlay, "quick-view">;
};

/** A button that opens one of the site-wide overlays. Lets Server Components trigger them. */
export function OverlayButton({ overlay, ...props }: OverlayButtonProps) {
  return <button type="button" aria-haspopup="dialog" onClick={() => ui.open(overlay)} {...props} />;
}
