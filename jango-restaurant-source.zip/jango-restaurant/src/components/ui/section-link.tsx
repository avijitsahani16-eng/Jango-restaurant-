"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ComponentProps, MouseEvent } from "react";

import { scrollToTarget } from "@/lib/scroll";

type SectionLinkProps = Omit<ComponentProps<typeof Link>, "href"> & {
  /** "/#offers" style link to a section of the home page, or any normal path. */
  href: string;
};

/**
 * A link that glides to a home-page section when you are already on the home
 * page, and navigates there (then jumps to the section) from anywhere else.
 */
export function SectionLink({ href, onClick, ...props }: SectionLinkProps) {
  const pathname = usePathname();

  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(event);
    if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;

    const hashIndex = href.indexOf("#");
    if (hashIndex === -1) return;
    const path = href.slice(0, hashIndex) || "/";
    const hash = href.slice(hashIndex);
    if (path !== pathname || !document.querySelector(hash)) return;

    event.preventDefault();
    scrollToTarget(hash);
    window.history.replaceState(null, "", hash);
  };

  return <Link href={href} onClick={handleClick} {...props} />;
}
