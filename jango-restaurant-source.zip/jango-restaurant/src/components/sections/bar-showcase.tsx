import { CalendarCheck, Phone, Wine } from "lucide-react";
import Image from "next/image";

import { buttonStyles } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Magnetic } from "@/components/ui/magnetic";
import { OverlayButton } from "@/components/ui/overlay-button";
import { Eyebrow } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { cocktails } from "@/data/content";
import { formatINR } from "@/lib/format";

const highlights = [
  "Signature cocktails with Bengal’s own gondhoraj lime",
  "Bar bites straight from the tandoor and the wok",
  "Tables for two, corners for ten — open till 11 PM",
];

/** The bar — dine-in only. A typographic cocktail list on a dark, warm surface. */
export function BarShowcase() {
  return (
    <section id="bar" aria-labelledby="bar-title" className="on-dark relative isolate overflow-hidden bg-ink text-white">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-px w-[min(90rem,100%)] -translate-x-1/2 bg-gradient-to-r from-transparent via-brand-500/60 to-transparent" />
        <div className="absolute -left-52 top-1/3 size-[36rem] rounded-full bg-brand-600/20 blur-[130px]" />
        <div className="absolute -right-40 -top-40 size-[30rem] rounded-full bg-brand-500/15 blur-[120px]" />
        <Wine strokeWidth={0.5} className="absolute -bottom-20 right-[4%] size-[26rem] -rotate-12 text-white/[0.035]" />
      </div>

      <div className="container-site section-y grid items-center gap-x-16 gap-y-14 lg:grid-cols-[1fr_1.05fr] xl:gap-x-24">
        <div>
          <div data-reveal="up">
            <Eyebrow tone="dark">The bar · Dine-in only</Eyebrow>
          </div>
          <h2 id="bar-title" data-reveal="up" className="text-section mt-4 text-white">
            Come for dinner. <span className="text-brand-400">Stay for the pour.</span>
          </h2>
          <p data-reveal="up" className="text-lead mt-5 max-w-xl text-white/75">
            When the food is this good, nobody wants to rush home. Pull up a stool, order something cold and let the evening stretch —
            our bar pours classics and a few house originals until last call.
          </p>

          <ul className="mt-8 space-y-3.5">
            {highlights.map((text) => (
              <li key={text} data-reveal="up" className="flex items-start gap-3.5 text-[1.0625rem] text-white/90">
                <span aria-hidden="true" className="mt-2 size-2 shrink-0 rounded-full bg-brand-500 shadow-[0_0_0_4px_rgb(249_115_22/0.2)]" />
                {text}
              </li>
            ))}
          </ul>

          <div data-reveal="up" className="mt-10 flex flex-wrap items-center gap-3.5">
            <Magnetic>
              <OverlayButton overlay="reservation" data-ripple="" className={buttonStyles({ variant: "primary", size: "lg" })}>
                <CalendarCheck aria-hidden="true" className="size-5" />
                Reserve a table
              </OverlayButton>
            </Magnetic>
            <a href={site.phone.href} data-ripple="" className={buttonStyles({ variant: "glass", size: "lg" })}>
              <Phone aria-hidden="true" className="size-5" />
              {site.phone.display}
            </a>
          </div>
          <p data-reveal="up" className="mt-6 text-sm text-white/65">
            Alcohol is served in-house only, to guests aged {site.legalDrinkingAge} and above. Please drink responsibly.
          </p>
        </div>

        {/* Cocktail menu card */}
        <div data-reveal="left" className="relative">
          <div aria-hidden="true" className="absolute -inset-px rounded-[2rem] bg-gradient-to-br from-brand-500/60 via-white/10 to-transparent" />
          <div className="relative rounded-[2rem] bg-[#161d2e] p-6 sm:p-9">
            <div className="flex items-end justify-between gap-4 border-b border-white/10 pb-5">
              <div>
                <p className="eyebrow text-brand-400">House signatures</p>
                <h3 className="mt-2 font-display text-2xl font-extrabold tracking-[-0.02em] text-white">The cocktail list</h3>
              </div>
              <span className="rounded-full bg-white/[0.08] px-3.5 py-1.5 text-xs font-semibold text-white/85 ring-1 ring-inset ring-white/15">
                {site.legalDrinkingAge}+ only
              </span>
            </div>

            <ul>
              {cocktails.map((cocktail) => (
                <li key={cocktail.id} className="group flex items-center gap-4 border-b border-white/10 py-5 last:border-b-0 last:pb-0 sm:gap-5">
                  {cocktail.image ? (
                    <span className="relative size-16 shrink-0 overflow-hidden rounded-2xl">
                      <Image src={cocktail.image} alt={cocktail.imageAlt ?? ""} fill sizes="64px" className="object-cover transition-transform duration-700 group-hover:scale-110" />
                    </span>
                  ) : (
                    <span className="grid size-14 shrink-0 place-items-center rounded-2xl bg-white/[0.06] text-brand-400 ring-1 ring-inset ring-white/10 transition-[background-color,color,rotate] duration-500 ease-out-expo group-hover:-rotate-6 group-hover:bg-brand-500 group-hover:text-ink sm:size-16">
                      <Icon name={cocktail.icon} className="size-7" strokeWidth={1.5} />
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-3">
                      <h4 className="font-display text-lg font-bold tracking-[-0.01em] text-white">{cocktail.name}</h4>
                      <span aria-hidden="true" className="mb-1 hidden min-w-6 flex-1 border-b border-dotted border-white/25 sm:block" />
                      <p className="ml-auto shrink-0 font-display text-lg font-bold tabular-nums text-brand-400 sm:ml-0">
                        <span className="sr-only">Price: </span>
                        {formatINR(cocktail.price)}
                      </p>
                    </div>
                    <p className="mt-1 text-[0.9375rem] leading-relaxed text-white/70">{cocktail.notes}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
