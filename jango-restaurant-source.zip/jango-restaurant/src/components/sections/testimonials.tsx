"use client";

import { ArrowLeft, ArrowRight, Pause, Play, Quote, Star } from "lucide-react";
import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";

import { Eyebrow, Stars, avatarTone } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { testimonials } from "@/data/content";
import { cn } from "@/lib/cn";
import { formatRating, initials } from "@/lib/format";
import { prefersReducedMotion } from "@/lib/scroll";

const AUTOPLAY_MS = 6000;

/**
 * Testimonial carousel.
 * Native scroll-snap does the swiping (touch, trackpad, keyboard); JavaScript
 * adds auto-advance, buttons and dots. Auto-advance pauses on hover, on
 * keyboard focus, when the tab is hidden, and for reduced-motion visitors.
 */
export function Testimonials() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(0);
  const [pages, setPages] = useState(testimonials.length);
  const [userPaused, setUserPaused] = useState(false);
  const [interacting, setInteracting] = useState(false);
  const [onScreen, setOnScreen] = useState(false);
  const playing = !userPaused && !interacting && onScreen;

  const slideWidth = () => trackRef.current?.firstElementChild?.getBoundingClientRect().width ?? 1;

  const goTo = useCallback((target: number, behavior: ScrollBehavior = "smooth") => {
    const track = trackRef.current;
    if (!track) return;
    const max = Math.max(0, Math.round((track.scrollWidth - track.clientWidth) / slideWidth()));
    const next = target > max ? 0 : target < 0 ? max : target;
    track.scrollTo({ left: next * slideWidth(), behavior: prefersReducedMotion() ? "auto" : behavior });
  }, []);

  /* Keep the index and the number of pages in sync with the scroll position and the layout. */
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    let frame = 0;
    const measure = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const width = slideWidth();
        setIndex(Math.round(track.scrollLeft / width));
        setPages(Math.max(1, Math.round((track.scrollWidth - track.clientWidth) / width) + 1));
      });
    };
    measure();
    track.addEventListener("scroll", measure, { passive: true });
    const observer = new ResizeObserver(measure);
    observer.observe(track);
    return () => {
      cancelAnimationFrame(frame);
      track.removeEventListener("scroll", measure);
      observer.disconnect();
    };
  }, []);

  /* Only auto-advance while the carousel can actually be seen. */
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const observer = new IntersectionObserver(([entry]) => setOnScreen(entry.isIntersecting), { threshold: 0.35 });
    observer.observe(track);
    return () => observer.disconnect();
  }, []);

  /* Auto-advance */
  useEffect(() => {
    if (!playing || prefersReducedMotion()) return;
    const id = window.setInterval(() => {
      if (document.visibilityState === "visible") goTo(index + 1);
    }, AUTOPLAY_MS);
    return () => window.clearInterval(id);
  }, [playing, index, goTo]);

  const controlButton =
    "grid size-12 place-items-center rounded-full bg-white text-ink shadow-soft ring-1 ring-ink/10 transition-[background-color,translate,box-shadow] duration-300 hover:-translate-y-0.5 hover:bg-ink hover:text-white hover:shadow-card";

  return (
    <section id="reviews" aria-labelledby="reviews-title" className="section-y overflow-hidden">
      <div className="container-site">
        <div className="grid gap-x-12 gap-y-10 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.6fr)] xl:gap-x-20">
          {/* Intro */}
          <div>
            <div data-reveal="up">
              <Eyebrow>Customer stories</Eyebrow>
            </div>
            <h2 id="reviews-title" data-reveal="up" className="text-section mt-4">
              Loved across Nadia, one plate at a time.
            </h2>
            <p data-reveal="up" className="text-lead mt-5 text-ink-muted">
              The nicest thing about cooking for a living is hearing that it made someone’s evening.
            </p>

            <a
              data-reveal="up"
              href={site.maps.reviewsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-8 flex items-center gap-4 rounded-card bg-white p-4 shadow-card ring-1 ring-ink/[0.04] transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1 hover:shadow-lift"
            >
              <span className="grid size-16 shrink-0 place-items-center rounded-2xl bg-ink font-display text-2xl font-extrabold tracking-[-0.03em] text-white">
                {formatRating(site.googleRating.value)}
              </span>
              <span className="min-w-0">
                <span className="flex gap-0.5">
                  {[0, 1, 2, 3, 4].map((star) => (
                    <Star key={star} aria-hidden="true" className="size-[1.125rem] fill-brand-500 text-brand-500" />
                  ))}
                </span>
                <span className="mt-1 block text-[0.9375rem] text-ink-muted">
                  Based on <strong className="font-semibold text-ink">{site.googleRating.label} Google reviews</strong>
                </span>
                <span className="link-underline mt-0.5 inline-flex items-center gap-1 text-sm font-medium text-brand-700">
                  Read them on Google
                  <ArrowRight aria-hidden="true" className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5" />
                  <span className="sr-only">(opens in a new tab)</span>
                </span>
              </span>
            </a>

            {/* Controls */}
            <div data-reveal="up" className="mt-8 flex items-center gap-3">
              <button type="button" onClick={() => goTo(index - 1)} aria-label="Previous review" className={controlButton}>
                <ArrowLeft aria-hidden="true" className="size-5" />
              </button>
              <button type="button" onClick={() => goTo(index + 1)} aria-label="Next review" className={controlButton}>
                <ArrowRight aria-hidden="true" className="size-5" />
              </button>
              <button
                type="button"
                onClick={() => setUserPaused((value) => !value)}
                aria-label={userPaused ? "Resume automatic sliding" : "Pause automatic sliding"}
                aria-pressed={userPaused}
                className={cn(controlButton, "ml-1 size-10 shadow-none")}
              >
                {userPaused ? <Play aria-hidden="true" className="size-4" /> : <Pause aria-hidden="true" className="size-4" />}
              </button>
              <p className="ml-auto font-display text-sm font-bold tabular-nums text-ink-muted lg:ml-3" aria-hidden="true">
                <span className="text-ink">{String(Math.min(index + 1, pages)).padStart(2, "0")}</span> / {String(pages).padStart(2, "0")}
              </p>
            </div>
          </div>

          {/* Carousel */}
          <div
            role="group"
            aria-roledescription="carousel"
            aria-label="Customer reviews"
            data-reveal="left"
            className="min-w-0"
            onPointerEnter={(event) => event.pointerType === "mouse" && setInteracting(true)}
            onPointerLeave={() => setInteracting(false)}
            onFocus={() => setInteracting(true)}
            onBlur={(event) => !event.currentTarget.contains(event.relatedTarget as Node | null) && setInteracting(false)}
          >
            <div
              ref={trackRef}
              tabIndex={0}
              role="region"
              aria-label="Reviews — scroll or swipe sideways"
              aria-live={userPaused || interacting ? "polite" : "off"}
              className="no-scrollbar -mx-5 flex snap-x snap-mandatory scroll-px-5 overflow-x-auto scroll-smooth px-5 pb-10 pt-3 sm:-mx-3 sm:scroll-px-0 sm:px-0 lg:-mr-12 lg:pr-12"
            >
              {testimonials.map((review, position) => {
                const active = position === index;
                return (
                  <div
                    key={review.id}
                    role="group"
                    aria-roledescription="slide"
                    aria-label={`${position + 1} of ${testimonials.length}`}
                    className="w-full shrink-0 snap-start px-0 pr-4 last:pr-0 sm:w-1/2 sm:px-3 sm:last:pr-3 xl:w-[44%]"
                  >
                    <figure
                      className={cn(
                        "relative flex h-full flex-col rounded-[2rem] p-7 transition-[background-color,color,box-shadow,scale] duration-700 ease-out-expo sm:p-8",
                        active ? "on-dark bg-ink text-white shadow-lift" : "bg-white text-ink shadow-card ring-1 ring-ink/[0.04] sm:scale-[0.97]",
                      )}
                    >
                      <Quote
                        aria-hidden="true"
                        className={cn("size-10 transition-colors duration-700", active ? "fill-brand-500 text-brand-500" : "fill-brand-200 text-brand-200")}
                      />
                      <Stars value={review.rating} className="mt-5" size="size-[1.125rem]" />
                      <blockquote className={cn("mt-4 flex-1 text-[1.0625rem] leading-[1.75] transition-colors duration-700", active ? "text-white/90" : "text-ink-soft")}>
                        “{review.quote}”
                      </blockquote>
                      <p
                        className={cn(
                          "mt-6 inline-flex h-8 items-center self-start rounded-full px-3.5 text-xs font-semibold transition-colors duration-700",
                          active ? "bg-white/10 text-white" : "bg-cream text-brand-800",
                        )}
                      >
                        Ordered: {review.ordered}
                      </p>
                      <figcaption className={cn("mt-6 flex items-center gap-3.5 border-t pt-6 transition-colors duration-700", active ? "border-white/15" : "border-line")}>
                        {review.avatar ? (
                          <span className="relative size-12 shrink-0 overflow-hidden rounded-full ring-2 ring-brand-500 ring-offset-2 ring-offset-transparent">
                            <Image src={review.avatar} alt="" fill sizes="48px" className="object-cover" />
                          </span>
                        ) : (
                          <span aria-hidden="true" className={cn("grid size-12 shrink-0 place-items-center rounded-full font-display text-sm font-extrabold", avatarTone(review.name))}>
                            {initials(review.name)}
                          </span>
                        )}
                        <span className="leading-tight">
                          <span className="block font-display font-bold">{review.name}</span>
                          <span className={cn("block text-sm transition-colors duration-700", active ? "text-white/70" : "text-ink-muted")}>{review.context}</span>
                        </span>
                      </figcaption>
                    </figure>
                  </div>
                );
              })}
            </div>

            {/* Dots */}
            <div className="-mt-3 flex justify-center gap-0.5 sm:justify-start sm:pl-3">
              {Array.from({ length: pages }, (_, page) => (
                <button
                  key={page}
                  type="button"
                  onClick={() => goTo(page)}
                  aria-label={`Go to review ${page + 1}`}
                  aria-current={page === index ? "true" : undefined}
                  className="group grid h-8 w-8 place-items-center"
                >
                  <span
                    className={cn(
                      "h-2 rounded-full transition-[width,background-color] duration-500 ease-out-expo",
                      page === index ? "w-7 bg-brand-500" : "w-2 bg-ink/25 group-hover:bg-ink/50",
                    )}
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
