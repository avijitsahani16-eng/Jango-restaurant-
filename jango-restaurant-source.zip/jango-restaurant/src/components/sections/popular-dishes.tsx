import { ArrowRight } from "lucide-react";
import Link from "next/link";

import { DishCard } from "@/components/menu/dish-card";
import { buttonStyles } from "@/components/ui/button";
import { SectionHeading } from "@/components/ui/primitives";
import { popularDishes, totalDishes } from "@/data/dishes";
import { cn } from "@/lib/cn";

export function PopularDishes() {
  // Four across when the set divides evenly, otherwise a roomier three.
  const fourUp = popularDishes.length % 4 === 0;

  return (
    <section id="popular" aria-labelledby="popular-title" className="section-y relative bg-cream/60">
      <div className="container-site">
        <div className="flex flex-wrap items-end justify-between gap-x-10 gap-y-6">
          <SectionHeading
            id="popular-title"
            eyebrow="Popular dishes"
            title="The ones everybody orders twice."
            description="Our most-loved plates this month — rated by the people who eat them. Tap any dish for a closer look."
          />
          <Link href="/menu" data-reveal="up" data-ripple="" className={cn(buttonStyles({ variant: "dark" }), "group")}>
            See all {totalDishes} dishes
            <ArrowRight aria-hidden="true" className="size-4 text-brand-400 transition-transform duration-300 group-hover:translate-x-0.5" />
          </Link>
        </div>

        {/* Phones: a swipeable rail. Tablets and up: a grid. */}
        <ul
          aria-label="Popular dishes"
          className={cn(
            "no-scrollbar -mx-5 mt-10 flex snap-x snap-mandatory scroll-px-5 gap-4 overflow-x-auto px-5 pb-6 pt-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:gap-6 sm:overflow-visible sm:px-0 sm:pb-0 lg:mt-14 lg:grid-cols-3 lg:gap-7",
            fourUp && "xl:grid-cols-4",
          )}
        >
          {popularDishes.map((dish) => (
            <li key={dish.id} data-reveal="up" className="w-[82vw] max-w-[22rem] shrink-0 snap-start sm:w-auto sm:max-w-none">
              <DishCard dish={dish} />
            </li>
          ))}
        </ul>
        <p className="mt-1 text-center text-sm text-ink-subtle sm:hidden" aria-hidden="true">
          Swipe for more →
        </p>
      </div>
    </section>
  );
}
