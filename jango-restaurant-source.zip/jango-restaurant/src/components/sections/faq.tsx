"use client";

import * as m from "framer-motion/m";
import { MessageCircleQuestion, Phone, Plus } from "lucide-react";
import { useState } from "react";

import { buttonStyles } from "@/components/ui/button";
import { SectionLink } from "@/components/ui/section-link";
import { Eyebrow } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { faqs } from "@/data/content";
import { cn } from "@/lib/cn";

/** FAQ accordion. Answers stay in the HTML (good for search engines) and animate open. */
export function Faq() {
  const [openId, setOpenId] = useState<string | null>(faqs[0]?.id ?? null);

  return (
    <section id="faq" aria-labelledby="faq-title" className="section-y">
      <div className="container-site grid gap-x-16 gap-y-12 lg:grid-cols-[0.85fr_1.15fr] xl:gap-x-24">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <div data-reveal="up">
            <Eyebrow>Good to know</Eyebrow>
          </div>
          <h2 id="faq-title" data-reveal="up" className="text-section mt-4">
            Questions, answered before you ask.
          </h2>
          <p data-reveal="up" className="text-lead mt-5 max-w-md text-ink-muted">
            Delivery, payments, table bookings and the bar — everything people usually want to know before their first order.
          </p>

          <div data-reveal="up" className="mt-9 rounded-card bg-cream p-6 ring-1 ring-brand-200/60 sm:p-7">
            <span className="grid size-12 place-items-center rounded-2xl bg-brand-500 text-ink">
              <MessageCircleQuestion aria-hidden="true" className="size-6" />
            </span>
            <h3 className="mt-4 font-display text-xl font-bold tracking-[-0.01em] text-ink">Still hungry for answers?</h3>
            <p className="mt-1.5 text-[0.9375rem] text-ink-muted">Talk to a real person — we pick up from 11 AM to 11 PM, every day.</p>
            <div className="mt-5 flex flex-wrap gap-3">
              <a href={site.phone.href} data-ripple="" className={buttonStyles({ variant: "dark", size: "sm" })}>
                <Phone aria-hidden="true" className="size-4 text-brand-400" />
                {site.phone.display}
              </a>
              <SectionLink href="/#contact" data-ripple="" className={buttonStyles({ variant: "outline", size: "sm" })}>
                Send a message
              </SectionLink>
            </div>
          </div>
        </div>

        <div data-reveal="up" className="rounded-[2rem] bg-white p-2 shadow-card ring-1 ring-ink/[0.04] sm:p-3">
          {faqs.map((faq, index) => {
            const open = openId === faq.id;
            return (
              <div
                key={faq.id}
                className={cn(
                  "rounded-[1.5rem] transition-colors duration-500",
                  open ? "bg-cream" : "bg-transparent",
                  index > 0 && !open && "border-t border-line/70",
                )}
              >
                <h3>
                  <button
                    type="button"
                    id={`faq-button-${faq.id}`}
                    aria-expanded={open}
                    aria-controls={`faq-panel-${faq.id}`}
                    onClick={() => setOpenId(open ? null : faq.id)}
                    className="group flex w-full items-center justify-between gap-5 rounded-[1.5rem] px-5 py-5 text-left sm:px-7 sm:py-6"
                  >
                    <span className="font-display text-[1.0625rem] font-bold leading-snug tracking-[-0.01em] text-ink sm:text-lg">
                      {faq.question}
                    </span>
                    <span
                      aria-hidden="true"
                      className={cn(
                        "grid size-10 shrink-0 place-items-center rounded-full transition-[background-color,color,rotate] duration-500 ease-out-expo",
                        open ? "rotate-[135deg] bg-ink text-white" : "bg-cream text-ink group-hover:bg-brand-500",
                      )}
                    >
                      <Plus className="size-5" />
                    </span>
                  </button>
                </h3>
                <m.div
                  id={`faq-panel-${faq.id}`}
                  role="region"
                  aria-labelledby={`faq-button-${faq.id}`}
                  inert={!open}
                  initial={false}
                  animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }}
                  transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-6 pr-12 text-[1.0625rem] leading-relaxed text-ink-muted sm:px-7 sm:pr-20">{faq.answer}</p>
                </m.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
