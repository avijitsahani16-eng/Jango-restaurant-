"use client";

import { Expand } from "lucide-react";
import dynamic from "next/dynamic";
import Image from "next/image";
import { useState } from "react";

import { SectionHeading } from "@/components/ui/primitives";
import { gallery } from "@/data/content";

const Lightbox = dynamic(() => import("./gallery-lightbox").then((module) => module.GalleryLightbox), { ssr: false });

/** Pinterest-style masonry of food photography with a keyboard-friendly lightbox. */
export function Gallery() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [everOpened, setEverOpened] = useState(false);

  const open = (index: number) => {
    setEverOpened(true);
    setOpenIndex(index);
  };

  return (
    <section id="gallery" aria-labelledby="gallery-title" className="section-y bg-cream/60">
      <div className="container-site">
        <SectionHeading
          id="gallery-title"
          align="center"
          eyebrow="Gallery"
          title="A feast for the eyes first."
          description="Colour, smoke and a little theatre — a taste of what comes out of the Jango kitchen. Tap any photo for a closer look."
        />

        <ul className="mt-12 columns-2 gap-3 sm:gap-5 lg:mt-16 lg:columns-4">
          {gallery.map((photo, index) => (
            <li key={photo.id} data-reveal="up" className="mb-3 break-inside-avoid sm:mb-5">
              <button
                type="button"
                onClick={() => open(index)}
                aria-haspopup="dialog"
                aria-label={`View photo: ${photo.caption}`}
                className="group relative block w-full overflow-hidden rounded-card bg-cream shadow-card transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1 hover:shadow-lift"
              >
                <Image
                  src={photo.src}
                  alt={photo.alt}
                  sizes="(min-width: 1024px) 23vw, 46vw"
                  placeholder="blur"
                  className="h-auto w-full transition-transform duration-[1000ms] ease-out-expo group-hover:scale-110"
                />
                <span
                  aria-hidden="true"
                  className="absolute inset-0 flex flex-col justify-between bg-gradient-to-t from-ink/80 via-ink/10 to-transparent p-4 opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-visible:opacity-100"
                >
                  <span className="glass ml-auto grid size-10 -translate-y-2 place-items-center rounded-full text-ink transition-transform duration-500 ease-out-expo group-hover:translate-y-0">
                    <Expand className="size-4" />
                  </span>
                  <span className="translate-y-2 text-left font-display text-[0.9375rem] font-bold leading-snug text-white transition-transform duration-500 ease-out-expo group-hover:translate-y-0">
                    {photo.caption}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      {everOpened && <Lightbox photos={gallery} index={openIndex} onChange={setOpenIndex} />}
    </section>
  );
}
