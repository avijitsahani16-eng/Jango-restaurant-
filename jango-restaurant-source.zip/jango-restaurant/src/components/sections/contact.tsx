import { CalendarCheck, Clock, MapPin, Phone } from "lucide-react";

import { buttonStyles } from "@/components/ui/button";
import { OpenStatus } from "@/components/ui/open-status";
import { OverlayButton } from "@/components/ui/overlay-button";
import { SectionHeading } from "@/components/ui/primitives";
import { SocialIcon } from "@/components/ui/social-icon";
import { site } from "@/config/site";

import { ContactForm, HoursList, LazyMap } from "./contact-parts";

const iconChip = "grid size-12 shrink-0 place-items-center rounded-2xl bg-cream text-brand-600";

export function Contact() {
  return (
    <section id="contact" aria-labelledby="contact-title" className="section-y">
      <div className="container-site">
        <div className="flex flex-wrap items-end justify-between gap-x-10 gap-y-6">
          <SectionHeading
            id="contact-title"
            eyebrow="Find us"
            title="Right on NH12. Impossible to miss."
            description="On the highway between Krishnanagar and Bethuadahari. Call, message or simply drop in — the kitchen is open from 11 to 11, every day."
          />
          <OverlayButton overlay="reservation" data-reveal="up" data-ripple="" className={buttonStyles({ variant: "primary" })}>
            <CalendarCheck aria-hidden="true" className="size-5" />
            Reserve a table
          </OverlayButton>
        </div>

        <div className="mt-12 grid gap-6 lg:mt-16 lg:grid-cols-12 lg:gap-7">
          {/* Details */}
          <div data-reveal="up" className="rounded-card bg-white p-6 shadow-card ring-1 ring-ink/[0.04] sm:p-8 lg:col-span-5">
            <address className="not-italic">
              <ul className="space-y-6">
                <li className="flex gap-4">
                  <span className={iconChip}>
                    <MapPin aria-hidden="true" className="size-6" />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold text-ink">Address</h3>
                    <p className="mt-1 text-[0.9375rem] leading-relaxed text-ink-muted">
                      {site.legalName}
                      <br />
                      {site.address.street}
                      <br />
                      {site.address.locality}, {site.address.region} {site.address.postalCode}
                    </p>
                    <p className="mt-1 text-sm text-ink-muted">
                      Plus code: <span className="font-medium text-ink">{site.address.plusCode}</span>
                    </p>
                    <a
                      href={site.maps.listingUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="link-underline mt-2 inline-block text-sm font-medium text-brand-700"
                    >
                      View on Google Maps<span className="sr-only"> (opens in a new tab)</span>
                    </a>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className={iconChip}>
                    <Phone aria-hidden="true" className="size-6" />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold text-ink">Phone</h3>
                    <p className="mt-1 text-[0.9375rem] text-ink-muted">Orders, reservations and party bookings</p>
                    <a href={site.phone.href} className="link-underline mt-1 inline-block font-display text-xl font-extrabold tracking-[-0.02em] text-ink">
                      {site.phone.display}
                    </a>
                  </div>
                </li>
              </ul>
            </address>

            <div className="mt-6 flex gap-4 border-t border-line pt-6">
              <span className={iconChip}>
                <Clock aria-hidden="true" className="size-6" />
              </span>
              <div className="min-w-0 flex-1">
                <h3 className="font-display text-lg font-bold text-ink">Working hours</h3>
                <OpenStatus className="mt-1 text-[0.9375rem]" />
              </div>
            </div>
            <div className="mt-4">
              <HoursList />
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-line pt-6">
              <h3 className="text-sm font-semibold text-ink">Follow along</h3>
              <ul className="flex items-center gap-2">
                {site.social.map((profile) => (
                  <li key={profile.name}>
                    <a
                      href={profile.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`${site.name} on ${profile.name} (opens in a new tab)`}
                      className="grid size-11 place-items-center rounded-full bg-cream text-ink ring-1 ring-inset ring-brand-200/70 transition-[background-color,color,translate] duration-300 hover:-translate-y-0.5 hover:bg-ink hover:text-white"
                    >
                      <SocialIcon name={profile.icon} />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Form */}
          <div data-reveal="up" className="flex flex-col rounded-card bg-white p-6 shadow-card ring-1 ring-ink/[0.04] sm:p-9 lg:col-span-7">
            <h3 className="font-display text-2xl font-extrabold tracking-[-0.02em] text-ink">Send us a message</h3>
            <p className="mb-7 mt-1.5 text-ink-muted">Planning a party, need catering, or have feedback? We would love to hear from you.</p>
            <div className="flex-1">
              <ContactForm />
            </div>
          </div>

          {/* Map */}
          <div data-reveal="up" className="lg:col-span-12">
            <LazyMap className="h-[22rem] sm:h-[28rem]" />
          </div>
        </div>
      </div>
    </section>
  );
}
