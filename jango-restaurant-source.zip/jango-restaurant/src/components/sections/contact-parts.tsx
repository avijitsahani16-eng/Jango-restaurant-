"use client";

import { Navigation, Send } from "lucide-react";
import { useEffect, useRef, useState, type FormEvent } from "react";

import { Button } from "@/components/ui/button";
import { Honeypot, SubmitButton, SuccessCheck } from "@/components/ui/form-bits";
import { useOpenStatus } from "@/components/ui/open-status";
import { Field, fieldProps, inputStyles, textareaStyles } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { focusFirstError, useFormSubmit } from "@/hooks/use-form-submit";
import { cn } from "@/lib/cn";
import { formatClock } from "@/lib/format";
import { CONTACT_TOPICS, validateContact } from "@/lib/validation";
import type { ContactInput } from "@/types";

/* ── Contact form ────────────────────────────────────────────────────────── */
const EMPTY = { name: "", phone: "", email: "", topic: CONTACT_TOPICS[0] as string, message: "" };

export function ContactForm() {
  const [form, setForm] = useState(EMPTY);
  const [trap, setTrap] = useState("");
  const formRef = useRef<HTMLFormElement>(null);
  const { status, message, errors, submit, clearError, reset } = useFormSubmit<ContactInput>("/api/contact");

  const set = (field: keyof typeof EMPTY) => (event: { target: { value: string } }) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    clearError(field);
  };

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    const result = await submit(validateContact(form), { company: trap });
    if (result.status === "error") focusFirstError(formRef.current);
  };

  if (status === "success") {
    return (
      <div role="status" className="flex h-full min-h-[26rem] flex-col items-center justify-center px-4 py-10 text-center">
        <SuccessCheck />
        <h3 className="mt-6 font-display text-2xl font-extrabold tracking-[-0.02em] text-ink">
          Thanks, {form.name.trim().split(" ")[0]} — message received.
        </h3>
        <p className="mt-2 max-w-sm text-ink-muted">
          We usually reply within a few hours during opening time. For anything urgent, call {site.phone.display}.
        </p>
        <Button
          variant="outline"
          className="mt-7"
          onClick={() => {
            setForm(EMPTY);
            reset();
          }}
        >
          Send another message
        </Button>
      </div>
    );
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="relative flex h-full flex-col">
      <Honeypot value={trap} onChange={setTrap} />
      <div className="grid flex-1 grid-rows-[auto_auto_1fr] gap-x-4 gap-y-5 sm:grid-cols-2">
        <Field id="contact-name" label="Your name" error={errors.name}>
          <input {...fieldProps("contact-name", errors.name)} name="name" autoComplete="name" value={form.name} onChange={set("name")} className={inputStyles} />
        </Field>
        <Field id="contact-phone" label="Mobile number" error={errors.phone}>
          <input
            {...fieldProps("contact-phone", errors.phone)}
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="98765 43210"
            value={form.phone}
            onChange={set("phone")}
            className={inputStyles}
          />
        </Field>
        <Field id="contact-email" label="Email" optional error={errors.email}>
          <input
            {...fieldProps("contact-email", errors.email)}
            name="email"
            type="email"
            inputMode="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={form.email}
            onChange={set("email")}
            className={inputStyles}
          />
        </Field>
        <Field id="contact-topic" label="What is it about?" error={errors.topic}>
          <select {...fieldProps("contact-topic", errors.topic)} name="topic" value={form.topic} onChange={set("topic")} className={inputStyles}>
            {CONTACT_TOPICS.map((topic) => (
              <option key={topic} value={topic}>
                {topic}
              </option>
            ))}
          </select>
        </Field>
        <Field id="contact-message" label="Message" error={errors.message} className="flex flex-col sm:col-span-2">
          <textarea
            {...fieldProps("contact-message", errors.message)}
            name="message"
            rows={6}
            maxLength={1500}
            placeholder="Tell us the date, the number of guests, or what we can help with…"
            value={form.message}
            onChange={set("message")}
            className={cn(textareaStyles, "min-h-40 flex-1")}
          />
        </Field>
      </div>

      {status === "error" && message && (
        <p role="alert" className="mt-5 rounded-2xl bg-danger/10 px-4 py-3 text-sm font-medium text-danger-ink">
          {message}
        </p>
      )}

      <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-xs text-sm text-ink-subtle">We only use your details to reply to this message.</p>
        <SubmitButton pending={status === "submitting"} size="lg">
          <Send aria-hidden="true" className="size-5" />
          Send message
        </SubmitButton>
      </div>
    </form>
  );
}

/* ── Opening hours, with today highlighted ───────────────────────────────── */
export function HoursList() {
  const status = useOpenStatus();
  // Start the week on Monday.
  const week = [...site.hours.slice(1), site.hours[0]];

  return (
    <ul className="space-y-1 text-[0.9375rem]">
      {week.map((entry) => {
        const today = status?.today === entry.day;
        return (
          <li
            key={entry.day}
            aria-current={today ? "date" : undefined}
            className={cn(
              "flex items-center justify-between gap-4 rounded-xl px-3 py-1.5 transition-colors duration-500",
              today ? "bg-ink font-semibold text-white" : "text-ink-muted",
            )}
          >
            <span className="flex items-center gap-2">
              {entry.label}
              {today && (
                <span
                  className={cn(
                    "hidden rounded-full px-2 py-0.5 text-[0.6875rem] font-bold uppercase tracking-wide min-[25rem]:inline-block",
                    status?.isOpen ? "bg-success text-ink" : "bg-white/15 text-white",
                  )}
                >
                  {status?.isOpen ? "Open now" : "Today"}
                </span>
              )}
            </span>
            <span className="whitespace-nowrap tabular-nums">
              {formatClock(entry.open)} – {formatClock(entry.close)}
            </span>
          </li>
        );
      })}
    </ul>
  );
}

/* ── Google Map, loaded only when it scrolls into view ───────────────────── */
export function LazyMap({ className }: { className?: string }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "400px 0px" },
    );
    observer.observe(host);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={hostRef} className={cn("relative isolate overflow-hidden rounded-card bg-cream shadow-card ring-1 ring-ink/[0.05]", className)}>
      {/* The shimmer only runs while the map is actually loading — not while it waits off screen. */}
      {!loaded && (
        <div aria-hidden="true" className={cn("absolute inset-0 grid place-items-center", visible ? "skeleton" : "bg-[#f3ece2]")}>
          <span className="relative z-[1] rounded-full bg-white/80 px-4 py-2 text-sm font-medium text-ink-muted shadow-soft">Loading map…</span>
        </div>
      )}
      {visible && (
        <iframe
          src={site.maps.embedUrl}
          title={`Map showing ${site.legalName} on ${site.address.short}`}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
          onLoad={() => setLoaded(true)}
          className={cn("absolute inset-0 size-full border-0 transition-opacity duration-700", loaded ? "opacity-100" : "opacity-0")}
        />
      )}
      <a
        href={site.maps.directionsUrl}
        target="_blank"
        rel="noopener noreferrer"
        data-ripple=""
        className="absolute bottom-4 right-4 z-10 inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-medium text-white shadow-lift transition-[background-color,translate] duration-300 hover:-translate-y-0.5 hover:bg-ink-soft"
      >
        <Navigation aria-hidden="true" className="size-4 text-brand-400" />
        Get directions
        <span className="sr-only"> (opens Google Maps in a new tab)</span>
      </a>
    </div>
  );
}
