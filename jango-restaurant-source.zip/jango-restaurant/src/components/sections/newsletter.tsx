import Image from "next/image";

import basil from "@/assets/images/cutouts/basil.webp";
import chili from "@/assets/images/cutouts/chili.webp";
import lime from "@/assets/images/cutouts/lime.webp";
import tomatoes from "@/assets/images/cutouts/tomatoes.webp";
import { NewsletterForm } from "@/components/ui/newsletter-form";

/** Rounded subscription box with a subtle orange gradient. */
export function Newsletter() {
  return (
    <section id="newsletter" aria-labelledby="newsletter-title" className="pb-4">
      <div className="container-site">
        <div
          data-reveal="scale"
          data-scroll-root=""
          suppressHydrationWarning
          className="relative isolate overflow-hidden rounded-[2rem] bg-gradient-to-br from-brand-400 to-brand-500 px-6 py-14 shadow-[0_30px_70px_-30px_rgb(234_88_12/0.7)] sm:px-12 sm:py-16 lg:px-20 lg:py-20"
        >
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
            <div className="absolute -right-28 -top-28 size-96 rounded-full border-[3rem] border-white/15" />
            <div className="absolute -bottom-36 -left-20 size-80 rounded-full bg-white/15" />
            <div
              className="absolute inset-0 opacity-25"
              style={{ backgroundImage: "radial-gradient(rgb(17 24 39 / 0.35) 1px, transparent 1px)", backgroundSize: "26px 26px" }}
            />
          </div>

          {/* floating garnish */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 hidden lg:block">
            <div className="absolute right-[7%] top-[12%] w-24 rotate-12" data-parallax="0.6">
              <Image src={basil} alt="" sizes="96px" className="h-auto w-full animate-drift" />
            </div>
            <div className="absolute bottom-[10%] right-[16%] w-24 -rotate-6" data-parallax="-0.5">
              <Image src={tomatoes} alt="" sizes="96px" className="h-auto w-full animate-float" />
            </div>
            <div className="absolute right-[3%] top-[52%] w-[4.5rem]" data-parallax="0.9">
              <Image src={lime} alt="" sizes="72px" className="h-auto w-full animate-float-slow" />
            </div>
            <div className="absolute right-[27%] top-[14%] w-14 rotate-[40deg]" data-parallax="-0.8">
              <Image src={chili} alt="" sizes="56px" className="h-auto w-full animate-drift" />
            </div>
          </div>

          <div className="relative max-w-2xl">
            <p className="eyebrow inline-flex items-center gap-2.5 text-ink">
              <span aria-hidden="true" className="h-px w-7 bg-ink" />
              The Jango list
            </p>
            <h2 id="newsletter-title" className="text-section mt-4 text-ink">
              First dibs on new dishes and weekly offers.
            </h2>
            <p className="text-lead mt-4 max-w-xl text-ink/85">
              One short email a week: what is new on the menu, this week’s coupon codes and the occasional secret special.
            </p>
            <NewsletterForm className="mt-8 max-w-xl" />
          </div>
        </div>
      </div>
    </section>
  );
}
