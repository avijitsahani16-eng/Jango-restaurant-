import { Apple, Bell, Bike, Check, ChevronDown, House, MapPin, Play, ReceiptText, Search, Star, UserRound } from "lucide-react";
import Image from "next/image";

import { Icon } from "@/components/ui/icon";
import { LogoMark } from "@/components/ui/logo";
import { Eyebrow } from "@/components/ui/primitives";
import { featuredCoupon, getSiteUrl, site } from "@/config/site";
import { categories } from "@/data/categories";
import { popularDishes } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { formatINR, formatRating } from "@/lib/format";
import { createQr } from "@/lib/qr";

const appFeatures = [
  { title: "Live order tracking", text: "Watch your order move from the kitchen to your gate." },
  { title: "One-tap reorders", text: "Your usual, saved and ready whenever you are." },
  { title: "App-only offers", text: "Early access to new dishes and weekly deals." },
  { title: "Tables in seconds", text: "Book, change or cancel a reservation from your phone." },
];

const stores = [
  { name: "App Store", kicker: "Download on the", href: site.app.ios, icon: Apple },
  { name: "Google Play", kicker: "Get it on", href: site.app.android, icon: Play },
];

/** Mobile app promotion: phone mock-up, features, store buttons and a scannable QR code. */
export function AppPromo() {
  const qr = createQr(`${getSiteUrl()}/menu?utm_source=qr&utm_medium=app-section`);

  return (
    <section id="app" aria-labelledby="app-title" className="section-y">
      <div className="container-site">
        <div
          data-scroll-root=""
          suppressHydrationWarning
          className="relative isolate overflow-hidden rounded-[2rem] bg-gradient-to-br from-brand-100 via-cream to-white px-6 pt-12 ring-1 ring-brand-200/60 sm:px-12 lg:px-16 lg:pt-0"
        >
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
            <div className="absolute -left-24 top-1/2 size-[34rem] -translate-y-1/2 rounded-full bg-[radial-gradient(closest-side,rgb(253_186_116/0.55),transparent)]" />
            <div
              className="absolute inset-0 opacity-[0.35]"
              style={{ backgroundImage: "radial-gradient(rgb(234 88 12 / 0.22) 1px, transparent 1px)", backgroundSize: "24px 24px" }}
            />
          </div>

          <div className="grid items-center gap-x-12 gap-y-12 lg:grid-cols-[0.9fr_1fr] xl:gap-x-20">
            {/* content */}
            <div className="lg:order-2 lg:py-20">
              <div data-reveal="up">
                <Eyebrow>Jango in your pocket</Eyebrow>
              </div>
              <h2 id="app-title" data-reveal="up" className="text-section mt-4">
                Your favourite table, now on your home screen.
              </h2>
              <p data-reveal="up" className="text-lead mt-5 max-w-xl text-ink-muted">
                Order in three taps, follow your rider on the map and get first dibs on every new dish. Free on Android and iOS.
              </p>

              <ul className="mt-8 grid gap-x-8 gap-y-5 sm:grid-cols-2">
                {appFeatures.map((feature) => (
                  <li key={feature.title} data-reveal="up" className="flex gap-3.5">
                    <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-full bg-ink text-brand-400">
                      <Check aria-hidden="true" className="size-4" strokeWidth={3} />
                    </span>
                    <span>
                      <span className="block font-display font-bold text-ink">{feature.title}</span>
                      <span className="mt-0.5 block text-[0.9375rem] leading-relaxed text-ink-muted">{feature.text}</span>
                    </span>
                  </li>
                ))}
              </ul>

              <div data-reveal="up" className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-6">
                <ul className="flex flex-wrap gap-3">
                  {stores.map(({ name, kicker, href, icon: StoreIcon }) => (
                    <li key={name}>
                      <a
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        data-ripple=""
                        aria-label={`${kicker} ${name} (opens in a new tab)`}
                        className="on-dark inline-flex h-14 items-center gap-3 rounded-2xl bg-ink pl-4 pr-6 text-white shadow-card transition-[translate,box-shadow,background-color] duration-300 ease-out-expo hover:-translate-y-0.5 hover:bg-ink-soft hover:shadow-lift"
                      >
                        <StoreIcon aria-hidden="true" className={cn("size-7", name === "Google Play" && "fill-brand-500 text-brand-500")} />
                        <span className="text-left leading-none">
                          <span className="block text-[0.6875rem] text-white/75">{kicker}</span>
                          <span className="mt-1 block font-display text-lg font-bold tracking-[-0.01em]">{name}</span>
                        </span>
                      </a>
                    </li>
                  ))}
                </ul>

                <div className="flex items-center gap-4">
                  <div className="rounded-2xl bg-white p-3 shadow-card ring-1 ring-ink/[0.06]">
                    <svg
                      role="img"
                      aria-label="QR code that opens the Jango menu on your phone"
                      viewBox={`0 0 ${qr.size} ${qr.size}`}
                      shapeRendering="crispEdges"
                      className="size-[5.5rem]"
                    >
                      <path d={qr.path} fill="#111827" />
                    </svg>
                  </div>
                  <p className="max-w-[9.5rem] text-sm leading-snug text-ink-muted">
                    <span className="block font-display text-base font-bold text-ink">Scan to order</span>
                    Point your camera to open the menu on your phone.
                  </p>
                </div>
              </div>
            </div>

            {/* phone */}
            <div className="relative mx-auto w-full max-w-[26rem] lg:order-1 lg:self-end">
              <div data-parallax="0.35" className="relative mx-auto w-[17.5rem] sm:w-[19rem] lg:mt-16">
                <PhoneMockup />
              </div>

              {/* floating notifications */}
              <div className="absolute left-0 top-[14%] sm:-left-4" data-parallax="0.9">
                <div aria-hidden="true" className="glass flex animate-float items-center gap-3 rounded-[1.25rem] p-2.5 pr-4 shadow-float">
                  <span className="grid size-10 place-items-center rounded-full bg-success text-ink">
                    <Check className="size-5" strokeWidth={3} />
                  </span>
                  <p className="leading-tight">
                    <span className="block font-display text-sm font-bold text-ink">Order confirmed</span>
                    <span className="block text-xs text-ink-muted">Arriving in 28 min</span>
                  </p>
                </div>
              </div>
              <div className="absolute bottom-[41%] right-0 sm:-right-4" data-parallax="-0.5">
                <div aria-hidden="true" className="glass flex animate-float-slow items-center gap-3 rounded-[1.25rem] p-2.5 pr-4 shadow-float">
                  <span className="grid size-10 place-items-center rounded-full bg-brand-500 text-ink">
                    <Bell className="size-5" />
                  </span>
                  <p className="leading-tight">
                    <span className="block font-display text-sm font-bold text-ink">{featuredCoupon.value}% off tonight</span>
                    <span className="block text-xs text-ink-muted">Use {featuredCoupon.code}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/** A CSS-drawn handset showing the ordering experience. Decorative, described by one label. */
function PhoneMockup() {
  const picks = popularDishes.slice(0, 2);
  const chips = categories.slice(0, 4);

  return (
    <div
      role="img"
      aria-label="Preview of the Jango app: delivery address, search, today’s offer, categories, popular dishes and a live order tracker"
      className="relative rounded-t-[3rem] bg-ink p-2.5 pb-0 shadow-lift ring-1 ring-white/10"
    >
      <span aria-hidden="true" className="absolute -left-1 top-28 h-10 w-1 rounded-l bg-ink" />
      <span aria-hidden="true" className="absolute -right-1 top-36 h-16 w-1 rounded-r bg-ink" />
      <div aria-hidden="true" className="relative h-[37.5rem] overflow-hidden rounded-t-[2.4rem] bg-canvas sm:h-[39.5rem]">
        <span className="absolute left-1/2 top-2.5 z-10 h-6 w-24 -translate-x-1/2 rounded-full bg-ink" />

        {/* status bar */}
        <div className="flex h-11 items-end justify-between px-7 pb-1 font-display text-[0.6875rem] font-bold text-ink">
          <span>7:42</span>
          <span className="flex items-center gap-1">
            <span className="flex items-end gap-px">
              <i className="h-1 w-0.5 rounded-sm bg-ink" />
              <i className="h-1.5 w-0.5 rounded-sm bg-ink" />
              <i className="h-2 w-0.5 rounded-sm bg-ink" />
              <i className="h-2.5 w-0.5 rounded-sm bg-ink" />
            </span>
            <span className="relative ml-1 h-2.5 w-5 rounded-[3px] border border-ink p-px">
              <i className="block h-full w-3/4 rounded-[1px] bg-ink" />
            </span>
          </span>
        </div>

        <div className="px-4 pt-2.5">
          {/* address + avatar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <LogoMark className="size-8" />
              <div className="leading-tight">
                <p className="text-[0.625rem] text-ink-muted">Deliver to</p>
                <p className="flex items-center gap-0.5 font-display text-xs font-bold text-ink">
                  <MapPin className="size-3 text-brand-600" />
                  Dhubulia, NH12
                  <ChevronDown className="size-3" />
                </p>
              </div>
            </div>
            <span className="grid size-8 place-items-center rounded-full bg-brand-200 font-display text-[0.625rem] font-extrabold text-brand-900">AR</span>
          </div>

          {/* search */}
          <div className="mt-3 flex h-9 items-center gap-2 rounded-full bg-white px-3.5 text-[0.6875rem] text-ink-subtle shadow-soft ring-1 ring-ink/[0.05]">
            <Search className="size-3.5" />
            Search biryani, momos, pizza…
          </div>

          {/* offer */}
          <div className="relative mt-3 overflow-hidden rounded-2xl bg-ink p-3.5 text-white">
            <div className="absolute -right-6 -top-8 size-24 rounded-full bg-brand-500/60 blur-2xl" />
            <p className="relative text-[0.5625rem] font-bold uppercase tracking-[0.14em] text-brand-400">This week only</p>
            <p className="relative mt-1 font-display text-base font-extrabold leading-tight">
              {featuredCoupon.value}% off your
              <br />
              first order
            </p>
            <span className="relative mt-2 inline-block rounded-full bg-brand-500 px-2.5 py-1 font-display text-[0.5625rem] font-extrabold tracking-[0.1em] text-ink">
              {featuredCoupon.code}
            </span>
          </div>

          {/* categories */}
          <div className="mt-3 flex justify-between">
            {chips.map((category) => (
              <div key={category.slug} className="flex w-14 flex-col items-center gap-1">
                <span className="grid size-11 place-items-center rounded-2xl bg-cream text-brand-600 ring-1 ring-brand-200/70">
                  <Icon name={category.icon} className="size-5" strokeWidth={1.75} />
                </span>
                <span className="text-[0.5625rem] font-semibold text-ink">{category.name}</span>
              </div>
            ))}
          </div>

          {/* popular */}
          <p className="mt-3.5 font-display text-xs font-extrabold text-ink">Popular near you</p>
          <div className="mt-2 grid grid-cols-2 gap-2.5">
            {picks.map((dish) => (
              <div key={dish.id} className="rounded-2xl bg-white p-1.5 shadow-soft ring-1 ring-ink/[0.05]">
                <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-cream">
                  {dish.image && <Image src={dish.image} alt="" fill sizes="140px" className="object-cover" />}
                </div>
                <p className="mt-1.5 truncate px-1 font-display text-[0.6875rem] font-bold text-ink">{dish.name}</p>
                <p className="flex items-center justify-between px-1 pb-0.5 text-[0.625rem]">
                  <span className="font-display font-extrabold text-ink">{formatINR(dish.price)}</span>
                  <span className="flex items-center gap-0.5 font-semibold text-ink">
                    <Star className="size-2.5 fill-brand-500 text-brand-500" />
                    {formatRating(dish.rating)}
                  </span>
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* live tracker */}
        <div className="absolute inset-x-3 bottom-14 rounded-2xl bg-ink p-3 text-white shadow-lift">
          <div className="flex items-center gap-2.5">
            <span className="grid size-8 shrink-0 place-items-center rounded-full bg-brand-500 text-ink">
              <Bike className="size-4" />
            </span>
            <p className="flex-1 leading-tight">
              <span className="block font-display text-[0.6875rem] font-bold">Out for delivery</span>
              <span className="block text-[0.5625rem] text-white/75">Your rider is 12 minutes away</span>
            </p>
            <span className="font-display text-xs font-extrabold text-brand-400">12 min</span>
          </div>
          <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-white/15">
            <div className="h-full w-[68%] rounded-full bg-brand-500" />
          </div>
        </div>

        {/* tab bar */}
        <div className="absolute inset-x-0 bottom-0 flex h-12 items-center justify-around border-t border-line bg-white/95 px-4">
          <House className="size-[1.125rem] text-brand-600" />
          <Search className="size-[1.125rem] text-ink-subtle" />
          <ReceiptText className="size-[1.125rem] text-ink-subtle" />
          <UserRound className="size-[1.125rem] text-ink-subtle" />
        </div>
      </div>
    </div>
  );
}
