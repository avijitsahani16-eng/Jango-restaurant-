"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import Image from "next/image";
import { useEffect, useRef } from "react";

import { Modal } from "@/components/ui/modal";
import { cn } from "@/lib/cn";
import type { GalleryImage } from "@/types";

interface LightboxProps {
  photos: readonly GalleryImage[];
  /** Index of the open photo, or `null` when closed. */
  index: number | null;
  onChange: (index: number | null) => void;
}

/** Full-screen photo viewer: arrow keys, swipe, thumbnails, Escape to close. */
export function GalleryLightbox({ photos, index, onChange }: LightboxProps) {
  const open = index !== null;
  const touchStart = useRef<number | null>(null);

  const step = (delta: number) => {
    if (index === null) return;
    onChange((index + delta + photos.length) % photos.length);
  };

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight") onChange(((index ?? 0) + 1) % photos.length);
      if (event.key === "ArrowLeft") onChange(((index ?? 0) - 1 + photos.length) % photos.length);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open, index, photos.length, onChange]);

  const photo = index !== null ? photos[index] : null;
  const control =
    "grid size-12 place-items-center rounded-full bg-white/10 text-white ring-1 ring-inset ring-white/20 backdrop-blur transition-colors duration-300 hover:bg-white hover:text-ink";

  return (
    <Modal open={open} onClose={() => onChange(null)} variant="full" label="Photo gallery" className="on-dark flex flex-col bg-ink/80">
      {photo && (
        <>
          <div className="flex shrink-0 items-center justify-between gap-4 px-4 py-4 text-white sm:px-8">
            <p className="font-display text-sm font-bold tabular-nums" aria-live="polite">
              {String((index ?? 0) + 1).padStart(2, "0")} <span className="text-white/60">/ {String(photos.length).padStart(2, "0")}</span>
            </p>
            <button type="button" onClick={() => onChange(null)} aria-label="Close gallery" data-autofocus="" className={control}>
              <X aria-hidden="true" className="size-5" />
            </button>
          </div>

          <div
            className="relative flex min-h-0 flex-1 items-center justify-center px-4 sm:px-24"
            onTouchStart={(event) => {
              touchStart.current = event.touches[0]?.clientX ?? null;
            }}
            onTouchEnd={(event) => {
              const start = touchStart.current;
              touchStart.current = null;
              if (start === null) return;
              const delta = (event.changedTouches[0]?.clientX ?? start) - start;
              if (Math.abs(delta) > 48) step(delta < 0 ? 1 : -1);
            }}
          >
            <button type="button" onClick={() => step(-1)} aria-label="Previous photo" className={cn(control, "absolute left-4 z-10 hidden sm:grid sm:left-8")}>
              <ChevronLeft aria-hidden="true" className="size-6" />
            </button>

            <AnimatePresence mode="wait" initial={false}>
              <m.figure
                key={photo.id}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="flex max-h-full flex-col items-center"
              >
                <Image
                  src={photo.src}
                  alt={photo.alt}
                  sizes="(min-width: 1024px) 70vw, 94vw"
                  placeholder="blur"
                  quality={85}
                  className="max-h-[66dvh] w-auto max-w-full rounded-[1.5rem] object-contain shadow-lift"
                />
                <figcaption className="mt-4 text-center font-display text-lg font-bold text-white">{photo.caption}</figcaption>
              </m.figure>
            </AnimatePresence>

            <button type="button" onClick={() => step(1)} aria-label="Next photo" className={cn(control, "absolute right-4 z-10 hidden sm:grid sm:right-8")}>
              <ChevronRight aria-hidden="true" className="size-6" />
            </button>
          </div>

          {/* Thumbnails (also the prev/next controls on phones) */}
          <div className="shrink-0 px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-4">
            <ul className="no-scrollbar mx-auto flex max-w-full justify-start gap-2 overflow-x-auto p-1 sm:justify-center">
              {photos.map((item, position) => (
                <li key={item.id} className="shrink-0">
                  <button
                    type="button"
                    onClick={() => onChange(position)}
                    aria-label={`Show photo ${position + 1}: ${item.caption}`}
                    aria-current={position === index ? "true" : undefined}
                    className={cn(
                      "relative block size-14 overflow-hidden rounded-xl transition-[opacity,box-shadow] duration-300 sm:size-16",
                      position === index ? "opacity-100 ring-2 ring-brand-500 ring-offset-2 ring-offset-ink" : "opacity-55 hover:opacity-100",
                    )}
                  >
                    <Image src={item.src} alt="" fill sizes="64px" className="object-cover" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </Modal>
  );
}
