import { ArrowRight, ArrowUpRight } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import { buttonStyles } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { SectionHeading } from "@/components/ui/primitives";
import { categories } from "@/data/categories";
import { categoryCounts } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { pluralize } from "@/lib/format";
import type { Category } from "@/types";

export function Categories() {
  return (
    <section id="categories" aria-labelledby="categories-title" className="section-y">
      <div className="container-site">
        <div className="flex flex-wrap items-end justify-between gap-x-10 gap-y-6">
          <SectionHeading
            id="categories-title"
            eyebrow="Browse by craving"
            title="Ten kitchens under one roof."
            description="From the tandoor to the wok to the pizza oven — pick a cuisine and go straight to what you feel like eating."
          />
          <Link href="/menu" data-reveal="up" data-ripple="" className={cn(buttonStyles({ variant: "outline" }), "group")}>
            View the full menu
            <ArrowRight aria-hidden="true" className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" />
          </Link>
        </div>

        <ul className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:mt-14 lg:grid-cols-5 lg:gap-5">
          {categories.map((category) => (
            <li key={category.slug} data-reveal="up">
              <CategoryCard category={category} count={categoryCounts[category.slug]} />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function CategoryCard({ category, count }: { category: Category; count: number }) {
  const href = `/menu/${category.slug}`;
  const label = pluralize(count, "dish", "dishes");

  /* Photo card — used automatically once a category has an image. */
  if (category.image) {
    return (
      <Link
        href={href}
        className="group relative block aspect-[4/5] overflow-hidden rounded-card bg-ink shadow-card transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1.5 hover:shadow-lift"
      >
        <Image
          src={category.image}
          alt={category.imageAlt ?? ""}
          fill
          sizes="(min-width: 1024px) 18vw, (min-width: 640px) 30vw, 46vw"
          placeholder="blur"
          className="object-cover transition-transform duration-[900ms] ease-out-expo group-hover:scale-110"
        />
        <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/20 to-transparent" />
        <span className="glass absolute left-3 top-3 grid size-11 place-items-center rounded-2xl text-brand-600">
          <Icon name={category.icon} className="size-5" />
        </span>
        <span className="absolute inset-x-4 bottom-4 text-white">
          <span className="block font-display text-xl font-bold tracking-[-0.02em]">{category.name}</span>
          <span className="mt-0.5 flex items-center justify-between text-sm text-white/85">
            {label}
            <ArrowUpRight aria-hidden="true" className="size-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </span>
        </span>
      </Link>
    );
  }

  /* Icon tile */
  return (
    <Link
      href={href}
      className="group relative flex h-full min-h-[12.5rem] flex-col justify-between overflow-hidden rounded-card bg-white p-4 shadow-card ring-1 ring-ink/[0.04] transition-[translate,box-shadow,background-color] duration-500 ease-out-expo hover:-translate-y-1.5 hover:bg-ink hover:shadow-lift sm:min-h-[14rem] sm:p-5"
    >
      {/* oversized watermark icon */}
      <Icon
        name={category.icon}
        strokeWidth={0.9}
        className="pointer-events-none absolute -bottom-7 -right-7 size-36 -rotate-12 text-brand-200/70 transition-[rotate,scale,color] duration-700 ease-out-expo group-hover:rotate-0 group-hover:scale-110 group-hover:text-white/10 sm:size-40"
      />

      <span className="relative flex items-start justify-between">
        <span className="grid size-12 place-items-center rounded-2xl bg-cream text-brand-600 transition-[background-color,color,scale] duration-500 ease-out-expo group-hover:scale-110 group-hover:bg-brand-500 group-hover:text-ink sm:size-14">
          <Icon name={category.icon} className="size-6 sm:size-7" strokeWidth={1.75} />
        </span>
        <span className="rounded-full bg-ink/[0.05] px-2.5 py-1 text-xs font-semibold text-ink-muted transition-colors duration-500 group-hover:bg-white/10 group-hover:text-white">
          {label}
        </span>
      </span>

      <span className="relative mt-8 block">
        <span className="block font-display text-xl font-bold tracking-[-0.02em] text-ink transition-colors duration-500 group-hover:text-white">
          {category.name}
        </span>
        <span className="mt-1 block text-sm leading-snug text-ink-muted transition-colors duration-500 group-hover:text-white/75">
          {category.tagline}
        </span>
        <span className="mt-3.5 inline-flex items-center gap-1 text-sm font-medium text-brand-700 transition-colors duration-500 group-hover:text-brand-400">
          Explore
          <ArrowRight aria-hidden="true" className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
        </span>
      </span>
    </Link>
  );
}
