import { CalendarCheck, Leaf, Star } from "lucide-react";
import Image from "next/image";

import { buttonStyles } from "@/components/ui/button";
import { Counter } from "@/components/ui/counter";
import { Icon } from "@/components/ui/icon";
import { OverlayButton } from "@/components/ui/overlay-button";
import { Eyebrow } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { kitchenPromises, servicePromises, whyImages } from "@/data/content";
import { totalDishes } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { formatRating } from "@/lib/format";
import type { Feature } from "@/types";

const stats = [
  { value: site.googleRating.value, decimals: 1, suffix: "", label: "Average rating on Google" },
  { value: 380, decimals: 0, suffix: "+", label: "Google reviews and counting" },
  { value: site.delivery.averageMinutes, decimals: 0, suffix: " min", label: "Average delivery time" },
  { value: totalDishes, decimals: 0, suffix: "", label: "Dishes cooked to order" },
];

export function WhyChooseUs() {
  return (
    <section id="about" aria-labelledby="about-title" data-scroll-root="" suppressHydrationWarning className="section-y overflow-x-clip">
      <div className="container-site">
        {/* Row 1 — the kitchen: image left, content right */}
        <div className="grid items-center gap-x-16 gap-y-12 lg:grid-cols-2 xl:gap-x-24">
          <figure data-reveal="right" className="relative mx-auto w-full max-w-xl lg:mx-0">
            <div aria-hidden="true" className="absolute -left-5 -top-5 size-40 rounded-[2rem] bg-brand-100 sm:-left-7 sm:-top-7" />
            <div aria-hidden="true" className="absolute -bottom-5 -right-5 size-52 rounded-full border-2 border-dashed border-brand-300 sm:-bottom-7 sm:-right-7" />
            <div className="group relative aspect-[4/5] overflow-hidden rounded-[2rem] bg-cream shadow-lift">
              <Image
                src={whyImages.kitchen.src}
                alt={whyImages.kitchen.alt}
                fill
                sizes="(min-width: 1024px) 42vw, 92vw"
                placeholder="blur"
                className="object-cover transition-transform duration-[1200ms] ease-out-expo group-hover:scale-105"
              />
            </div>
            <figcaption className="glass absolute -right-2 bottom-8 flex animate-float items-center gap-3 rounded-[1.25rem] p-3 pr-5 shadow-float sm:-right-8">
              <span className="grid size-11 place-items-center rounded-full bg-success text-ink">
                <Leaf aria-hidden="true" className="size-5" />
              </span>
              <span className="leading-tight">
                <span className="block font-display text-sm font-bold text-ink">Bought fresh daily</span>
                <span className="block text-xs text-ink-muted">Nothing pre-cooked, ever</span>
              </span>
            </figcaption>
          </figure>

          <div>
            <div data-reveal="up">
              <Eyebrow>Why choose Jango</Eyebrow>
            </div>
            <h2 id="about-title" data-reveal="up" className="text-section mt-4">
              Good food, served with a smile — every single time.
            </h2>
            <p data-reveal="up" className="text-lead mt-5 max-w-xl text-ink-muted">
              Jango sits right on NH12 in Dhubulia, between Krishnanagar and Bethuadahari. Families, travellers and regulars come for
              one reason: honest food cooked fresh, by people who care how it reaches your plate.
            </p>
            <PromiseList items={kitchenPromises} />
          </div>
        </div>

        {/* Animated counters */}
        <dl
          data-reveal="up"
          className="on-dark relative isolate my-16 grid grid-cols-2 gap-y-9 overflow-hidden rounded-[2rem] bg-ink px-6 py-10 text-white sm:px-10 lg:my-24 lg:grid-cols-4 lg:py-12"
        >
          <div aria-hidden="true" className="absolute -right-24 -top-24 -z-10 size-72 rounded-full bg-brand-500/25 blur-[90px]" />
          {stats.map((stat, index) => (
            <div key={stat.label} className={cn("flex flex-col-reverse px-2 text-center lg:px-6", index > 0 && "lg:border-l lg:border-white/10")}>
              <dt className="mt-2 text-sm text-white/75 sm:text-[0.9375rem]">{stat.label}</dt>
              <dd className="font-display text-[clamp(2.25rem,1.6rem+2.6vw,3.5rem)] font-extrabold leading-none tracking-[-0.04em] text-white">
                <Counter value={stat.value} decimals={stat.decimals} suffix={stat.suffix} />
              </dd>
            </div>
          ))}
        </dl>

        {/* Row 2 — the service: content left, image right */}
        <div className="grid items-center gap-x-16 gap-y-12 lg:grid-cols-2 xl:gap-x-24">
          <div className="order-2 lg:order-1">
            <div data-reveal="up">
              <Eyebrow>From our pass to your plate</Eyebrow>
            </div>
            <h3 data-reveal="up" className="text-section mt-4">
              Packed with care. Delivered without the wait.
            </h3>
            <p data-reveal="up" className="text-lead mt-5 max-w-xl text-ink-muted">
              A great dish can be ruined in the last kilometre, so we sweat the details after the cooking is done — the box, the seal,
              the route and the phone call if anything changes.
            </p>
            <PromiseList items={servicePromises} />
            <div data-reveal="up" className="mt-9 flex flex-wrap items-center gap-3.5">
              <OverlayButton overlay="reservation" data-ripple="" className={buttonStyles({ variant: "dark" })}>
                <CalendarCheck aria-hidden="true" className="size-5 text-brand-400" />
                Reserve a table
              </OverlayButton>
              <a
                href={site.maps.reviewsUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-ripple=""
                className={buttonStyles({ variant: "outline" })}
              >
                Read our Google reviews
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            </div>
          </div>

          <figure data-reveal="left" className="relative order-1 mx-auto w-full max-w-xl lg:order-2 lg:mx-0 lg:ml-auto">
            <div aria-hidden="true" className="absolute -right-5 -top-5 size-40 rounded-[2rem] bg-ink sm:-right-7 sm:-top-7" />
            <div aria-hidden="true" className="absolute -bottom-5 -left-5 size-52 rounded-full border-2 border-dashed border-brand-300 sm:-bottom-7 sm:-left-7" />
            <div className="group relative aspect-[4/5] overflow-hidden rounded-[2rem] bg-cream shadow-lift">
              <Image
                src={whyImages.service.src}
                alt={whyImages.service.alt}
                fill
                sizes="(min-width: 1024px) 42vw, 92vw"
                placeholder="blur"
                className="object-cover transition-transform duration-[1200ms] ease-out-expo group-hover:scale-105"
              />
            </div>
            <figcaption className="glass absolute -left-2 top-8 flex animate-float-slow items-center gap-3 rounded-[1.25rem] p-3 pr-5 shadow-float sm:-left-8">
              <span className="grid size-11 place-items-center rounded-full bg-brand-500 text-ink">
                <Star aria-hidden="true" className="size-5 fill-ink" />
              </span>
              <span className="leading-tight">
                <span className="block font-display text-sm font-bold text-ink">{formatRating(site.googleRating.value)} on Google</span>
                <span className="block text-xs text-ink-muted">{site.googleRating.label} reviews</span>
              </span>
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}

function PromiseList({ items }: { items: readonly Feature[] }) {
  return (
    <ul className="mt-9 space-y-3">
      {items.map((item) => (
        <li
          key={item.title}
          data-reveal="up"
          className="group flex gap-4 rounded-card p-4 transition-[background-color,box-shadow] duration-500 hover:bg-white hover:shadow-card sm:gap-5"
        >
          <span className="grid size-14 shrink-0 place-items-center rounded-2xl bg-cream text-brand-600 transition-[background-color,color,rotate] duration-500 ease-out-expo group-hover:-rotate-6 group-hover:bg-brand-500 group-hover:text-ink">
            <Icon name={item.icon} className="size-7" strokeWidth={1.75} />
          </span>
          <span>
            <span className="block font-display text-lg font-bold tracking-[-0.01em] text-ink">{item.title}</span>
            <span className="mt-1 block text-[0.9375rem] leading-relaxed text-ink-muted">{item.description}</span>
          </span>
        </li>
      ))}
    </ul>
  );
}
