import { Icon } from "@/components/ui/icon";
import { trustFeatures } from "@/data/content";

/** Eight floating feature cards that overlap the bottom of the hero. */
export function TrustFeatures() {
  return (
    <section aria-labelledby="features-title" className="relative z-10 -mt-12 lg:-mt-16">
      <div className="container-site">
        <h2 id="features-title" className="sr-only">
          Why people order from Jango
        </h2>
        <ul className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 lg:gap-5">
          {trustFeatures.map((feature) => (
            <li
              key={feature.title}
              data-reveal="up"
              className="group relative overflow-hidden rounded-card bg-white p-4 shadow-card ring-1 ring-ink/[0.04] transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1.5 hover:shadow-lift sm:p-6"
            >
              <span
                aria-hidden="true"
                className="absolute -right-8 -top-8 size-24 rounded-full bg-brand-100/0 transition-[background-color,scale] duration-700 ease-out-expo group-hover:scale-[1.6] group-hover:bg-brand-100/70"
              />
              <span className="relative grid size-12 place-items-center rounded-2xl bg-cream text-brand-600 transition-[background-color,color,rotate,scale] duration-500 ease-out-expo group-hover:-rotate-6 group-hover:scale-110 group-hover:bg-brand-500 group-hover:text-ink sm:size-14">
                <Icon name={feature.icon} className="size-6 sm:size-7" strokeWidth={1.75} />
              </span>
              <h3 className="relative mt-4 font-display text-[1.0625rem] font-bold leading-snug tracking-[-0.01em] text-ink sm:mt-5 sm:text-lg">
                {feature.title}
              </h3>
              <p className="relative mt-1.5 text-sm leading-relaxed text-ink-muted sm:text-[0.9375rem]">{feature.description}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
