import { ArrowRight, Bike, CalendarCheck, Clock, Flame, Star, Truck } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import basil from "@/assets/images/cutouts/basil.webp";
import biryani from "@/assets/images/cutouts/biryani.webp";
import butterChicken from "@/assets/images/cutouts/butter-chicken.webp";
import chili from "@/assets/images/cutouts/chili.webp";
import coriander from "@/assets/images/cutouts/coriander.webp";
import lime from "@/assets/images/cutouts/lime.webp";
import pizza from "@/assets/images/cutouts/pizza.webp";
import starAnise from "@/assets/images/cutouts/star-anise.webp";
import tomatoes from "@/assets/images/cutouts/tomatoes.webp";
import { QuickAddButton } from "@/components/menu/dish-actions";
import { buttonStyles } from "@/components/ui/button";
import { Magnetic } from "@/components/ui/magnetic";
import { OpenStatus } from "@/components/ui/open-status";
import { OverlayButton } from "@/components/ui/overlay-button";
import { avatarTone } from "@/components/ui/primitives";
import { site } from "@/config/site";
import { testimonials } from "@/data/content";
import { getDish } from "@/data/dishes";
import { cn } from "@/lib/cn";
import { formatINR, formatRating, initials } from "@/lib/format";

const rise = (delay: number) => ({ animationDelay: `${delay}ms` });

export function Hero() {
  const signature = getDish("smoky-butter-chicken");
  const faces = testimonials.slice(0, 4);

  return (
    <section
      aria-labelledby="hero-title"
      data-scroll-root=""
      suppressHydrationWarning
      className="relative isolate -mt-[4.75rem] overflow-hidden pt-[4.75rem]"
    >
      <HeroBackdrop />

      <div className="container-site grid items-center gap-x-10 gap-y-14 pb-24 pt-10 sm:pt-14 lg:grid-cols-[1.04fr_1fr] lg:pb-32 lg:pt-16">
        {/* ── Copy ─────────────────────────────────────────────────────── */}
        <div className="relative z-10 max-w-2xl">
          <p
            className="inline-flex animate-rise items-center gap-2.5 whitespace-nowrap rounded-full bg-white py-1.5 pl-1.5 pr-4 text-[0.8125rem] font-medium text-ink shadow-soft ring-1 ring-ink/[0.05] sm:text-sm"
            style={rise(0)}
          >
            <span className="grid size-7 place-items-center rounded-full bg-brand-500 text-ink">
              <Flame aria-hidden="true" className="size-4" />
            </span>
            <span className="hidden text-ink-muted min-[25rem]:inline">NH12, Dhubulia</span>
            <span aria-hidden="true" className="hidden h-3.5 w-px bg-ink/15 min-[25rem]:block" />
            <OpenStatus />
          </p>

          {/* The headline and lead paint immediately — they are the Largest Contentful Paint on phones,
              and Chrome does not reliably measure text that animates in. Everything around them still rises. */}
          <h1 id="hero-title" className="text-hero mt-6 text-ink">
            Fresh off the{" "}
            <span className="relative whitespace-nowrap text-brand-600">
              flame,
              <svg
                aria-hidden="true"
                viewBox="0 0 220 18"
                preserveAspectRatio="none"
                className="absolute -bottom-[0.12em] left-0 h-[0.2em] w-full text-brand-400/70"
              >
                <path d="M3 13C40 4 92 2 131 6c32 3 60 6 86 3" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
              </svg>
            </span>{" "}
            straight to your door.
          </h1>

          <p className="text-lead mt-6 max-w-xl text-ink-muted">
            Smoky tandoori, Kolkata-style biryani, wok-tossed noodles and blistered pizza — cooked to order at Jango and delivered hot
            in about {site.delivery.averageMinutes} minutes. Or book a table and stay for the cocktails.
          </p>

          <div className="mt-8 flex animate-rise flex-wrap items-center gap-3.5" style={rise(120)}>
            <Magnetic>
              <Link href="/menu" data-ripple="" className={cn(buttonStyles({ variant: "primary", size: "lg" }), "pr-2.5")}>
                Order online
                <span className="grid size-9 place-items-center rounded-full bg-ink text-white">
                  <ArrowRight aria-hidden="true" className="size-4" />
                </span>
              </Link>
            </Magnetic>
            <OverlayButton overlay="reservation" data-ripple="" className={buttonStyles({ variant: "outline", size: "lg" })}>
              <CalendarCheck aria-hidden="true" className="size-5 text-brand-600" />
              Book a table
            </OverlayButton>
          </div>

          {/* Social proof */}
          <div className="mt-10 flex animate-rise flex-wrap items-center gap-x-5 gap-y-4" style={rise(220)}>
            <div aria-hidden="true" className="flex -space-x-3">
              {faces.map((person) =>
                person.avatar ? (
                  <span key={person.id} className="relative size-12 overflow-hidden rounded-full ring-[3px] ring-canvas">
                    <Image src={person.avatar} alt="" fill sizes="48px" className="object-cover" />
                  </span>
                ) : (
                  <span
                    key={person.id}
                    className={cn(
                      "grid size-12 place-items-center rounded-full font-display text-sm font-extrabold ring-[3px] ring-canvas",
                      avatarTone(person.name),
                    )}
                  >
                    {initials(person.name)}
                  </span>
                ),
              )}
              <span className="grid size-12 place-items-center rounded-full bg-ink font-display text-xs font-extrabold text-white ring-[3px] ring-canvas">
                {site.googleRating.label}
              </span>
            </div>
            <a
              href={site.maps.reviewsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group rounded-xl"
            >
              <span className="flex items-center gap-2">
                <span className="font-display text-2xl font-extrabold tracking-[-0.03em] text-ink">{formatRating(site.googleRating.value)}</span>
                <span className="sr-only"> out of 5 stars, </span>
                <span aria-hidden="true" className="flex gap-0.5">
                  {[0, 1, 2, 3, 4].map((index) => (
                    <Star key={index} aria-hidden="true" className="size-[1.125rem] fill-brand-500 text-brand-500" />
                  ))}
                </span>
              </span>
              <span className="block text-sm text-ink-muted">
                from <span className="link-underline font-medium text-ink">{site.googleRating.label} reviews on Google</span>
                <span className="sr-only"> (opens in a new tab)</span>
              </span>
            </a>
          </div>

          {/* Delivery trust indicators */}
          <ul className="mt-9 grid animate-rise gap-3 border-t border-ink/10 pt-7 text-sm sm:grid-cols-3" style={rise(320)}>
            {[
              { icon: Bike, title: `${site.delivery.averageMinutes}-min delivery`, text: "Average, door to door" },
              { icon: Truck, title: "Free delivery", text: `On orders over ${formatINR(site.delivery.freeThreshold)}` },
              { icon: Clock, title: "11 AM – 11 PM", text: "Open all week" },
            ].map(({ icon: ItemIcon, title, text }) => (
              <li key={title} className="flex items-center gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-2xl bg-cream text-brand-600">
                  <ItemIcon aria-hidden="true" className="size-5" />
                </span>
                <span className="leading-snug">
                  <span className="block font-semibold text-ink">{title}</span>
                  <span className="text-ink-muted">{text}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* ── Food composition ─────────────────────────────────────────── */}
        <div className="relative mx-auto aspect-square w-full max-w-[25rem] sm:max-w-[32rem] lg:mr-0 lg:max-w-[41rem]">
          {/* stage */}
          <div aria-hidden="true" className="absolute inset-[6%] rounded-full bg-gradient-to-br from-brand-200/80 via-brand-50 to-white shadow-[inset_0_2px_30px_rgb(255_255_255/0.9)]" />
          <svg aria-hidden="true" viewBox="0 0 100 100" className="absolute inset-0 size-full animate-spin-slow text-brand-400/60">
            <circle cx="50" cy="50" r="49" fill="none" stroke="currentColor" strokeWidth="0.35" strokeDasharray="0.6 2.4" strokeLinecap="round" />
          </svg>

          {/* signature dish — also painted immediately (it is the LCP element on desktop) */}
          <div className="absolute inset-[13%]">
            <div aria-hidden="true" className="absolute inset-x-[10%] -bottom-[7%] h-[22%] rounded-[100%] bg-ink/30 blur-2xl" />
            <div className="size-full animate-float-slow">
              <Image
                data-spin="55"
                src={butterChicken}
                alt="Jango’s signature smoky butter chicken, finished with a swirl of cream and fresh coriander"
                sizes="(min-width: 1024px) 490px, (min-width: 640px) 380px, 74vw"
                loading="eager"
                fetchPriority="high"
                quality={85}
                className="size-full object-contain drop-shadow-[0_12px_18px_rgb(17_24_39/0.25)]"
              />
            </div>
          </div>

          {/* supporting dishes */}
          <Floating className="right-[-7%] top-[-3%] w-[31%]" parallax={0.55} delay={260} float="animate-float">
            <Image src={pizza} alt="Classic margherita pizza" sizes="(min-width: 1024px) 210px, 31vw" loading="eager" className="h-auto w-full drop-shadow-[0_14px_16px_rgb(17_24_39/0.28)]" />
          </Floating>
          <Floating className="bottom-[-2%] left-[-6%] w-[32%]" parallax={-0.35} delay={340} float="animate-float-slow">
            <Image src={biryani} alt="Kolkata-style chicken biryani" sizes="(min-width: 1024px) 215px, 32vw" loading="eager" className="h-auto w-full drop-shadow-[0_14px_16px_rgb(17_24_39/0.28)]" />
          </Floating>

          {/* fresh ingredients */}
          <Floating className="left-[13%] top-[1%] w-[15%] -rotate-12" parallax={0.9} delay={420} float="animate-drift">
            <Image src={basil} alt="" sizes="100px" loading="eager" className="h-auto w-full" />
          </Floating>
          <Floating className="left-[46%] top-[1%] w-[9%]" parallax={1.2} delay={480} float="animate-float">
            <Image src={lime} alt="" sizes="70px" loading="eager" className="h-auto w-full" />
          </Floating>
          <Floating className="right-[-4%] top-[35%] w-[14%] rotate-12" parallax={0.7} delay={540} float="animate-drift">
            <Image src={tomatoes} alt="" sizes="95px" loading="eager" className="h-auto w-full" />
          </Floating>
          <Floating className="bottom-[-7%] left-[41%] w-[11%] rotate-[24deg]" parallax={-0.6} delay={600} float="animate-float">
            <Image src={chili} alt="" sizes="75px" loading="eager" className="h-auto w-full" />
          </Floating>
          <Floating className="left-[-6%] top-[41%] hidden w-[13%] -rotate-6 sm:block" parallax={1} delay={660} float="animate-drift">
            <Image src={coriander} alt="" sizes="90px" loading="eager" className="h-auto w-full" />
          </Floating>
          <Floating className="left-[5%] top-[62%] hidden w-[7.5%] sm:block" parallax={-0.9} delay={720} float="animate-float-slow">
            <Image src={starAnise} alt="" sizes="52px" loading="eager" className="h-auto w-full" />
          </Floating>

          {/* floating delivery badge */}
          <Floating className="left-[-3%] top-[17%] z-10 sm:left-[-1%]" parallax={0.4} delay={520} float="animate-float">
            <div className="glass flex items-center gap-3 rounded-[1.25rem] p-2.5 pr-4 shadow-float">
              <span className="relative grid size-11 shrink-0 place-items-center rounded-full bg-brand-500 text-ink">
                <span aria-hidden="true" className="absolute inset-0 animate-pulse-ring rounded-full bg-brand-500" />
                <Bike aria-hidden="true" className="relative size-5" />
              </span>
              <p className="leading-tight">
                <span className="block font-display text-sm font-bold text-ink">{site.delivery.averageMinutes}-min delivery</span>
                <span className="block text-xs text-ink-muted">Tracked live to your gate</span>
              </p>
            </div>
          </Floating>

          {/* floating dish card */}
          {signature && (
            <Floating className="bottom-[9%] right-[-3%] z-10 sm:right-[-2%]" parallax={-0.25} delay={620} float="animate-float-slow">
              <div data-fly-root="" className="glass flex w-[15.5rem] items-center gap-3 rounded-[1.25rem] p-2 pr-2.5 shadow-float sm:w-[18.5rem]">
                {signature.image && (
                  <span className="relative size-14 shrink-0 overflow-hidden rounded-2xl bg-cream">
                    <Image data-fly-image="" src={signature.image} alt="" fill sizes="56px" className="object-cover" />
                  </span>
                )}
                <p className="min-w-0 flex-1 leading-tight">
                  <span className="block text-[0.6875rem] font-bold uppercase tracking-[0.08em] text-brand-700">Chef’s signature</span>
                  <span className="mt-0.5 block truncate font-display text-sm font-bold text-ink">{signature.name}</span>
                  <span className="mt-0.5 flex items-center gap-1.5 text-xs text-ink-muted">
                    <Star aria-hidden="true" className="size-3.5 fill-brand-500 text-brand-500" />
                    <span className="font-semibold text-ink">{formatRating(signature.rating)}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-semibold text-ink">{formatINR(signature.price)}</span>
                  </span>
                </p>
                <QuickAddButton dish={signature} />
              </div>
            </Floating>
          )}

          {/* rotating seal */}
          <Floating className="right-[-5%] top-[53%] hidden w-[17%] sm:block" parallax={0.8} delay={700} float="animate-float">
            <div aria-hidden="true" className="relative aspect-square">
              <svg viewBox="0 0 120 120" className="size-full animate-spin-slow drop-shadow-[0_10px_14px_rgb(17_24_39/0.25)]">
                <defs>
                  <path id="hero-seal-path" d="M60 60m-43 0a43 43 0 1 1 86 0a43 43 0 1 1-86 0" />
                </defs>
                <circle cx="60" cy="60" r="60" fill="#111827" />
                <text fill="#fff" fontSize="10.5" fontWeight="700" letterSpacing="2" className="font-display">
                  <textPath href="#hero-seal-path" textLength="262" lengthAdjust="spacing">
                    FRESH • HOT • FAST • EVERY DAY •
                  </textPath>
                </text>
              </svg>
              <span className="absolute inset-[27%] grid place-items-center rounded-full bg-brand-500 text-ink">
                <Flame className="size-[52%]" />
              </span>
            </div>
          </Floating>
        </div>
      </div>
    </section>
  );
}

/** A layer that fades in, drifts on scroll (parallax) and bobs gently. */
function Floating({
  className,
  parallax,
  delay,
  float,
  children,
}: {
  className?: string;
  parallax: number;
  delay: number;
  float: string;
  children: React.ReactNode;
}) {
  return (
    <div className={cn("absolute", className)}>
      <div data-parallax={parallax}>
        <div className="animate-rise" style={rise(delay)}>
          <div className={float} style={{ animationDelay: `-${delay * 4}ms` }}>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

/** Subtle, abstract food-inspired shapes behind the hero. */
function HeroBackdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="absolute -right-[12%] -top-[18%] size-[46rem] rounded-full bg-[radial-gradient(closest-side,rgb(253_186_116/0.42),transparent)]" />
      <div className="absolute -left-[18%] top-[38%] size-[38rem] rounded-full bg-[radial-gradient(closest-side,rgb(255_237_213/0.9),transparent)]" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-canvas" />

      <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 size-full">
        <g fill="none" stroke="#EA580C" strokeLinecap="round" strokeLinejoin="round" opacity="0.2" strokeWidth="1.6">
          {/* leaf */}
          <path d="M96 596c38-58 96-76 150-64-6 60-52 104-124 104 18-28 44-50 80-62" />
          {/* tomato slice */}
          <circle cx="664" cy="792" r="34" />
          <path d="M664 768v48M640 792h48M647 775l34 34M681 775l-34 34" />
          {/* steam squiggles */}
          <path d="M706 118c-14 16 14 28 0 44s14 28 0 44" />
          <path d="M738 132c-10 12 10 20 0 32s10 20 0 32" />
          {/* chilli */}
          <path d="M1332 706c-38 52-98 66-146 48 46-4 88-28 116-74 6-10 22-10 28 0 6 8 6 18 2 26Z" />
          <path d="M1318 682c6-12 16-18 28-18" />
          {/* onion rings */}
          <circle cx="1392" cy="386" r="26" />
          <circle cx="1392" cy="386" r="15" />
        </g>
        <g fill="#F97316" opacity="0.28">
          <circle cx="52" cy="232" r="4" />
          <circle cx="612" cy="212" r="3" />
          <circle cx="590" cy="676" r="5" />
          <circle cx="1226" cy="826" r="4" />
          <circle cx="24" cy="812" r="3" />
        </g>
        <g fill="none" stroke="#111827" strokeWidth="1.6" strokeLinecap="round" opacity="0.12">
          <path d="M552 498h18M561 489v18" />
          <path d="M162 148h14M169 141v14" />
          <path d="M1404 598h16M1412 590v16" />
        </g>
      </svg>
    </div>
  );
}
