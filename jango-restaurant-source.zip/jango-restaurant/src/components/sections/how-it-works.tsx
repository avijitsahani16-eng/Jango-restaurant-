import { Icon } from "@/components/ui/icon";
import { SectionHeading } from "@/components/ui/primitives";
import { steps } from "@/data/content";
import { cn } from "@/lib/cn";

/** Four steps, joined by dashed arrows that draw themselves as you scroll. */
export function HowItWorks() {
  return (
    <section id="how-it-works" aria-labelledby="how-title" className="section-y relative overflow-hidden bg-cream">
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 top-10 size-80 rounded-full bg-brand-200/50 blur-[100px]" />
      <div aria-hidden="true" className="pointer-events-none absolute -right-32 bottom-0 size-80 rounded-full bg-brand-200/40 blur-[100px]" />

      <div className="container-site relative">
        <SectionHeading
          id="how-title"
          align="center"
          eyebrow="How it works"
          title="Dinner, sorted in four easy steps."
          description="No app to install and no account to create. Pick what you love, check out, and we take it from there."
        />

        <ol className="relative mt-14 grid gap-y-4 sm:grid-cols-2 sm:gap-x-6 sm:gap-y-12 lg:mt-20 lg:grid-cols-4 lg:gap-x-0">
          {steps.map((step, index) => {
            const last = index === steps.length - 1;
            return (
              <li key={step.title} className="relative flex flex-col items-center px-2 text-center lg:px-7">
                {/* Desktop connector: a curved dashed arrow to the next step */}
                {!last && (
                  <svg
                    aria-hidden="true"
                    data-wipe="x"
                    viewBox="0 0 160 48"
                    className={cn(
                      "absolute left-[calc(50%+3.75rem)] top-9 hidden h-12 w-[calc(100%-7.5rem)] text-brand-500 lg:block",
                      index % 2 === 1 && "-scale-y-100",
                    )}
                    preserveAspectRatio="none"
                    fill="none"
                  >
                    <path className="connector-path" d="M4 34C44 4 112 4 152 30" stroke="currentColor" strokeWidth="2" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
                    <path d="M141 22.5 153 31l-14 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
                  </svg>
                )}

                <div data-reveal="scale" className="relative">
                  <span className="grid size-[7.5rem] place-items-center rounded-[2rem] bg-white text-brand-600 shadow-card ring-1 ring-ink/[0.04] transition-[translate,box-shadow] duration-500 ease-out-expo hover:-translate-y-1.5 hover:shadow-lift">
                    <Icon name={step.icon} className="size-12" strokeWidth={1.5} />
                  </span>
                  <span className="absolute -right-3 -top-3 grid size-11 place-items-center rounded-full bg-ink font-display text-base font-extrabold text-white ring-4 ring-cream">
                    <span className="sr-only">Step </span>
                    {index + 1}
                  </span>
                </div>

                <h3 data-reveal="up" className="text-card-title mt-7 text-ink">
                  {step.title}
                </h3>
                <p data-reveal="up" className="mt-2.5 max-w-[17rem] text-[0.9375rem] leading-relaxed text-ink-muted">
                  {step.description}
                </p>

                {/* Phone connector: a short dashed drop to the next step */}
                {!last && (
                  <svg aria-hidden="true" data-wipe="y" viewBox="0 0 16 56" className="mt-4 h-14 w-4 text-brand-500 sm:hidden" fill="none">
                    <path className="connector-path" d="M8 2v44" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                    <path d="m2 42 6 8 6-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
