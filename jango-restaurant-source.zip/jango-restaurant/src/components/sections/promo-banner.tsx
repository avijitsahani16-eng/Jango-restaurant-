import { ArrowRight, BadgePercent } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import basil from "@/assets/images/cutouts/basil.webp";
import biryani from "@/assets/images/cutouts/biryani.webp";
import butterChicken from "@/assets/images/cutouts/butter-chicken.webp";
import chili from "@/assets/images/cutouts/chili.webp";
import lime from "@/assets/images/cutouts/lime.webp";
import starAnise from "@/assets/images/cutouts/star-anise.webp";
import tomatoes from "@/assets/images/cutouts/tomatoes.webp";
import { buttonStyles } from "@/components/ui/button";
import { CouponCopy } from "@/components/ui/coupon-copy";
import { Magnetic } from "@/components/ui/magnetic";
import { Eyebrow } from "@/components/ui/primitives";
import { featuredCoupon } from "@/config/site";
import { cn } from "@/lib/cn";
import { formatINR } from "@/lib/format";

/** Full-width offer: dark, luxurious, with orange highlights and layered food artwork. */
export function PromoBanner() {
  const coupon = featuredCoupon;

  return (
    <section id="offers" aria-labelledby="offers-title" className="section-y">
      <div className="container-site">
        <div
          data-reveal="scale"
          data-scroll-root=""
          suppressHydrationWarning
          className="on-dark relative isolate overflow-hidden rounded-[2rem] bg-ink text-white shadow-lift"
        >
          {/* atmosphere */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
            <div className="absolute -right-[10%] top-1/2 size-[46rem] -translate-y-1/2 rounded-full bg-[radial-gradient(closest-side,rgb(249_115_22/0.5),rgb(249_115_22/0.12)_55%,transparent)]" />
            <div className="absolute -left-40 -top-40 size-[28rem] rounded-full bg-brand-500/15 blur-[110px]" />
            <div
              className="absolute inset-0 opacity-[0.07]"
              style={{ backgroundImage: "radial-gradient(#fff 1px, transparent 1px)", backgroundSize: "22px 22px" }}
            />
          </div>

          <div className="grid items-center lg:grid-cols-[1.05fr_1fr]">
            {/* copy */}
            <div className="relative z-10 px-6 pb-4 pt-10 sm:px-12 sm:pt-14 lg:py-20 lg:pl-16 lg:pr-0">
              <Eyebrow tone="dark">This week only</Eyebrow>
              <h2 id="offers-title" className="mt-5 font-display font-extrabold leading-[0.95] tracking-[-0.04em] text-white">
                <span className="block text-[clamp(4rem,2rem+9vw,8.5rem)] text-brand-500">
                  {coupon.value}%<span className="ml-3 text-[0.42em] font-extrabold tracking-[-0.02em] text-white">OFF</span>
                </span>
                <span className="mt-2 block text-[clamp(1.75rem,1.2rem+2vw,2.75rem)] leading-[1.08]">your first order from Jango.</span>
              </h2>
              <p className="text-lead mt-5 max-w-md text-white/75">
                Save up to {formatINR(coupon.maxDiscount ?? 0)} on orders above {formatINR(coupon.minSubtotal)}. Copy the code and it
                applies itself at checkout.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <CouponCopy code={coupon.code} />
                <Magnetic>
                  <Link href="/menu" data-ripple="" className={cn(buttonStyles({ variant: "primary", size: "lg" }), "pr-2.5")}>
                    Order now
                    <span className="grid size-9 place-items-center rounded-full bg-ink text-white">
                      <ArrowRight aria-hidden="true" className="size-4" />
                    </span>
                  </Link>
                </Magnetic>
              </div>
              <p className="mt-5 text-sm text-white/65">One use per customer. Not valid with other offers.</p>
            </div>

            {/* artwork */}
            <div className="relative mx-auto aspect-[1/0.92] w-full max-w-[30rem] lg:max-w-none">
              <svg aria-hidden="true" viewBox="0 0 100 100" className="absolute inset-[4%] size-[92%] animate-spin-slow text-white/25">
                <circle cx="50" cy="50" r="49" fill="none" stroke="currentColor" strokeWidth="0.3" strokeDasharray="0.6 2.6" strokeLinecap="round" />
              </svg>

              <div className="absolute left-[13%] top-[9%] w-[72%]" data-parallax="0.25">
                <Image
                  data-spin="-70"
                  src={biryani}
                  alt="A generous bowl of Kolkata-style chicken biryani"
                  sizes="(min-width: 1024px) 460px, 72vw"
                  className="h-auto w-full drop-shadow-[0_30px_40px_rgb(0_0_0/0.55)]"
                />
              </div>
              <div className="absolute bottom-[1%] left-[-2%] w-[36%]" data-parallax="-0.35">
                <Image
                  src={butterChicken}
                  alt="A bowl of smoky butter chicken"
                  sizes="(min-width: 1024px) 230px, 36vw"
                  className="h-auto w-full animate-float-slow drop-shadow-[0_22px_28px_rgb(0_0_0/0.55)]"
                />
              </div>

              <PromoBit className="left-[4%] top-[6%] w-[16%] -rotate-[18deg]" parallax={0.9} float="animate-drift">
                <Image src={basil} alt="" sizes="90px" className="h-auto w-full" />
              </PromoBit>
              <PromoBit className="right-[2%] top-[4%] w-[15%] rotate-12" parallax={0.6} float="animate-float">
                <Image src={tomatoes} alt="" sizes="90px" className="h-auto w-full" />
              </PromoBit>
              <PromoBit className="bottom-[4%] right-[10%] w-[12%] rotate-[30deg]" parallax={-0.7} float="animate-drift">
                <Image src={chili} alt="" sizes="70px" className="h-auto w-full" />
              </PromoBit>
              <PromoBit className="right-[-1%] top-[46%] w-[11%]" parallax={1.1} float="animate-float-slow">
                <Image src={lime} alt="" sizes="70px" className="h-auto w-full" />
              </PromoBit>
              <PromoBit className="left-[38%] top-[-1%] w-[8%]" parallax={-0.5} float="animate-float">
                <Image src={starAnise} alt="" sizes="50px" className="h-auto w-full" />
              </PromoBit>

              {/* savings sticker */}
              <div className="absolute left-[2%] top-[36%] sm:left-[4%]" data-parallax="0.5">
                <div className="flex animate-float items-center gap-3 rounded-[1.25rem] bg-white py-2.5 pl-2.5 pr-4 text-ink shadow-float">
                  <span className="grid size-11 place-items-center rounded-full bg-brand-500">
                    <BadgePercent aria-hidden="true" className="size-6" />
                  </span>
                  <p className="leading-tight">
                    <span className="block text-xs text-ink-muted">Save up to</span>
                    <span className="block font-display text-lg font-extrabold tracking-[-0.02em]">{formatINR(coupon.maxDiscount ?? 0)}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function PromoBit({ className, parallax, float, children }: { className: string; parallax: number; float: string; children: React.ReactNode }) {
  return (
    <div aria-hidden="true" className={cn("absolute", className)}>
      <div data-parallax={parallax}>
        <div className={float}>{children}</div>
      </div>
    </div>
  );
}
