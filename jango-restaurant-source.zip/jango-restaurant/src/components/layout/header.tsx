"use client";

import { AnimatePresence, useScroll, useSpring } from "framer-motion";
import * as m from "framer-motion/m";
import { ArrowRight, ChevronDown, Menu, Search, ShoppingBag, UserRound } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useId, useRef, useState } from "react";

import { buttonStyles, iconButtonStyles } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Logo } from "@/components/ui/logo";
import { SectionLink } from "@/components/ui/section-link";
import { primaryNav, site } from "@/config/site";
import { categories } from "@/data/categories";
import { categoryCounts, totalDishes } from "@/data/dishes";
import { useCartCount } from "@/hooks/use-cart";
import { useScrolledPast } from "@/hooks/use-scrolled-past";
import { cn } from "@/lib/cn";
import { pluralize } from "@/lib/format";
import { CART_ADD_EVENT } from "@/stores/cart";
import { ui } from "@/stores/ui";

const navLink =
  "inline-flex h-10 items-center gap-1 rounded-full px-3.5 text-[0.9375rem] font-medium text-ink-soft transition-colors duration-300 hover:bg-ink/[0.06] hover:text-ink aria-[current=page]:bg-ink/[0.06] aria-[current=page]:text-ink";

/* Desktop navigation leaves "Home" to the logo and puts Categories after Menu. */
const desktopNav = primaryNav.filter((item) => item.href !== "/");

export function Header() {
  const pathname = usePathname();
  const scrolled = useScrolledPast(12);
  const cartCount = useCartCount();

  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 140, damping: 28, mass: 0.4 });

  return (
    <header data-site-header="" data-scrolled={scrolled} data-print-hide="" className="group/header sticky top-0 z-50">
      {/* Surface: transparent over the hero, frosted glass once the page scrolls. */}
      <div
        aria-hidden="true"
        className={cn(
          "absolute inset-0 -z-10 border-b transition-[background-color,border-color,box-shadow,backdrop-filter] duration-500",
          scrolled
            ? "border-ink/[0.07] bg-canvas/80 shadow-soft backdrop-blur-xl backdrop-saturate-150"
            : "border-transparent bg-canvas/0",
        )}
      />

      <div
        className={cn(
          "container-site flex items-center justify-between gap-3 transition-[height] duration-500 ease-out-expo",
          scrolled ? "h-16" : "h-[4.75rem]",
        )}
      >
        <Link
          href="/"
          aria-label={`${site.name} ${site.descriptor} — home`}
          className={cn("shrink-0 origin-left rounded-2xl transition-[scale] duration-500 ease-out-expo", scrolled && "scale-[0.92]")}
        >
          <Logo />
        </Link>

        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-0.5">
            <li>
              <Link href="/menu" aria-current={pathname === "/menu" ? "page" : undefined} className={navLink}>
                Menu
              </Link>
            </li>
            <li>
              <CategoriesMenu active={pathname.startsWith("/menu/")} />
            </li>
            {desktopNav
              .filter((item) => item.href !== "/menu")
              .map((item) => (
                <li key={item.href}>
                  <SectionLink href={item.href} className={navLink}>
                    {item.label}
                  </SectionLink>
                </li>
              ))}
          </ul>
        </nav>

        <div className="flex items-center gap-1 sm:gap-1.5">
          <button
            type="button"
            onClick={() => ui.open("search")}
            aria-label="Search the menu"
            aria-keyshortcuts="/"
            className={cn(iconButtonStyles(), "2xl:hidden")}
          >
            <Search aria-hidden="true" className="size-5" />
          </button>
          <button
            type="button"
            onClick={() => ui.open("search")}
            aria-keyshortcuts="/"
            className="hidden h-11 w-52 items-center gap-2.5 rounded-full bg-white/70 pl-4 pr-2 text-left text-[0.9375rem] text-ink-subtle ring-1 ring-inset ring-ink/10 transition-[background-color,box-shadow] duration-300 hover:bg-white hover:ring-ink/20 2xl:flex"
          >
            <Search aria-hidden="true" className="size-[1.125rem] text-ink-muted" />
            <span className="flex-1">Search the menu</span>
            <kbd aria-hidden="true" className="grid size-7 place-items-center rounded-full bg-ink/[0.06] font-sans text-xs font-medium text-ink-muted">
              /
            </kbd>
          </button>

          <button type="button" onClick={() => ui.open("account")} aria-label="Your account" className={cn(iconButtonStyles(), "hidden sm:inline-grid")}>
            <UserRound aria-hidden="true" className="size-5" />
          </button>

          <CartButton count={cartCount} />

          <Link
            href="/menu"
            data-ripple=""
            className={cn(buttonStyles({ variant: "primary", size: "sm" }), "ml-1.5 hidden md:inline-flex lg:hidden xl:inline-flex")}
          >
            Order now
            <ArrowRight aria-hidden="true" className="size-4" />
          </Link>

          <button
            type="button"
            onClick={() => ui.open("nav")}
            aria-label="Open menu"
            aria-haspopup="dialog"
            className={cn(iconButtonStyles("light"), "ml-1 lg:hidden")}
          >
            <Menu aria-hidden="true" className="size-5" />
          </button>
        </div>
      </div>

      {/* Reading progress */}
      <m.div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-0.5 origin-left bg-brand-500" style={{ scaleX: progress }} />
    </header>
  );
}

/* ── Cart button with live badge ─────────────────────────────────────────── */
function CartButton({ count }: { count: number }) {
  const [bump, setBump] = useState(0);

  useEffect(() => {
    const onAdd = () => setBump((value) => value + 1);
    window.addEventListener(CART_ADD_EVENT, onAdd);
    return () => window.removeEventListener(CART_ADD_EVENT, onAdd);
  }, []);

  return (
    <button
      type="button"
      data-cart-target=""
      onClick={() => ui.open("cart")}
      aria-haspopup="dialog"
      aria-label={count > 0 ? `Open cart, ${pluralize(count, "item")}` : "Open cart, empty"}
      className={iconButtonStyles()}
    >
      <ShoppingBag key={`icon-${bump}`} aria-hidden="true" className={cn("size-5", bump > 0 && "animate-pop")} />
      {count > 0 && (
        <span
          key={`count-${count}`}
          aria-hidden="true"
          className="absolute right-0.5 top-0.5 grid h-5 min-w-5 animate-pop place-items-center rounded-full bg-brand-500 px-1 font-display text-[0.6875rem] font-extrabold leading-none text-ink ring-2 ring-canvas"
        >
          {count > 99 ? "99+" : count}
        </span>
      )}
    </button>
  );
}

/* ── Categories dropdown ─────────────────────────────────────────────────── */
function CategoriesMenu({ active }: { active: boolean }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const wrapperRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const closeTimer = useRef<number | undefined>(undefined);
  const hoverOpenedAt = useRef(0);

  const cancelClose = () => window.clearTimeout(closeTimer.current);
  const scheduleClose = () => {
    cancelClose();
    closeTimer.current = window.setTimeout(() => setOpen(false), 160);
  };

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: PointerEvent) => {
      if (!wrapperRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
      }
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  useEffect(() => () => window.clearTimeout(closeTimer.current), []);

  return (
    <div
      ref={wrapperRef}
      className="relative"
      onPointerEnter={(event) => {
        if (event.pointerType !== "mouse") return;
        cancelClose();
        hoverOpenedAt.current = event.timeStamp;
        setOpen(true);
      }}
      onPointerLeave={(event) => event.pointerType === "mouse" && scheduleClose()}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setOpen(false);
      }}
    >
      <button
        ref={buttonRef}
        type="button"
        aria-expanded={open}
        aria-controls={panelId}
        onClick={(event) => {
          // Hovering has just opened the menu — a click that follows should not shut it again.
          const justHovered = event.timeStamp - hoverOpenedAt.current < 700;
          setOpen((value) => (justHovered ? true : !value));
        }}
        className={cn(navLink, active && "bg-ink/[0.06] text-ink")}
      >
        Categories
        <ChevronDown aria-hidden="true" className={cn("size-4 transition-transform duration-300", open && "rotate-180")} />
      </button>

      <AnimatePresence>
        {open && (
          <m.div
            id={panelId}
            initial={{ opacity: 0, y: 10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.98 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            className="absolute left-1/2 top-full z-10 w-[37rem] -translate-x-1/2 pt-3"
          >
            <div className="origin-top rounded-panel bg-white p-3 shadow-lift ring-1 ring-ink/[0.06]">
              <ul className="grid grid-cols-2 gap-1">
                {categories.map((category) => (
                  <li key={category.slug}>
                    <Link
                      href={`/menu/${category.slug}`}
                      onClick={() => setOpen(false)}
                      className="group flex items-center gap-3.5 rounded-2xl p-2.5 transition-colors duration-200 hover:bg-cream"
                    >
                      <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-cream text-brand-600 transition-colors duration-300 group-hover:bg-brand-500 group-hover:text-ink">
                        <Icon name={category.icon} className="size-5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block font-display text-[0.9375rem] font-bold text-ink">{category.name}</span>
                        <span className="block truncate text-sm text-ink-muted">{category.tagline}</span>
                      </span>
                      <span className="text-xs font-medium text-ink-subtle">{categoryCounts[category.slug]}</span>
                    </Link>
                  </li>
                ))}
              </ul>
              <Link
                href="/menu"
                onClick={() => setOpen(false)}
                className="mt-2 flex items-center justify-between rounded-2xl bg-ink px-5 py-3.5 text-[0.9375rem] font-medium text-white transition-colors duration-300 hover:bg-ink-soft"
              >
                <span>
                  View the full menu <span className="text-white/75">· {totalDishes} dishes</span>
                </span>
                <ArrowRight aria-hidden="true" className="size-4 text-brand-400" />
              </Link>
            </div>
          </m.div>
        )}
      </AnimatePresence>
    </div>
  );
}
