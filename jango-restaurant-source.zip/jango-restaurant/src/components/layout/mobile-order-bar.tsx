"use client";

import { AnimatePresence } from "framer-motion";
import * as m from "framer-motion/m";
import { ArrowRight, Phone, ShoppingBag } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";

import { site } from "@/config/site";
import { useCart } from "@/hooks/use-cart";
import { useScrolledPast } from "@/hooks/use-scrolled-past";
import { formatINR, pluralize } from "@/lib/format";
import { ui } from "@/stores/ui";

/**
 * Bottom sticky call to action for phones and tablets.
 * Empty cart → "Order now"; otherwise a live cart summary that opens the cart.
 */
export function MobileOrderBar() {
  const pathname = usePathname();
  const scrolled = useScrolledPast(420);
  const { totals, isEmpty } = useCart();

  const onHome = pathname === "/";
  const onMenu = pathname.startsWith("/menu");
  const hidden = pathname.startsWith("/checkout");
  // With an empty cart the bar invites people to the menu — pointless once they are on it.
  const visible = !hidden && (!isEmpty || (!onMenu && (!onHome || scrolled)));

  return (
    <AnimatePresence>
      {visible && (
        <m.div
          data-print-hide=""
          initial={{ y: "120%" }}
          animate={{ y: 0 }}
          exit={{ y: "120%" }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] lg:hidden"
        >
          <div className="on-dark mx-auto flex max-w-xl items-center gap-2 rounded-full bg-ink/95 p-1.5 shadow-lift ring-1 ring-white/10 backdrop-blur-md">
            <a
              href={site.phone.href}
              aria-label={`Call ${site.name} on ${site.phone.display}`}
              className="grid size-12 shrink-0 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            >
              <Phone aria-hidden="true" className="size-5" />
            </a>

            {isEmpty ? (
              <Link
                href="/menu"
                data-ripple=""
                className="flex h-12 min-w-0 flex-1 items-center justify-center gap-2 rounded-full bg-brand-500 px-5 text-[0.9375rem] font-medium text-ink transition-colors hover:bg-brand-400"
              >
                Order now
                <ArrowRight aria-hidden="true" className="size-4" />
              </Link>
            ) : (
              <button
                type="button"
                data-ripple=""
                data-cart-target=""
                onClick={() => ui.open("cart")}
                aria-haspopup="dialog"
                className="flex h-12 min-w-0 flex-1 items-center justify-between gap-3 rounded-full bg-brand-500 pl-4 pr-5 text-[0.9375rem] font-medium text-ink transition-colors hover:bg-brand-400"
              >
                <span className="flex min-w-0 items-center gap-2.5">
                  <ShoppingBag aria-hidden="true" className="size-5 shrink-0" />
                  <span className="truncate">
                    {pluralize(totals.itemCount, "item")} · <span className="font-display font-bold tabular-nums">{formatINR(totals.subtotal)}</span>
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-1.5">
                  View cart
                  <ArrowRight aria-hidden="true" className="size-4" />
                </span>
              </button>
            )}
          </div>
        </m.div>
      )}
    </AnimatePresence>
  );
}
