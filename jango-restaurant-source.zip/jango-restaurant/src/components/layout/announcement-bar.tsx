import { Icon } from "@/components/ui/icon";
import { announcements, site } from "@/config/site";

/**
 * Slim promotional strip above the header.
 * Desktop shows all three messages; phones cycle through them one at a time.
 */
export function AnnouncementBar() {
  return (
    <div className="on-dark relative z-[51] bg-ink text-[0.8125rem] font-medium text-white" data-print-hide="">
      <div className="container-site flex h-10 items-center justify-center lg:justify-between">
        {/* Screen readers and large screens: the full list. */}
        <ul className="sr-only lg:not-sr-only lg:flex lg:items-center lg:gap-9">
          {announcements.map((item) => (
            <li key={item.text} className="flex items-center gap-2">
              <Icon name={item.icon} className="size-4 text-brand-400" />
              {item.icon === "headset" ? (
                <a href={site.phone.href} className="link-underline">
                  {item.text}
                </a>
              ) : (
                item.text
              )}
            </li>
          ))}
        </ul>

        {/* Phones: a vertical ticker (decorative duplicate of the list above). */}
        <div aria-hidden="true" className="h-10 overflow-hidden lg:hidden">
          <ul className="animate-ticker">
            {[...announcements, announcements[0]].map((item, index) => (
              <li key={index} className="flex h-10 items-center justify-center gap-2 whitespace-nowrap">
                <Icon name={item.icon} className="size-4 text-brand-400" />
                {item.text}
              </li>
            ))}
          </ul>
        </div>

        <p className="hidden items-center gap-2 text-white/80 lg:flex">
          <span aria-hidden="true" className="size-1.5 rounded-full bg-success" />
          {site.hoursSummary}
        </p>
      </div>
    </div>
  );
}
