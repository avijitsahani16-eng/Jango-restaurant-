import type { ReactNode } from "react";

import { Eyebrow } from "@/components/ui/primitives";

export interface LegalSection {
  heading: string;
  body: ReactNode;
}

/** Shared layout for the privacy policy and the terms of service. */
export function LegalPage({ title, updated, intro, sections }: { title: string; updated: string; intro: ReactNode; sections: LegalSection[] }) {
  return (
    <div className="relative">
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 -top-[4.75rem] -z-10 h-[24rem] bg-gradient-to-b from-brand-100/70 via-cream/60 to-transparent" />
      <article className="container-site pb-24 pt-10 lg:pb-32 lg:pt-16">
        <div className="mx-auto max-w-3xl">
          <Eyebrow>Legal</Eyebrow>
          <h1 className="text-section mt-4 text-ink">{title}</h1>
          <p className="mt-3 text-sm text-ink-subtle">Last updated: {updated}</p>
          <div className="text-lead mt-6 text-ink-muted">{intro}</div>

          <div className="mt-12 space-y-10">
            {sections.map((section, index) => (
              <section key={section.heading} aria-labelledby={`legal-${index}`}>
                <h2 id={`legal-${index}`} className="font-display text-2xl font-extrabold tracking-[-0.02em] text-ink">
                  {index + 1}. {section.heading}
                </h2>
                <div className="mt-3 space-y-3 text-[1.0625rem] leading-relaxed text-ink-muted [&_a]:font-medium [&_a]:text-brand-700 [&_a]:underline [&_a]:underline-offset-4 [&_li]:ml-5 [&_li]:list-disc [&_li]:pl-1 [&_strong]:font-semibold [&_strong]:text-ink [&_ul]:space-y-1.5">
                  {section.body}
                </div>
              </section>
            ))}
          </div>
        </div>
      </article>
    </div>
  );
}
