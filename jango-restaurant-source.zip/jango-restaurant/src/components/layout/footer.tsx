import { Clock, MapPin, Phone } from "lucide-react";
import Link from "next/link";

import { Icon, type IconName } from "@/components/ui/icon";
import { Logo } from "@/components/ui/logo";
import { NewsletterForm } from "@/components/ui/newsletter-form";
import { OpenStatus } from "@/components/ui/open-status";
import { OverlayButton } from "@/components/ui/overlay-button";
import { SectionLink } from "@/components/ui/section-link";
import { SocialIcon } from "@/components/ui/social-icon";
import { primaryNav, site } from "@/config/site";
import { categories } from "@/data/categories";

const footerLink = "link-underline inline-block py-1 text-[0.9375rem] text-white/75 transition-colors duration-300 hover:text-white";

const DOODLES: { icon: IconName; className: string }[] = [
  { icon: "pizza", className: "left-[4%] top-[12%] size-24 -rotate-12" },
  { icon: "cooking-pot", className: "right-[6%] top-[8%] size-28 rotate-12" },
  { icon: "martini", className: "left-[38%] top-[46%] size-20 rotate-6" },
  { icon: "hamburger", className: "right-[24%] bottom-[30%] size-24 -rotate-6" },
  { icon: "soup", className: "left-[14%] bottom-[22%] size-24 rotate-12" },
];

export function Footer() {
  const year = process.env.NEXT_PUBLIC_BUILD_YEAR ?? "2026";

  return (
    <footer className="on-dark relative isolate overflow-hidden bg-ink text-white" data-print-hide="">
      {/* Background illustration: warm glow, faint food line-art and an oversized wordmark. */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-40 -top-40 size-[34rem] rounded-full bg-brand-500/20 blur-[120px]" />
        <div className="absolute -bottom-52 right-[-10rem] size-[30rem] rounded-full bg-brand-600/15 blur-[120px]" />
        {DOODLES.map((doodle) => (
          <Icon key={doodle.icon} name={doodle.icon} strokeWidth={0.75} className={`absolute text-white/[0.045] ${doodle.className}`} />
        ))}
        <span className="absolute inset-x-0 -bottom-[0.24em] select-none text-center font-display text-[clamp(7rem,27vw,25rem)] font-extrabold leading-none tracking-[-0.06em] text-white/[0.035]">
          Jango
        </span>
      </div>

      <div className="container-site pb-10 pt-16 lg:pt-24">
        <div className="grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-3">
            <Link href="/" aria-label={`${site.name} ${site.descriptor} — home`} className="inline-block rounded-2xl">
              <Logo tone="light" />
            </Link>
            <p className="mt-5 max-w-sm text-[0.9375rem] leading-relaxed text-white/75">
              A kitchen and bar on NH12, Dhubulia — cooking tandoori, biryani, Indo-Chinese and more, fresh to order, every day from 11 to 11.
            </p>
            <ul className="mt-6 flex items-center gap-2">
              {site.social.map((profile) => (
                <li key={profile.name}>
                  <a
                    href={profile.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${site.name} on ${profile.name} (opens in a new tab)`}
                    className="grid size-11 place-items-center rounded-full bg-white/[0.08] text-white ring-1 ring-inset ring-white/15 transition-[background-color,color,translate] duration-300 hover:-translate-y-0.5 hover:bg-brand-500 hover:text-ink"
                  >
                    <SocialIcon name={profile.icon} />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick links */}
          <nav aria-labelledby="footer-quick-links" className="lg:col-span-2">
            <h2 id="footer-quick-links" className="eyebrow text-white">
              Quick links
            </h2>
            <ul className="mt-4 space-y-1">
              {primaryNav.map((item) => (
                <li key={item.href}>
                  <SectionLink href={item.href} className={footerLink}>
                    {item.label}
                  </SectionLink>
                </li>
              ))}
              <li>
                <SectionLink href="/#faq" className={footerLink}>
                  FAQ
                </SectionLink>
              </li>
            </ul>
          </nav>

          {/* Menu */}
          <nav aria-labelledby="footer-menu" className="lg:col-span-2">
            <h2 id="footer-menu" className="eyebrow text-white">
              Menu
            </h2>
            <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-1 sm:grid-cols-1">
              {categories.slice(0, 8).map((category) => (
                <li key={category.slug}>
                  <Link href={`/menu/${category.slug}`} className={footerLink}>
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Services + contact */}
          <div className="lg:col-span-2">
            <h2 id="footer-services" className="eyebrow text-white">
              Services
            </h2>
            <ul aria-labelledby="footer-services" className="mt-4 space-y-1">
              <li>
                <Link href="/menu" className={footerLink}>
                  Online ordering
                </Link>
              </li>
              <li>
                <OverlayButton overlay="reservation" className={footerLink}>
                  Table reservations
                </OverlayButton>
              </li>
              <li>
                <SectionLink href="/#contact" className={footerLink}>
                  Parties &amp; catering
                </SectionLink>
              </li>
              <li>
                <OverlayButton overlay="account" className={footerLink}>
                  Track your order
                </OverlayButton>
              </li>
              <li>
                <SectionLink href="/#app" className={footerLink}>
                  Mobile app
                </SectionLink>
              </li>
            </ul>
          </div>

          {/* Newsletter + contact */}
          <div className="sm:col-span-2 lg:col-span-3">
            <h2 className="eyebrow text-white">Stay in the loop</h2>
            <p className="mt-4 text-[0.9375rem] text-white/75">New dishes and weekly offers, straight to your inbox.</p>
            <NewsletterForm variant="compact" className="mt-4" />
          </div>
        </div>

        {/* Contact strip */}
        <address className="mt-12 grid gap-3 rounded-card bg-white/[0.05] p-5 not-italic ring-1 ring-inset ring-white/10 sm:grid-cols-3 sm:gap-6 sm:p-6">
          <a href={site.maps.directionsUrl} target="_blank" rel="noopener noreferrer" className="group flex items-start gap-3.5">
            <span className="grid size-11 shrink-0 place-items-center rounded-full bg-brand-500 text-ink">
              <MapPin aria-hidden="true" className="size-5" />
            </span>
            <span className="text-[0.9375rem] leading-snug">
              <span className="block font-semibold text-white">Visit us</span>
              <span className="text-white/75 group-hover:text-white">
                {site.address.street}, {site.address.locality}, {site.address.region} {site.address.postalCode}
              </span>
              <span className="sr-only"> (opens directions in a new tab)</span>
            </span>
          </a>
          <a href={site.phone.href} className="group flex items-start gap-3.5">
            <span className="grid size-11 shrink-0 place-items-center rounded-full bg-brand-500 text-ink">
              <Phone aria-hidden="true" className="size-5" />
            </span>
            <span className="text-[0.9375rem] leading-snug">
              <span className="block font-semibold text-white">Call to order or book</span>
              <span className="text-white/75 group-hover:text-white">{site.phone.display}</span>
            </span>
          </a>
          <div className="flex items-start gap-3.5">
            <span className="grid size-11 shrink-0 place-items-center rounded-full bg-brand-500 text-ink">
              <Clock aria-hidden="true" className="size-5" />
            </span>
            <span className="text-[0.9375rem] leading-snug">
              <span className="block font-semibold text-white">{site.hoursSummary}</span>
              <OpenStatus tone="dark" className="text-white/75" />
            </span>
          </div>
        </address>

        {/* Bottom bar */}
        <div className="mt-10 flex flex-col gap-6 border-t border-white/10 pb-24 pt-8 lg:flex-row lg:items-center lg:justify-between lg:pb-0">
          <p className="text-sm text-white/70">
            © {year} {site.legalName}. All rights reserved.
            <span className="mt-1 block text-xs text-white/60">Food photographs are representative; actual presentation may vary.</span>
          </p>

          <ul className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
            <li>
              <Link href="/privacy" className={footerLink.replace("text-[0.9375rem]", "text-sm")}>
                Privacy policy
              </Link>
            </li>
            <li>
              <Link href="/terms" className={footerLink.replace("text-[0.9375rem]", "text-sm")}>
                Terms of service
              </Link>
            </li>
          </ul>

          <div className="flex flex-wrap items-center gap-2">
            <span className="mr-1 text-sm text-white/70">We accept</span>
            <ul aria-label="Payment methods" className="flex flex-wrap items-center gap-1.5">
              {site.payments.map((method) => (
                <li
                  key={method}
                  className="inline-flex h-8 items-center rounded-lg bg-white px-2.5 font-display text-[0.6875rem] font-extrabold uppercase tracking-[0.06em] text-ink"
                >
                  {method}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
