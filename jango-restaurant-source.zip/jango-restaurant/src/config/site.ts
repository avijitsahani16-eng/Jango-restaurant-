/**
 * Single source of truth for brand, contact and policy details.
 *
 * ── REAL (taken from the restaurant's Google Maps listing) ───────────────────
 *    name, address, phone, opening hours, map location, Google rating.
 * ── SAMPLE (confirm with the owner before launch) ────────────────────────────
 *    delivery policy, coupons, social handles, app-store links.
 */
import type { Coupon } from "@/types";

const PLACE_ID = "ChIJF8dheXgf-TkRGF-_WNBvKp8";
/** The listing's own title and address, so the embedded map and directions resolve to exactly that place. */
const MAP_QUERY = "JANGO RESTAURANT CUM BAR, NH12, more, Hasadanga, Mayapur, Dhubulia, West Bengal 741140";

/** Public origin of the site. Set NEXT_PUBLIC_SITE_URL in production. */
export function getSiteUrl(): string {
  const explicit = process.env.NEXT_PUBLIC_SITE_URL;
  if (explicit) return explicit.replace(/\/+$/, "");
  const vercel = process.env.VERCEL_PROJECT_PRODUCTION_URL ?? process.env.VERCEL_URL;
  if (vercel) return `https://${vercel}`;
  return "http://localhost:3000";
}

export const site = {
  name: "Jango",
  legalName: "Jango Restaurant Cum Bar",
  descriptor: "Restaurant & Bar",
  tagline: "Fresh off the flame, straight to your door.",
  description:
    "Order tandoori, biryani, Indo-Chinese, pizza and more from Jango Restaurant Cum Bar on NH12, Dhubulia. Hot delivery in about 30 minutes, or book a table and stay for the cocktails.",
  locale: "en_IN",
  currency: "INR",
  cuisines: ["Indian", "Chinese", "Asian", "Pizza", "Burgers", "Pasta", "Sushi", "Desserts"],
  priceRange: "₹₹",

  phone: {
    display: "+91 81675 05450",
    href: "tel:+918167505450",
    e164: "+918167505450",
  },
  /** Leave empty to hide e-mail everywhere. */
  email: "",

  /** Word for word as on the Google Maps listing, so the site and the listing always agree. */
  address: {
    street: "NH12, more, Hasadanga, Mayapur",
    locality: "Dhubulia",
    district: "Nadia",
    region: "West Bengal",
    postalCode: "741140",
    country: "IN",
    countryName: "India",
    plusCode: "FF82+9P Dhubulia, West Bengal",
    /** One-line version for cards and the footer. */
    short: "NH12, more, Hasadanga, Mayapur, Dhubulia, West Bengal 741140",
  },

  /** The listing's pin on Google Maps. */
  geo: { latitude: 23.4659245, longitude: 88.4518634 },

  maps: {
    placeId: PLACE_ID,
    listingUrl: "https://maps.app.goo.gl/sSof1rKTT6YQ9PKMA",
    embedUrl: `https://www.google.com/maps/embed?origin=mfe&pb=!1m3!2m1!1s${encodeURIComponent(MAP_QUERY).replace(/%20/g, "+")}!6i16`,
    directionsUrl: `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(MAP_QUERY)}&destination_place_id=${PLACE_ID}`,
    reviewsUrl: `https://search.google.com/local/reviews?placeid=${PLACE_ID}`,
  },

  timeZone: "Asia/Kolkata",
  /** 0 = Sunday … 6 = Saturday. 24-hour "HH:mm". */
  hours: [
    { day: 0, label: "Sunday", open: "11:00", close: "23:00" },
    { day: 1, label: "Monday", open: "11:00", close: "23:00" },
    { day: 2, label: "Tuesday", open: "11:00", close: "23:00" },
    { day: 3, label: "Wednesday", open: "11:00", close: "23:00" },
    { day: 4, label: "Thursday", open: "11:00", close: "23:00" },
    { day: 5, label: "Friday", open: "11:00", close: "23:00" },
    { day: 6, label: "Saturday", open: "11:00", close: "23:00" },
  ],
  hoursSummary: "Open daily, 11 AM – 11 PM",

  /** As shown on the Google Maps listing when this site was built. */
  googleRating: { value: 4.7, count: 382, label: "380+" },

  /* ── SAMPLE policy values ──────────────────────────────────────────────── */
  delivery: {
    freeThreshold: 499,
    fee: 39,
    averageMinutes: 30,
    pickupMinutes: 20,
    area: "Dhubulia and nearby NH12 neighbourhoods",
  },
  /** GST on restaurant food. */
  taxRate: 0.05,
  maxQuantityPerDish: 20,
  legalDrinkingAge: 21,

  social: [
    { name: "Instagram", icon: "instagram", href: "https://www.instagram.com/" },
    { name: "Facebook", icon: "facebook", href: "https://www.facebook.com/" },
    { name: "YouTube", icon: "youtube", href: "https://www.youtube.com/" },
    { name: "Google Maps", icon: "google", href: "https://maps.app.goo.gl/sSof1rKTT6YQ9PKMA" },
  ],

  app: {
    ios: "https://apps.apple.com/",
    android: "https://play.google.com/store/apps",
  },

  payments: ["UPI", "Visa", "Mastercard", "RuPay", "Cash"],
} as const;

/* ── SAMPLE offers ───────────────────────────────────────────────────────── */
export const coupons: readonly Coupon[] = [
  {
    code: "JANGO20",
    title: "20% off your first order",
    description: "20% off up to ₹150 on orders above ₹399.",
    kind: "percent",
    value: 20,
    minSubtotal: 399,
    maxDiscount: 150,
  },
  {
    code: "TREAT50",
    title: "₹50 off",
    description: "Flat ₹50 off on orders above ₹299.",
    kind: "flat",
    value: 50,
    minSubtotal: 299,
  },
];

export const featuredCoupon = coupons[0];

export interface NavItem {
  label: string;
  href: string;
}

/** Primary navigation. Hash links resolve to sections on the home page. */
export const primaryNav: readonly NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Menu", href: "/menu" },
  { label: "Offers", href: "/#offers" },
  { label: "The Bar", href: "/#bar" },
  { label: "About", href: "/#about" },
  { label: "Contact", href: "/#contact" },
];

export const announcements = [
  { icon: "truck", text: `Free delivery on orders over ₹${site.delivery.freeThreshold}` },
  { icon: "timer", text: `Hot at your door in about ${site.delivery.averageMinutes} minutes` },
  { icon: "headset", text: `Need help? Call ${site.phone.display}` },
] as const;
