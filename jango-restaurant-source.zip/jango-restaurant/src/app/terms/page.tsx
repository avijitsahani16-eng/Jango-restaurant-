import type { Metadata } from "next";

import { LegalPage } from "@/components/layout/legal-page";
import { site } from "@/config/site";
import { formatINR } from "@/lib/format";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: `The terms that apply when you order food, book a table or use the website of ${site.legalName}.`,
  alternates: { canonical: "/terms" },
};

/**
 * SAMPLE TERMS — a sensible starting point written for this website.
 * Have them reviewed by the business owner (and ideally a lawyer) before launch.
 */
export default function TermsPage() {
  const { delivery } = site;

  return (
    <LegalPage
      title="Terms of service"
      updated="November 2026"
      intro={
        <p>
          These terms apply whenever you order from, book a table at, or use the website of {site.legalName}, {site.address.short}. By
          placing an order you agree to them.
        </p>
      }
      sections={[
        {
          heading: "Ordering",
          body: (
            <>
              <p>
                An order is confirmed once you see an order number on the confirmation screen. We may call you to confirm details, and we
                may decline an order if a dish is unavailable or your address is outside our delivery area.
              </p>
              <p>Dishes are cooked fresh, so preparation times are estimates and can be longer at busy times.</p>
            </>
          ),
        },
        {
          heading: "Prices and payment",
          body: (
            <ul>
              <li>Prices are in Indian rupees. GST is added at checkout and shown before you place the order.</li>
              <li>
                Delivery is free on orders over {formatINR(delivery.freeThreshold)}; otherwise a delivery fee of {formatINR(delivery.fee)}{" "}
                applies. Pickup is free.
              </li>
              <li>Payment is made on delivery or pickup by UPI, card or cash.</li>
              <li>Coupon codes cannot be combined, have no cash value and may be withdrawn at any time.</li>
            </ul>
          ),
        },
        {
          heading: "Delivery",
          body: (
            <p>
              We deliver across {delivery.area}. Please make sure someone is available at the address and reachable on the phone number you
              gave us. If we cannot reach you, the order may be cancelled.
            </p>
          ),
        },
        {
          heading: "Cancellations and refunds",
          body: (
            <p>
              You can cancel free of charge until the kitchen starts preparing your order — call us on{" "}
              <a href={site.phone.href}>{site.phone.display}</a> as soon as possible. If something is wrong or missing, tell us the same
              day and we will replace the dish or refund it.
            </p>
          ),
        },
        {
          heading: "Table reservations",
          body: (
            <p>
              A reservation request is confirmed once we call you back. We hold tables for 15 minutes after the reserved time. For groups
              of ten or more, please book at least a day in advance.
            </p>
          ),
        },
        {
          heading: "Alcohol",
          body: (
            <p>
              Alcohol is served only on the premises and only to guests aged {site.legalDrinkingAge} or above, in line with West Bengal
              law. We may ask for a valid photo ID and may refuse service. We do not deliver alcohol.
            </p>
          ),
        },
        {
          heading: "Allergies",
          body: (
            <p>
              Our kitchen handles nuts, dairy, gluten, eggs, shellfish and other allergens. We take care, but we cannot guarantee that any
              dish is completely free of them. Please tell us about allergies when you order.
            </p>
          ),
        },
        {
          heading: "This website",
          body: (
            <p>
              Food photographs are representative and the dish you receive may look different. We work to keep the menu, prices and
              opening hours up to date, but they can change without notice.
            </p>
          ),
        },
      ]}
    />
  );
}
