import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { MenuPage } from "@/components/menu/menu-page";
import { site } from "@/config/site";
import { categories, getCategory } from "@/data/categories";

/**
 * Keep this route fully static: unknown slugs wait for the complete render
 * instead of streaming a fallback shell, so `notFound()` can answer with a
 * real 404 status.
 */
export const ensureStatic = "navigation";

/** Every category is prerendered at build time. */
export function generateStaticParams() {
  return categories.map((category) => ({ category: category.slug }));
}

export async function generateMetadata({ params }: PageProps<"/menu/[category]">): Promise<Metadata> {
  const { category: slug } = await params;
  const category = getCategory(slug);
  if (!category) return { title: "Page not found", robots: { index: false, follow: true } };

  const description = `${category.description} Order ${category.name.toLowerCase()} online from ${site.legalName}, ${site.address.locality} — delivered in about ${site.delivery.averageMinutes} minutes.`;
  return {
    title: `${category.name} — Order Online`,
    description,
    alternates: { canonical: `/menu/${category.slug}` },
    openGraph: { title: `${category.name} — ${site.name} ${site.descriptor}`, description, url: `/menu/${category.slug}` },
  };
}

export default async function Page({ params }: PageProps<"/menu/[category]">) {
  const { category: slug } = await params;
  const category = getCategory(slug);
  if (!category) notFound();

  return <MenuPage category={category} />;
}
