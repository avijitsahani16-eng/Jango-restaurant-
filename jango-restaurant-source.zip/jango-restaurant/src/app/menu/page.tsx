import type { Metadata } from "next";

import { MenuPage } from "@/components/menu/menu-page";
import { site } from "@/config/site";
import { totalDishes } from "@/data/dishes";

const description = `Browse all ${totalDishes} dishes from ${site.legalName} — tandoori, biryani, Indo-Chinese, pizza, burgers, desserts and more. Order online for delivery in about ${site.delivery.averageMinutes} minutes.`;

export const metadata: Metadata = {
  title: "Menu — Order Online",
  description,
  alternates: { canonical: "/menu" },
  openGraph: { title: `Menu — ${site.name} ${site.descriptor}`, description, url: "/menu" },
};

export default function Page() {
  return <MenuPage category={null} />;
}
