import type { Metadata } from "next";

import { LegalPage } from "@/components/layout/legal-page";
import { site } from "@/config/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `How ${site.legalName} collects, uses and protects the information you share when you order, book a table or contact us.`,
  alternates: { canonical: "/privacy" },
};

/**
 * SAMPLE POLICY — a sensible starting point written for this website.
 * Have it reviewed by the business owner (and ideally a lawyer) before launch.
 */
export default function PrivacyPage() {
  return (
    <LegalPage
      title="Privacy policy"
      updated="November 2026"
      intro={
        <p>
          {site.legalName} (“Jango”, “we”, “us”) respects your privacy. This page explains what we collect when you use this website, why
          we collect it and the choices you have.
        </p>
      }
      sections={[
        {
          heading: "What we collect",
          body: (
            <ul>
              <li>
                <strong>Order details</strong> — your name, mobile number, delivery address, the dishes you order and any notes you add.
              </li>
              <li>
                <strong>Reservations and messages</strong> — your name, mobile number, the date, time and party size, and whatever you
                write to us.
              </li>
              <li>
                <strong>Newsletter</strong> — your email address, if you choose to subscribe.
              </li>
              <li>
                <strong>On your device</strong> — your cart, favourites, saved details and recent orders are stored in your own browser so
                the site can remember them. They are not sent to us until you place an order.
              </li>
            </ul>
          ),
        },
        {
          heading: "How we use it",
          body: (
            <>
              <p>We use your information only to do what you asked us to do:</p>
              <ul>
                <li>prepare and deliver your order, and call you if there is a problem with it;</li>
                <li>confirm or change a table reservation;</li>
                <li>reply to your message;</li>
                <li>send the newsletter, if you subscribed.</li>
              </ul>
              <p>We do not sell your information, and we do not share it with advertisers.</p>
            </>
          ),
        },
        {
          heading: "Who sees it",
          body: (
            <p>
              Our kitchen and delivery team see what they need to fulfil your order. Service providers that help us run this website (for
              example hosting) process data on our behalf and only under our instructions.
            </p>
          ),
        },
        {
          heading: "How long we keep it",
          body: (
            <p>
              Order and reservation records are kept for as long as we need them for accounting and tax purposes. Newsletter subscribers
              stay on the list until they unsubscribe. You can clear everything stored in your browser at any time from your browser
              settings.
            </p>
          ),
        },
        {
          heading: "Your choices",
          body: (
            <p>
              You can ask us to show you, correct or delete the information we hold about you. Call us on{" "}
              <a href={site.phone.href}>{site.phone.display}</a> or use the contact form on the home page and we will take care of it.
            </p>
          ),
        },
        {
          heading: "Cookies and third parties",
          body: (
            <p>
              This website does not use advertising or tracking cookies. The map on our contact section is provided by Google Maps and is
              loaded only when you scroll to it; Google’s own privacy policy applies to that map.
            </p>
          ),
        },
        {
          heading: "Changes to this policy",
          body: <p>If we change how we handle your information, we will update this page and the date at the top.</p>,
        },
      ]}
    />
  );
}
