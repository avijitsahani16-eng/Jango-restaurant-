# Rupee glyph subsets

`rupee-sans.woff2` and `rupee-display.woff2` each contain a single glyph — the
Indian rupee sign (₹, U+20B9) — taken from **Inter** and **Manrope** and renamed.

Why: Google Fonts ships ₹ in the large `latin-ext` subset. Because prices appear
on every page, browsers would download ~100 KB of extra font data for one
character. These two files weigh about 1 KB each and are matched first for
U+20B9 (see `unicode-range` in `src/app/layout.tsx`), so the `latin-ext` files
are never requested.

Both source fonts are licensed under the SIL Open Font License 1.1
(https://openfontlicense.org). Inter © The Inter Project Authors; Manrope ©
The Manrope Project Authors. The subsets are distributed under the same licence.
