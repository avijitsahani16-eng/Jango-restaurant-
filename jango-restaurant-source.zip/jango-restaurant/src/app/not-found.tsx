import { ArrowRight, UtensilsCrossed } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";

import { buttonStyles } from "@/components/ui/button";
import { categories } from "@/data/categories";

export const metadata: Metadata = {
  title: "Page not found",
  robots: { index: false, follow: true },
};

export default function NotFound() {
  return (
    <div className="relative isolate overflow-hidden">
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 -top-[4.75rem] -z-10 h-[34rem] bg-gradient-to-b from-brand-100/80 via-cream/60 to-transparent" />
      <div className="container-site flex flex-col items-center py-20 text-center lg:py-28">
        <p aria-hidden="true" className="relative font-display text-[clamp(7rem,5rem+16vw,15rem)] font-extrabold leading-none tracking-[-0.06em] text-ink">
          4
          <span className="relative mx-[0.02em] inline-grid size-[0.72em] translate-y-[0.02em] place-items-center rounded-full bg-brand-500 align-baseline shadow-glow">
            <UtensilsCrossed className="size-[42%] text-ink" strokeWidth={1.75} />
          </span>
          4
        </p>
        <h1 className="text-section mt-4 text-ink">This plate is empty.</h1>
        <p className="text-lead mt-4 max-w-md text-ink-muted">
          The page you were looking for has moved or never existed. The kitchen, thankfully, is exactly where you left it.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3.5">
          <Link href="/menu" data-ripple="" className={buttonStyles({ variant: "primary", size: "lg" })}>
            Browse the menu
            <ArrowRight aria-hidden="true" className="size-5" />
          </Link>
          <Link href="/" data-ripple="" className={buttonStyles({ variant: "outline", size: "lg" })}>
            Back to home
          </Link>
        </div>

        <nav aria-label="Popular categories" className="mt-12">
          <ul className="flex flex-wrap justify-center gap-2">
            {categories.slice(0, 6).map((category) => (
              <li key={category.slug}>
                <Link
                  href={`/menu/${category.slug}`}
                  className="inline-flex h-10 items-center rounded-full bg-white px-4 text-sm font-medium text-ink shadow-soft ring-1 ring-ink/[0.06] transition-colors hover:bg-cream"
                >
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
}
