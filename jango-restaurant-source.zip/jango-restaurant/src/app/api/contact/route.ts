import { BAD_REQUEST, deliver, fail, INVALID, isBot, ok, rateLimited, readJson, TOO_MANY } from "@/lib/server/api";
import { validateContact } from "@/lib/validation";

export async function POST(request: Request) {
  if (rateLimited(request, "contact")) return fail(429, TOO_MANY);

  const body = await readJson(request);
  if (!body) return fail(400, BAD_REQUEST);
  if (isBot(body)) return ok("Message received.");

  const result = validateContact(body);
  if (!result.ok) return fail(422, INVALID, result.errors as Record<string, string>);

  await deliver("contact", result.data);
  return ok("Message received.");
}
