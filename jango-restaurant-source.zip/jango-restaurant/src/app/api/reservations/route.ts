import { BAD_REQUEST, deliver, fail, INVALID, isBot, ok, rateLimited, readJson, TOO_MANY } from "@/lib/server/api";
import { validateReservation } from "@/lib/validation";

export async function POST(request: Request) {
  if (rateLimited(request, "reservations")) return fail(429, TOO_MANY);

  const body = await readJson(request);
  if (!body) return fail(400, BAD_REQUEST);
  if (isBot(body)) return ok("Reservation request received.");

  const result = validateReservation(body);
  if (!result.ok) return fail(422, INVALID, result.errors as Record<string, string>);

  await deliver("reservation", result.data);
  return ok("Reservation request received.");
}
