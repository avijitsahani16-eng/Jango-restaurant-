import { randomInt } from "node:crypto";

import { site } from "@/config/site";
import { calculateTotals, toOrderLines } from "@/lib/cart";
import { BAD_REQUEST, deliver, fail, INVALID, isBot, ok, rateLimited, readJson, TOO_MANY } from "@/lib/server/api";
import { validateOrder } from "@/lib/validation";
import type { Order } from "@/types";

const ID_ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"; // no look-alikes (0/O, 1/I)

function createOrderId(): string {
  let id = "";
  for (let index = 0; index < 6; index += 1) id += ID_ALPHABET[randomInt(ID_ALPHABET.length)];
  return `JG-${id}`;
}

/**
 * Places an order.
 *
 * The browser only sends dish ids and quantities — every price, discount, tax
 * and total is recomputed here from the menu, so the client is never trusted
 * with money. Payment is collected on delivery; plug a gateway in at the
 * marked point to take payment online.
 */
export async function POST(request: Request) {
  if (rateLimited(request, "orders", 5)) return fail(429, TOO_MANY);

  const body = await readJson(request);
  if (!body) return fail(400, BAD_REQUEST);
  if (isBot(body)) return fail(400, BAD_REQUEST);

  const result = validateOrder(body);
  if (!result.ok) return fail(422, result.errors.lines ?? INVALID, result.errors);

  const { lines, couponCode, fulfilment, payment, customer } = result.data;
  const totals = calculateTotals(lines, { couponCode, fulfilment });

  const order: Order = {
    id: createOrderId(),
    placedAt: new Date().toISOString(),
    fulfilment,
    payment,
    customer,
    lines: toOrderLines(lines),
    totals: {
      itemCount: totals.itemCount,
      subtotal: totals.subtotal,
      discount: totals.discount,
      deliveryFee: totals.deliveryFee,
      tax: totals.tax,
      total: totals.total,
    },
    couponCode: totals.appliedCoupon?.code ?? null,
    etaMinutes: fulfilment === "pickup" ? site.delivery.pickupMinutes : site.delivery.averageMinutes,
  };

  // ── Online payments: create the gateway order here (e.g. Razorpay) and return its id. ──

  await deliver("order", order);
  return ok("Order placed.", { order }, 201);
}
