import { BAD_REQUEST, deliver, fail, INVALID, isBot, ok, rateLimited, readJson, TOO_MANY } from "@/lib/server/api";
import { validateNewsletter } from "@/lib/validation";

export async function POST(request: Request) {
  if (rateLimited(request, "newsletter")) return fail(429, TOO_MANY);

  const body = await readJson(request);
  if (!body) return fail(400, BAD_REQUEST);
  if (isBot(body)) return ok("You’re on the list.");

  const result = validateNewsletter(body);
  if (!result.ok) return fail(422, result.errors.email ?? INVALID, result.errors as Record<string, string>);

  await deliver("newsletter", result.data);
  return ok("You’re on the list.");
}
