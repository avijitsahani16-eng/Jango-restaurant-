"use client";

import * as m from "framer-motion/m";
import { useEffect, useState, type ReactNode } from "react";

/* The very first page is server-rendered and must paint immediately (no fade → fast LCP).
   Every later navigation gets a short, smooth entrance. */
let hasNavigated = false;

export default function Template({ children }: { children: ReactNode }) {
  const [animateIn] = useState(() => hasNavigated);

  useEffect(() => {
    hasNavigated = true;
  }, []);

  return (
    <m.div
      initial={animateIn ? { opacity: 0, y: 16 } : false}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </m.div>
  );
}
