"use client";

import { RotateCcw, TriangleAlert } from "lucide-react";
import Link from "next/link";
import { useEffect } from "react";

import { Button, buttonStyles } from "@/components/ui/button";
import { site } from "@/config/site";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="container-site flex flex-col items-center py-24 text-center lg:py-32" role="alert">
      <span className="grid size-20 place-items-center rounded-full bg-cream text-brand-600">
        <TriangleAlert aria-hidden="true" className="size-9" strokeWidth={1.5} />
      </span>
      <h1 className="text-section mt-7 text-ink">Something boiled over.</h1>
      <p className="text-lead mt-4 max-w-md text-ink-muted">
        That was our fault, not yours. Try again — and if it keeps happening, call us on{" "}
        <a href={site.phone.href} className="font-semibold text-ink underline underline-offset-4">
          {site.phone.display}
        </a>{" "}
        and we will take your order over the phone.
      </p>
      <div className="mt-9 flex flex-wrap justify-center gap-3.5">
        <Button size="lg" onClick={reset}>
          <RotateCcw aria-hidden="true" className="size-5" />
          Try again
        </Button>
        <Link href="/" data-ripple="" className={buttonStyles({ variant: "outline", size: "lg" })}>
          Back to home
        </Link>
      </div>
    </div>
  );
}
