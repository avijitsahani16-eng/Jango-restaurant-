import type { MetadataRoute } from "next";

import { getSiteUrl } from "@/config/site";

export default function robots(): MetadataRoute.Robots {
  const base = getSiteUrl();

  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/checkout"] }],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}
