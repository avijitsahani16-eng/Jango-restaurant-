import { ChevronLeft } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";

import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Review your order, add your delivery details and place your order with Jango Restaurant Cum Bar.",
  alternates: { canonical: "/checkout" },
  robots: { index: false, follow: true },
};

export default function CheckoutPage() {
  return (
    <div className="relative">
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 -top-[4.75rem] -z-10 h-[26rem] bg-gradient-to-b from-brand-100/70 via-cream/60 to-transparent" />

      <div className="container-site pb-32 pt-6 lg:pb-28 lg:pt-10">
        <Link href="/menu" className="link-underline inline-flex items-center gap-1 text-sm font-medium text-ink-muted hover:text-ink">
          <ChevronLeft aria-hidden="true" className="size-4" />
          Back to the menu
        </Link>

        <CheckoutFlow />
      </div>
    </div>
  );
}
