import type { Metadata, Viewport } from "next";
import { Inter, Manrope } from "next/font/google";
import localFont from "next/font/local";

import { AnnouncementBar } from "@/components/layout/announcement-bar";
import { Footer } from "@/components/layout/footer";
import { Header } from "@/components/layout/header";
import { MobileOrderBar } from "@/components/layout/mobile-order-bar";
import { GlobalOverlays } from "@/components/overlays/global-overlays";
import { InteractionEffects } from "@/components/providers/interaction-effects";
import { MotionProvider } from "@/components/providers/motion-provider";
import { ScrollEngine } from "@/components/providers/scroll-engine";
import { JsonLd } from "@/components/seo/json-ld";
import { getSiteUrl, site } from "@/config/site";
import { restaurantSchema, websiteSchema } from "@/lib/schema";

import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope", display: "swap" });

/* One-glyph subsets for the rupee sign (₹), matched before the Google fonts so the
   ~100 KB latin-ext files are never downloaded for a single character. See app/fonts/README.md. */
const rupeeSans = localFont({
  src: "./fonts/rupee-sans.woff2",
  variable: "--font-rupee-sans",
  weight: "100 900",
  display: "swap",
  adjustFontFallback: false,
  declarations: [{ prop: "unicode-range", value: "U+20B9" }],
});
const rupeeDisplay = localFont({
  src: "./fonts/rupee-display.woff2",
  variable: "--font-rupee-display",
  weight: "200 800",
  display: "swap",
  adjustFontFallback: false,
  declarations: [{ prop: "unicode-range", value: "U+20B9" }],
});

const title = `${site.name} ${site.descriptor} — Order Food Online in Dhubulia, Nadia`;

export const metadata: Metadata = {
  metadataBase: new URL(getSiteUrl()),
  title: { default: title, template: `%s | ${site.name} ${site.descriptor}` },
  description: site.description,
  applicationName: site.name,
  keywords: [
    "Jango Restaurant Cum Bar",
    "restaurant in Dhubulia",
    "food delivery Dhubulia",
    "restaurant on NH12",
    "restaurant near Krishnanagar",
    "biryani delivery Nadia",
    "tandoori",
    "Indo-Chinese",
    "bar in Dhubulia",
    "book a table Dhubulia",
  ],
  authors: [{ name: site.legalName }],
  creator: site.legalName,
  publisher: site.legalName,
  category: "food",
  formatDetection: { telephone: true, address: true, email: false },
  openGraph: {
    type: "website",
    siteName: `${site.name} ${site.descriptor}`,
    locale: site.locale,
    url: "/",
    title,
    description: site.description,
  },
  twitter: {
    card: "summary_large_image",
    title,
    description: site.description,
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1, "max-video-preview": -1 },
  },
  other: {
    "geo.region": "IN-WB",
    "geo.placename": `${site.address.locality}, ${site.address.region}`,
    "geo.position": `${site.geo.latitude};${site.geo.longitude}`,
    ICBM: `${site.geo.latitude}, ${site.geo.longitude}`,
  },
};

export const viewport: Viewport = {
  themeColor: "#FFFDF9",
  colorScheme: "light",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en-IN" className={`${inter.variable} ${manrope.variable} ${rupeeSans.variable} ${rupeeDisplay.variable}`} suppressHydrationWarning>
      <body className="antialiased">
        {/* Runs before first paint: marks the document as script-capable so scroll reveals can start hidden. */}
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />

        <MotionProvider>
          <a
            href="#main"
            className="fixed left-4 top-4 z-[100] -translate-y-24 rounded-full bg-ink px-5 py-3 text-sm font-medium text-white shadow-lift transition-transform duration-300 focus:translate-y-0"
          >
            Skip to main content
          </a>

          <div id="site" className="flex min-h-dvh flex-col">
            <AnnouncementBar />
            <Header />
            <main id="main" tabIndex={-1} className="flex-1 outline-none">
              {children}
            </main>
            <Footer />
            <MobileOrderBar />
          </div>

          <GlobalOverlays />
          <ScrollEngine />
          <InteractionEffects />
        </MotionProvider>

        <JsonLd data={[restaurantSchema(), websiteSchema()]} />
      </body>
    </html>
  );
}
