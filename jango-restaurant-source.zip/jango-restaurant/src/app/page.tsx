import type { Metadata } from "next";

import { AppPromo } from "@/components/sections/app-promo";
import { BarShowcase } from "@/components/sections/bar-showcase";
import { Categories } from "@/components/sections/categories";
import { Contact } from "@/components/sections/contact";
import { Faq } from "@/components/sections/faq";
import { Gallery } from "@/components/sections/gallery";
import { Hero } from "@/components/sections/hero";
import { HowItWorks } from "@/components/sections/how-it-works";
import { Newsletter } from "@/components/sections/newsletter";
import { PopularDishes } from "@/components/sections/popular-dishes";
import { PromoBanner } from "@/components/sections/promo-banner";
import { Testimonials } from "@/components/sections/testimonials";
import { TrustFeatures } from "@/components/sections/trust-features";
import { WhyChooseUs } from "@/components/sections/why-choose-us";
import { JsonLd } from "@/components/seo/json-ld";
import { faqs } from "@/data/content";
import { faqSchema } from "@/lib/schema";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
};

/**
 * Home — every section in the order set out in STRUCTURE.md § 1.
 * Each section is self-contained and reads from the shared config, data and
 * design tokens; none of them defines its own colours, type or data shapes.
 */
export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustFeatures />
      <Categories />
      <PopularDishes />
      <PromoBanner />
      <WhyChooseUs />
      <HowItWorks />
      <BarShowcase />
      <Testimonials />
      <Gallery />
      <AppPromo />
      <Faq />
      <Newsletter />
      <Contact />
      <JsonLd data={faqSchema(faqs)} />
    </>
  );
}
