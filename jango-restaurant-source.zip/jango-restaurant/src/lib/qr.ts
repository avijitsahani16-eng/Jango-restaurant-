import QRCode from "qrcode";

export interface QrMatrix {
  /** Modules per side. */
  size: number;
  /** SVG path data, one unit per module. */
  path: string;
}

/**
 * Builds a QR code as a single SVG path (horizontal runs are merged),
 * so it can be server-rendered with no client JavaScript and styled freely.
 */
export function createQr(text: string): QrMatrix {
  const { modules } = QRCode.create(text, { errorCorrectionLevel: "M" });
  const { size, data } = modules;
  let path = "";

  for (let y = 0; y < size; y += 1) {
    let x = 0;
    while (x < size) {
      if (!data[y * size + x]) {
        x += 1;
        continue;
      }
      let run = 1;
      while (x + run < size && data[y * size + x + run]) run += 1;
      path += `M${x} ${y}h${run}v1h-${run}z`;
      x += run;
    }
  }

  return { size, path };
}
