import { extendTailwindMerge } from "tailwind-merge";

export type ClassValue = string | number | null | false | undefined | ClassValue[];

/**
 * tailwind-merge, taught about the custom tokens in globals.css so that a
 * later class always wins over an earlier one that sets the same property
 * (`cn(buttonStyles(), "hidden md:inline-flex")` does what it says).
 */
const merge = extendTailwindMerge({
  extend: {
    theme: {
      text: ["hero", "section", "card-title", "lead"],
      shadow: ["soft", "card", "lift", "float", "glow"],
      radius: ["card", "panel", "tile"],
      ease: ["out-expo", "spring"],
      animate: ["float", "float-slow", "drift", "spin-slow", "shimmer", "rise", "pop", "ticker", "pulse-ring"],
    },
  },
});

function flatten(values: ClassValue[], out: string[]): string[] {
  for (const value of values) {
    if (!value) continue;
    if (Array.isArray(value)) flatten(value, out);
    else out.push(String(value));
  }
  return out;
}

/** Joins class names, skips falsy values and resolves Tailwind conflicts (last one wins). */
export function cn(...values: ClassValue[]): string {
  return merge(flatten(values, []).join(" "));
}
