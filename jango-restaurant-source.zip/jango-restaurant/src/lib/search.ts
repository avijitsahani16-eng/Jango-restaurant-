import { getCategory } from "@/data/categories";
import type { Dish } from "@/types";

const normalize = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const DIET_WORDS: Record<string, Dish["diet"]> = {
  veg: "veg",
  vegetarian: "veg",
  "non-veg": "non-veg",
  nonveg: "non-veg",
  "non veg": "non-veg",
};

/**
 * Small, dependency-free menu search.
 * Every word in the query must match somewhere; name matches rank highest.
 */
export function searchDishes(query: string, dishes: readonly Dish[], limit = 8): Dish[] {
  const raw = query.trim().toLowerCase();
  const text = normalize(query);
  if (!text) return [];

  const diet = DIET_WORDS[raw] ?? DIET_WORDS[text];
  if (diet) {
    return dishes
      .filter((dish) => dish.diet === diet)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  const words = text.split(" ");
  const scored: { dish: Dish; score: number }[] = [];

  for (const dish of dishes) {
    const name = normalize(dish.name);
    const category = normalize(getCategory(dish.category)?.name ?? dish.category);
    const description = normalize(dish.description);
    const tags = normalize(dish.tags.join(" "));

    let score = 0;
    let matchedAll = true;

    for (const word of words) {
      let best = 0;
      if (name.startsWith(word)) best = 12;
      else if (name.split(" ").some((part) => part.startsWith(word))) best = 9;
      else if (name.includes(word)) best = 6;
      else if (category.startsWith(word) || category.includes(word)) best = 5;
      else if (tags.includes(word)) best = 4;
      else if (description.includes(word)) best = 2;

      if (best === 0) {
        matchedAll = false;
        break;
      }
      score += best;
    }

    if (!matchedAll) continue;
    if (name === text) score += 20;
    score += dish.rating / 10;
    scored.push({ dish, score });
  }

  return scored
    .sort((a, b) => b.score - a.score || a.dish.name.localeCompare(b.dish.name))
    .slice(0, limit)
    .map((entry) => entry.dish);
}
