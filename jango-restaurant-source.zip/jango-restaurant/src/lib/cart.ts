/**
 * Cart maths — pure functions, no React, no storage.
 *
 * The same code runs in the browser (live totals) and on the server
 * (/api/orders recomputes every total from dish ids, so a tampered client
 * can never change a price).
 */
import { coupons, site } from "@/config/site";
import { dishes as catalogue } from "@/data/dishes";
import type { CartLine, CartTotals, Coupon, Dish, Fulfilment, OrderLine } from "@/types";

export const MAX_QUANTITY = site.maxQuantityPerDish;

const clampQuantity = (quantity: number) => Math.max(0, Math.min(MAX_QUANTITY, Math.trunc(quantity) || 0));

export function addLine(lines: readonly CartLine[], dishId: string, quantity = 1): CartLine[] {
  const existing = lines.find((line) => line.dishId === dishId);
  if (!existing) {
    const next = clampQuantity(quantity);
    return next > 0 ? [...lines, { dishId, quantity: next }] : [...lines];
  }
  return setLineQuantity(lines, dishId, existing.quantity + quantity);
}

export function setLineQuantity(lines: readonly CartLine[], dishId: string, quantity: number): CartLine[] {
  const next = clampQuantity(quantity);
  if (next === 0) return lines.filter((line) => line.dishId !== dishId);
  return lines.map((line) => (line.dishId === dishId ? { ...line, quantity: next } : line));
}

export function removeLine(lines: readonly CartLine[], dishId: string): CartLine[] {
  return lines.filter((line) => line.dishId !== dishId);
}

export function getQuantity(lines: readonly CartLine[], dishId: string): number {
  return lines.find((line) => line.dishId === dishId)?.quantity ?? 0;
}

export function countItems(lines: readonly CartLine[]): number {
  return lines.reduce((sum, line) => sum + line.quantity, 0);
}

/** Drops unknown dishes and invalid quantities (e.g. stale data in localStorage). */
export function sanitizeLines(lines: unknown, menu: readonly Dish[] = catalogue): CartLine[] {
  if (!Array.isArray(lines)) return [];
  const known = new Set(menu.map((dish) => dish.id));
  const merged = new Map<string, number>();
  for (const raw of lines) {
    if (!raw || typeof raw !== "object") continue;
    const { dishId, quantity } = raw as Partial<CartLine>;
    if (typeof dishId !== "string" || !known.has(dishId)) continue;
    const safe = clampQuantity(Number(quantity));
    if (safe > 0) merged.set(dishId, clampQuantity((merged.get(dishId) ?? 0) + safe));
  }
  return Array.from(merged, ([dishId, quantity]) => ({ dishId, quantity }));
}

export function normalizeCouponCode(code: string | null | undefined): string {
  return (code ?? "").trim().toUpperCase();
}

export function findCoupon(code: string | null | undefined, available: readonly Coupon[] = coupons): Coupon | null {
  const normalized = normalizeCouponCode(code);
  if (!normalized) return null;
  return available.find((coupon) => coupon.code === normalized) ?? null;
}

export function couponDiscount(coupon: Coupon, subtotal: number): number {
  if (subtotal < coupon.minSubtotal) return 0;
  const raw = coupon.kind === "percent" ? Math.round((subtotal * coupon.value) / 100) : coupon.value;
  const capped = coupon.maxDiscount !== undefined ? Math.min(raw, coupon.maxDiscount) : raw;
  return Math.max(0, Math.min(capped, subtotal));
}

export interface TotalsOptions {
  couponCode?: string | null;
  fulfilment?: Fulfilment;
  menu?: readonly Dish[];
  available?: readonly Coupon[];
}

export function calculateTotals(lines: readonly CartLine[], options: TotalsOptions = {}): CartTotals {
  const { couponCode = null, fulfilment = "delivery", menu = catalogue, available = coupons } = options;
  const prices = new Map(menu.map((dish) => [dish.id, dish.price]));

  let subtotal = 0;
  let itemCount = 0;
  for (const line of lines) {
    const price = prices.get(line.dishId);
    if (price === undefined) continue;
    subtotal += price * line.quantity;
    itemCount += line.quantity;
  }

  let appliedCoupon: Coupon | null = null;
  let couponError: string | null = null;
  let discount = 0;

  const requested = normalizeCouponCode(couponCode);
  if (requested) {
    const coupon = findCoupon(requested, available);
    if (!coupon) {
      couponError = "That code isn’t valid.";
    } else if (subtotal < coupon.minSubtotal) {
      couponError = `Add ₹${coupon.minSubtotal - subtotal} more to use ${coupon.code}.`;
    } else {
      appliedCoupon = coupon;
      discount = couponDiscount(coupon, subtotal);
    }
  }

  const { freeThreshold, fee } = site.delivery;
  const qualifiesForFreeDelivery = subtotal >= freeThreshold;
  const deliveryFee = itemCount === 0 || fulfilment === "pickup" || qualifiesForFreeDelivery ? 0 : fee;
  const taxable = subtotal - discount;
  const tax = Math.round(taxable * site.taxRate);
  const total = taxable + tax + deliveryFee;

  return {
    itemCount,
    subtotal,
    discount,
    deliveryFee,
    tax,
    total,
    freeDeliveryRemaining: Math.max(0, freeThreshold - subtotal),
    freeDeliveryProgress: Math.max(0, Math.min(1, subtotal / freeThreshold)),
    appliedCoupon,
    couponError,
  };
}

/** Snapshot of the cart with names and prices frozen, for receipts. */
export function toOrderLines(lines: readonly CartLine[], menu: readonly Dish[] = catalogue): OrderLine[] {
  const byId = new Map(menu.map((dish) => [dish.id, dish]));
  return lines.flatMap((line) => {
    const dish = byId.get(line.dishId);
    return dish ? [{ dishId: dish.id, name: dish.name, unitPrice: dish.price, quantity: line.quantity }] : [];
  });
}
