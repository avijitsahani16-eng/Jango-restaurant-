/**
 * A ~60-line external store.
 *
 * State lives outside React, components subscribe with `useSyncExternalStore`
 * (see hooks/use-store.ts). Persisted stores read localStorage lazily on the
 * client; the server and the hydration pass always see the initial state, so
 * there is never a hydration mismatch.
 */

type Listener = () => void;

export interface Store<T> {
  getState(): T;
  /** State used on the server and during hydration. */
  getInitialState(): T;
  setState(next: T | ((previous: T) => T)): void;
  subscribe(listener: Listener): () => void;
}

export function createStore<T>(initial: T): Store<T> {
  let state = initial;
  const listeners = new Set<Listener>();

  return {
    getState: () => state,
    getInitialState: () => initial,
    setState(next) {
      const value = typeof next === "function" ? (next as (previous: T) => T)(state) : next;
      if (Object.is(value, state)) return;
      state = value;
      listeners.forEach((listener) => listener());
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };
}

export interface PersistOptions<T> {
  /** localStorage key. Bump the suffix when the shape changes. */
  key: string;
  /** Turns whatever was found in storage into a valid state (or throws). */
  parse: (raw: unknown) => T;
}

export function createPersistedStore<T>(initial: T, { key, parse }: PersistOptions<T>): Store<T> {
  const base = createStore(initial);
  const isBrowser = typeof window !== "undefined";
  let hydrated = false;

  const read = (): T => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw === null ? initial : parse(JSON.parse(raw));
    } catch {
      return initial;
    }
  };

  const hydrate = () => {
    if (hydrated || !isBrowser) return;
    hydrated = true;
    base.setState(read());
    // Keep several tabs in sync.
    window.addEventListener("storage", (event) => {
      if (event.key === key || event.key === null) base.setState(read());
    });
  };

  return {
    getInitialState: base.getInitialState,
    getState() {
      hydrate();
      return base.getState();
    },
    setState(next) {
      hydrate();
      base.setState(next);
      if (!isBrowser) return;
      try {
        window.localStorage.setItem(key, JSON.stringify(base.getState()));
      } catch {
        /* storage full or blocked — the in-memory state still works */
      }
    },
    subscribe(listener) {
      hydrate();
      return base.subscribe(listener);
    },
  };
}
