/**
 * Form validation — shared by the client forms (instant feedback) and the API
 * routes (the server never trusts the browser).
 */
import { site } from "@/config/site";
import { getDish } from "@/data/dishes";
import type {
  CartLine,
  ContactInput,
  CustomerDetails,
  FieldErrors,
  Fulfilment,
  NewsletterInput,
  OrderInput,
  PaymentMethod,
  ReservationInput,
  ValidationResult,
} from "@/types";

import { MAX_QUANTITY } from "./cart";
import { reservationSlots, zonedDateString } from "./hours";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const CONTACT_TOPICS = ["General enquiry", "Party or group booking", "Catering", "Feedback"] as const;
export const OCCASIONS = ["Just dinner", "Birthday", "Anniversary", "Family get-together", "Business meal"] as const;
export const MAX_GUESTS = 20;
export const MAX_ADVANCE_DAYS = 60;

export function clean(value: unknown, maxLength = 500): string {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, maxLength) : "";
}

export function cleanMultiline(value: unknown, maxLength = 1500): string {
  return typeof value === "string"
    ? value
        .replace(/\r\n?/g, "\n")
        .replace(/[ \t]+/g, " ")
        .replace(/\n{3,}/g, "\n\n")
        .trim()
        .slice(0, maxLength)
    : "";
}

export function isEmail(value: string): boolean {
  return value.length <= 254 && EMAIL_PATTERN.test(value);
}

/** Returns the 10-digit Indian mobile number, or null if it is not one. */
export function normalizePhone(value: string): string | null {
  let digits = value.replace(/\D/g, "");
  if (digits.length === 12 && digits.startsWith("91")) digits = digits.slice(2);
  else if (digits.length === 11 && digits.startsWith("0")) digits = digits.slice(1);
  return /^[6-9]\d{9}$/.test(digits) ? digits : null;
}

function nameError(name: string): string | undefined {
  if (!name) return "Please tell us your name.";
  if (name.length < 2) return "That name looks a little short.";
  return undefined;
}

function phoneError(phone: string): string | undefined {
  if (!phone) return "We need a phone number to reach you.";
  if (!normalizePhone(phone)) return "Enter a valid 10-digit mobile number.";
  return undefined;
}

function finish<T>(data: T, errors: FieldErrors<T>): ValidationResult<T> {
  for (const key of Object.keys(errors) as (keyof T)[]) {
    if (errors[key] === undefined) delete errors[key];
  }
  return Object.keys(errors).length > 0 ? { ok: false, errors } : { ok: true, data };
}

/* ── Newsletter ──────────────────────────────────────────────────────────── */
export function validateNewsletter(input: Record<string, unknown>): ValidationResult<NewsletterInput> {
  const email = clean(input.email, 254).toLowerCase();
  const errors: FieldErrors<NewsletterInput> = {};
  if (!email) errors.email = "Enter your email address.";
  else if (!isEmail(email)) errors.email = "That email doesn’t look right.";
  return finish({ email }, errors);
}

/* ── Contact ─────────────────────────────────────────────────────────────── */
export function validateContact(input: Record<string, unknown>): ValidationResult<ContactInput> {
  const data: ContactInput = {
    name: clean(input.name, 80),
    phone: clean(input.phone, 20),
    email: clean(input.email, 254).toLowerCase(),
    topic: clean(input.topic, 60),
    message: cleanMultiline(input.message, 1500),
  };
  const errors: FieldErrors<ContactInput> = {
    name: nameError(data.name),
    phone: phoneError(data.phone),
  };
  if (data.email && !isEmail(data.email)) errors.email = "That email doesn’t look right.";
  if (!(CONTACT_TOPICS as readonly string[]).includes(data.topic)) errors.topic = "Choose a topic.";
  if (!data.message) errors.message = "Write a short message so we can help.";
  else if (data.message.length < 10) errors.message = "Please add a little more detail.";
  if (!errors.phone) data.phone = normalizePhone(data.phone) ?? data.phone;
  return finish(data, errors);
}

/* ── Reservation ─────────────────────────────────────────────────────────── */
export function validateReservation(input: Record<string, unknown>, now: Date = new Date()): ValidationResult<ReservationInput> {
  const data: ReservationInput = {
    name: clean(input.name, 80),
    phone: clean(input.phone, 20),
    date: clean(input.date, 10),
    time: clean(input.time, 5),
    guests: Math.trunc(Number(input.guests)),
    occasion: clean(input.occasion, 60) || OCCASIONS[0],
    notes: cleanMultiline(input.notes, 500),
  };
  const errors: FieldErrors<ReservationInput> = {
    name: nameError(data.name),
    phone: phoneError(data.phone),
  };

  const today = zonedDateString(now);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data.date) || Number.isNaN(Date.parse(`${data.date}T00:00:00Z`))) {
    errors.date = "Pick a date.";
  } else if (data.date < today) {
    errors.date = "That date has already passed.";
  } else {
    const days = Math.round((Date.parse(`${data.date}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86_400_000);
    if (days > MAX_ADVANCE_DAYS) errors.date = `We take bookings up to ${MAX_ADVANCE_DAYS} days ahead.`;
  }

  if (!reservationSlots().includes(data.time)) errors.time = "Choose a time slot.";

  if (!Number.isFinite(data.guests) || data.guests < 1) errors.guests = "How many guests?";
  else if (data.guests > MAX_GUESTS) errors.guests = `For more than ${MAX_GUESTS} guests, please call ${site.phone.display}.`;

  if (!(OCCASIONS as readonly string[]).includes(data.occasion)) errors.occasion = "Choose an occasion.";
  if (!errors.phone) data.phone = normalizePhone(data.phone) ?? data.phone;
  return finish(data, errors);
}

/* ── Checkout ────────────────────────────────────────────────────────────── */
export type CustomerErrors = FieldErrors<CustomerDetails>;

export function validateCustomer(
  input: Record<string, unknown>,
  fulfilment: Fulfilment,
): { data: CustomerDetails; errors: CustomerErrors } {
  const data: CustomerDetails = {
    name: clean(input.name, 80),
    phone: clean(input.phone, 20),
    email: clean(input.email, 254).toLowerCase(),
    address: cleanMultiline(input.address, 300),
    landmark: clean(input.landmark, 120),
    notes: cleanMultiline(input.notes, 300),
  };
  const errors: CustomerErrors = {};
  const nameIssue = nameError(data.name);
  const phoneIssue = phoneError(data.phone);
  if (nameIssue) errors.name = nameIssue;
  if (phoneIssue) errors.phone = phoneIssue;
  else data.phone = normalizePhone(data.phone) ?? data.phone;
  if (data.email && !isEmail(data.email)) errors.email = "That email doesn’t look right.";
  if (fulfilment === "delivery") {
    if (!data.address) errors.address = "Where should we deliver?";
    else if (data.address.length < 10) errors.address = "Add house number, street and area.";
  }
  return { data, errors };
}

const FULFILMENTS: readonly Fulfilment[] = ["delivery", "pickup"];
const PAYMENTS: readonly PaymentMethod[] = ["upi", "card", "cash"];

export function validateOrder(
  input: Record<string, unknown>,
): { ok: true; data: OrderInput } | { ok: false; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  const fulfilment = FULFILMENTS.includes(input.fulfilment as Fulfilment) ? (input.fulfilment as Fulfilment) : null;
  if (!fulfilment) errors.fulfilment = "Choose delivery or pickup.";

  const payment = PAYMENTS.includes(input.payment as PaymentMethod) ? (input.payment as PaymentMethod) : null;
  if (!payment) errors.payment = "Choose a payment method.";

  const lines: CartLine[] = [];
  if (Array.isArray(input.lines)) {
    for (const raw of input.lines.slice(0, 60)) {
      if (!raw || typeof raw !== "object") continue;
      const { dishId, quantity } = raw as Partial<CartLine>;
      const qty = Math.trunc(Number(quantity));
      if (typeof dishId === "string" && getDish(dishId) && qty >= 1 && qty <= MAX_QUANTITY) {
        if (!lines.some((line) => line.dishId === dishId)) lines.push({ dishId, quantity: qty });
      }
    }
  }
  if (lines.length === 0) errors.lines = "Your cart is empty.";

  const customerInput = input.customer && typeof input.customer === "object" ? (input.customer as Record<string, unknown>) : {};
  const customer = validateCustomer(customerInput, fulfilment ?? "delivery");
  for (const [field, message] of Object.entries(customer.errors)) {
    if (message) errors[field] = message;
  }

  if (Object.keys(errors).length > 0 || !fulfilment || !payment) return { ok: false, errors };

  return {
    ok: true,
    data: {
      lines,
      couponCode: clean(input.couponCode, 24).toUpperCase() || null,
      fulfilment,
      payment,
      customer: customer.data,
    },
  };
}
