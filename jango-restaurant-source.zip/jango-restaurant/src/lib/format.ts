/**
 * Formatting helpers.
 *
 * Deliberately hand-rolled instead of `Intl`: the output is byte-identical on
 * the server and in every browser, so prices can never cause a hydration
 * mismatch.
 */

/** Groups digits the Indian way: 1,23,45,678. */
export function groupIndian(value: number): string {
  const negative = value < 0;
  const digits = Math.abs(Math.trunc(value)).toString();
  if (digits.length <= 3) return (negative ? "-" : "") + digits;
  const lastThree = digits.slice(-3);
  const rest = digits.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${rest},${lastThree}`;
}

/** ₹1,299 — whole rupees, no decimals. */
export function formatINR(amount: number): string {
  const rounded = Math.round(amount);
  return `${rounded < 0 ? "-" : ""}₹${groupIndian(Math.abs(rounded))}`;
}

/** "1 item" / "3 items" */
export function pluralize(count: number, singular: string, plural = `${singular}s`): string {
  return `${count} ${count === 1 ? singular : plural}`;
}

/** "23:00" → "11 PM", "11:30" → "11:30 AM" */
export function formatClock(time: string): string {
  const [h, m] = time.split(":").map(Number);
  const suffix = h >= 12 ? "PM" : "AM";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return m ? `${hour12}:${String(m).padStart(2, "0")} ${suffix}` : `${hour12} ${suffix}`;
}

/** 4.7 → "4.7", 5 → "5.0" */
export function formatRating(rating: number): string {
  return rating.toFixed(1);
}

/** 1200 → "1.2k", 380 → "380" */
export function formatCompact(value: number): string {
  if (value < 1000) return String(value);
  const thousands = value / 1000;
  return `${thousands >= 10 ? Math.round(thousands) : Math.round(thousands * 10) / 10}k`;
}

/** Turns arbitrary text into initials: "Ananya Roy" → "AR". */
export function initials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}
