/**
 * Scroll helpers shared by the whole app.
 *
 * The Lenis instance is registered here by <ScrollEngine />, so any module can
 * scroll smoothly or lock the page without threading a React context through.
 */
import type Lenis from "lenis";

let lenis: Lenis | null = null;
let locks = 0;

export function registerLenis(instance: Lenis | null) {
  lenis = instance;
  if (instance && locks > 0) instance.stop();
}

export function prefersReducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function headerOffset(): number {
  const header = document.querySelector<HTMLElement>("[data-site-header]");
  return (header?.offsetHeight ?? 76) + 16;
}

/** Smoothly scrolls to an element, a selector such as "#offers", or a pixel position. */
export function scrollToTarget(target: string | HTMLElement | number, options: { immediate?: boolean } = {}) {
  if (typeof window === "undefined") return;
  const immediate = options.immediate ?? prefersReducedMotion();

  if (typeof target === "number") {
    if (lenis) lenis.scrollTo(target, { immediate });
    else window.scrollTo({ top: target, behavior: immediate ? "auto" : "smooth" });
    return;
  }

  let element: HTMLElement | null = null;
  if (typeof target === "string") {
    try {
      element = document.querySelector<HTMLElement>(target);
    } catch {
      element = null;
    }
  } else {
    element = target;
  }
  if (!element) return;

  const offset = -headerOffset();
  if (lenis) {
    lenis.scrollTo(element, { offset, immediate, duration: 1.15 });
  } else {
    const top = element.getBoundingClientRect().top + window.scrollY + offset;
    window.scrollTo({ top, behavior: immediate ? "auto" : "smooth" });
  }
}

/**
 * Locks page scroll while an overlay is open. Reference-counted, compensates
 * for the scrollbar so nothing shifts, and makes the page behind inert so
 * keyboard and screen-reader focus stay inside the overlay.
 */
export function lockScroll() {
  locks += 1;
  if (locks > 1) return;
  const root = document.documentElement;
  const scrollbar = window.innerWidth - root.clientWidth;
  root.style.setProperty("--scrollbar-comp", `${Math.max(0, scrollbar)}px`);
  root.classList.add("scroll-locked");
  lenis?.stop();
  document.getElementById("site")?.setAttribute("inert", "");
}

export function unlockScroll() {
  locks = Math.max(0, locks - 1);
  if (locks > 0) return;
  const root = document.documentElement;
  root.classList.remove("scroll-locked");
  root.style.removeProperty("--scrollbar-comp");
  lenis?.start();
  document.getElementById("site")?.removeAttribute("inert");
}
