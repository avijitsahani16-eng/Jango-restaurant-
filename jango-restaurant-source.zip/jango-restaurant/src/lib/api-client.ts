export type ApiResult<T> =
  | { ok: true; message: string; data: T }
  | { ok: false; message: string; errors?: Record<string, string> };

const NETWORK_ERROR = "We couldn’t reach the kitchen. Check your connection and try again.";

/** POSTs JSON to one of our API routes and always resolves to a typed result. */
export async function postJson<T = undefined>(url: string, body: unknown, timeoutMs = 12_000): Promise<ApiResult<T>> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const payload = (await response.json().catch(() => null)) as
      | { ok?: boolean; message?: string; data?: T; errors?: Record<string, string> }
      | null;

    if (response.ok && payload?.ok) {
      return { ok: true, message: payload.message ?? "Done.", data: payload.data as T };
    }
    return {
      ok: false,
      message: payload?.message ?? (response.status === 429 ? "Too many attempts. Please wait a minute and try again." : NETWORK_ERROR),
      errors: payload?.errors,
    };
  } catch {
    return { ok: false, message: NETWORK_ERROR };
  } finally {
    clearTimeout(timer);
  }
}
