import type { Order } from "@/types";

export interface OrderStage {
  key: "confirmed" | "preparing" | "on-the-way" | "delivered" | "ready";
  label: string;
  description: string;
  /** Minutes after the order was placed at which this stage is expected to begin. */
  startsAt: number;
}

export interface OrderProgress {
  stages: OrderStage[];
  /** Index of the stage the order is expected to be in right now. */
  current: number;
  minutesLeft: number;
  done: boolean;
}

/**
 * Estimated progress of an order, derived from the time it was placed and the
 * promised ETA. Replace with real kitchen / rider status when a backend exists.
 */
export function getOrderProgress(order: Pick<Order, "placedAt" | "etaMinutes" | "fulfilment">, now: Date): OrderProgress {
  const eta = Math.max(5, order.etaMinutes);
  const pickup = order.fulfilment === "pickup";

  const stages: OrderStage[] = pickup
    ? [
        { key: "confirmed", label: "Order confirmed", description: "The kitchen has your order.", startsAt: 0 },
        { key: "preparing", label: "Being prepared", description: "Our chefs are cooking it fresh.", startsAt: Math.min(3, eta * 0.15) },
        { key: "ready", label: "Ready for pickup", description: "Hot and packed at the counter.", startsAt: eta },
      ]
    : [
        { key: "confirmed", label: "Order confirmed", description: "The kitchen has your order.", startsAt: 0 },
        { key: "preparing", label: "Being prepared", description: "Our chefs are cooking it fresh.", startsAt: Math.min(3, eta * 0.1) },
        { key: "on-the-way", label: "Out for delivery", description: "Your rider is on the way.", startsAt: eta * 0.55 },
        { key: "delivered", label: "Delivered", description: "Enjoy your meal!", startsAt: eta },
      ];

  const placed = Date.parse(order.placedAt);
  const elapsed = Number.isNaN(placed) ? 0 : Math.max(0, (now.getTime() - placed) / 60_000);

  let current = 0;
  stages.forEach((stage, index) => {
    if (elapsed >= stage.startsAt) current = index;
  });

  return {
    stages,
    current,
    minutesLeft: Math.max(0, Math.ceil(eta - elapsed)),
    done: current === stages.length - 1,
  };
}
