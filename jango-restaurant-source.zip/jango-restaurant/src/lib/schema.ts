/**
 * Structured data (schema.org JSON-LD) builders.
 *
 * Note: there is deliberately no `aggregateRating`. Google's guidelines do not
 * allow marking up ratings collected on another platform (our 4.7 comes from
 * Google Maps), so it is shown to people on the page but not asserted here.
 */
import { getSiteUrl, site } from "@/config/site";
import { categories } from "@/data/categories";
import { dishes } from "@/data/dishes";
import type { Category, Dish, Faq } from "@/types";

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export function restaurantSchema() {
  const url = getSiteUrl();
  return {
    "@context": "https://schema.org",
    "@type": ["Restaurant", "BarOrPub"],
    "@id": `${url}/#restaurant`,
    name: site.legalName,
    alternateName: site.name,
    description: site.description,
    url,
    telephone: site.phone.e164,
    image: [`${url}/opengraph-image.jpg`],
    logo: `${url}/icon.svg`,
    priceRange: site.priceRange,
    servesCuisine: site.cuisines,
    currenciesAccepted: site.currency,
    paymentAccepted: "Cash, UPI, Credit Card, Debit Card",
    acceptsReservations: true,
    hasMap: site.maps.listingUrl,
    sameAs: [site.maps.listingUrl],
    menu: `${url}/menu`,
    address: {
      "@type": "PostalAddress",
      streetAddress: site.address.street,
      addressLocality: site.address.locality,
      addressRegion: site.address.region,
      postalCode: site.address.postalCode,
      addressCountry: site.address.country,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: site.geo.latitude,
      longitude: site.geo.longitude,
    },
    openingHoursSpecification: site.hours.map((entry) => ({
      "@type": "OpeningHoursSpecification",
      dayOfWeek: `https://schema.org/${DAY_NAMES[entry.day]}`,
      opens: entry.open,
      closes: entry.close,
    })),
    potentialAction: [
      {
        "@type": "OrderAction",
        target: { "@type": "EntryPoint", urlTemplate: `${url}/menu`, actionPlatform: ["https://schema.org/DesktopWebPlatform", "https://schema.org/MobileWebPlatform"] },
        deliveryMethod: ["http://purl.org/goodrelations/v1#DeliveryModeOwnFleet", "http://purl.org/goodrelations/v1#DeliveryModePickUp"],
      },
      {
        "@type": "ReserveAction",
        target: { "@type": "EntryPoint", urlTemplate: `${url}/#contact` },
        result: { "@type": "FoodEstablishmentReservation", name: "Reserve a table" },
      },
    ],
  };
}

export function websiteSchema() {
  const url = getSiteUrl();
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${url}/#website`,
    url,
    name: `${site.name} ${site.descriptor}`,
    inLanguage: "en-IN",
    publisher: { "@id": `${url}/#restaurant` },
  };
}

export function faqSchema(items: readonly Faq[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer },
    })),
  };
}

function menuItem(dish: Dish) {
  const url = getSiteUrl();
  return {
    "@type": "MenuItem",
    name: dish.name,
    description: dish.description,
    ...(dish.image ? { image: `${url}${dish.image.src}` } : {}),
    ...(dish.diet === "veg" ? { suitableForDiet: "https://schema.org/VegetarianDiet" } : {}),
    nutrition: { "@type": "NutritionInformation", calories: `${dish.calories} calories` },
    offers: { "@type": "Offer", price: dish.price, priceCurrency: site.currency, availability: "https://schema.org/InStock" },
  };
}

/** The menu, or a single section of it when `only` is given. */
export function menuSchema(only?: Category) {
  const url = getSiteUrl();
  const sections = (only ? [only] : categories).map((category) => ({
    "@type": "MenuSection",
    name: category.name,
    description: category.description,
    hasMenuItem: dishes.filter((dish) => dish.category === category.slug).map(menuItem),
  }));

  return {
    "@context": "https://schema.org",
    "@type": "Menu",
    "@id": `${url}/menu#menu`,
    name: `${site.name} menu`,
    url: `${url}/menu`,
    inLanguage: "en-IN",
    hasMenuSection: sections,
  };
}

export function breadcrumbSchema(trail: { name: string; path: string }[]) {
  const url = getSiteUrl();
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: trail.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: `${url}${item.path}`,
    })),
  };
}
