/**
 * Shared plumbing for the API routes: JSON parsing, responses, a small rate
 * limiter, bot detection and delivery of submissions.
 *
 * Where submissions go
 * ────────────────────
 * Set FORM_WEBHOOK_URL and every contact message, reservation, newsletter
 * sign-up and order is POSTed there as JSON (Slack, Zapier, Make, a Google
 * Apps Script, your own backend …). Without it, submissions are written to the
 * server log so nothing is lost while the real destination is being decided.
 */
import "server-only";

import { NextResponse } from "next/server";

const MAX_BODY_BYTES = 16 * 1024;

export type SubmissionKind = "contact" | "newsletter" | "reservation" | "order";

export function ok<T extends object>(message: string, data?: T, status = 200) {
  return NextResponse.json({ ok: true, message, ...(data ? { data } : {}) }, { status, headers: { "Cache-Control": "no-store" } });
}

export function fail(status: number, message: string, errors?: Record<string, string>) {
  return NextResponse.json({ ok: false, message, ...(errors ? { errors } : {}) }, { status, headers: { "Cache-Control": "no-store" } });
}

/** Parses a JSON object body. Returns `null` for anything malformed or oversized. */
export async function readJson(request: Request): Promise<Record<string, unknown> | null> {
  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) return null;
  try {
    const text = await request.text();
    if (text.length > MAX_BODY_BYTES) return null;
    const value: unknown = JSON.parse(text);
    return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** The hidden "company" field is only ever filled in by bots. */
export function isBot(body: Record<string, unknown>): boolean {
  return typeof body.company === "string" && body.company.trim().length > 0;
}

/* ── Rate limiting ───────────────────────────────────────────────────────────
   In-memory sliding window, per client and per route. Good enough to stop a
   stuck form or a casual script; put a shared store (Upstash, Redis) behind it
   if you run more than one server instance. */
const hits = new Map<string, number[]>();

function clientKey(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  return forwarded || request.headers.get("x-real-ip") || "local";
}

/** RATE_LIMIT_MAX overrides the per-minute allowance (the end-to-end tests raise it). */
const LIMIT_OVERRIDE = Number(process.env.RATE_LIMIT_MAX) || 0;

export function rateLimited(request: Request, bucket: string, limit = 6, windowMs = 60_000): boolean {
  if (LIMIT_OVERRIDE > 0) limit = LIMIT_OVERRIDE;
  const now = Date.now();
  const key = `${bucket}:${clientKey(request)}`;
  const recent = (hits.get(key) ?? []).filter((time) => now - time < windowMs);
  recent.push(now);
  hits.set(key, recent);

  if (hits.size > 5_000) {
    for (const [entry, times] of hits) {
      if (times.every((time) => now - time >= windowMs)) hits.delete(entry);
    }
  }
  return recent.length > limit;
}

/** Hands a validated submission to its destination. Never throws. */
export async function deliver(kind: SubmissionKind, payload: object): Promise<void> {
  const record = { kind, receivedAt: new Date().toISOString(), ...payload };
  const webhook = process.env.FORM_WEBHOOK_URL;

  if (!webhook) {
    console.info(`[jango] ${kind} submission`, JSON.stringify(record));
    return;
  }

  try {
    const response = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(record),
      signal: AbortSignal.timeout(6_000),
    });
    if (!response.ok) console.error(`[jango] webhook responded ${response.status} for ${kind}`);
  } catch (error) {
    console.error(`[jango] webhook failed for ${kind}`, error);
  }
}

export const TOO_MANY = "Too many attempts. Please wait a minute and try again.";
export const BAD_REQUEST = "We couldn’t read that request. Please try again.";
export const INVALID = "Please check the highlighted fields.";
