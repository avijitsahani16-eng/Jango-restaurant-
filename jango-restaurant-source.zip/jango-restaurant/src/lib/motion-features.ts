/**
 * Framer Motion's animation, gesture and layout features.
 * Imported lazily by <MotionProvider /> so they stay out of the first bundle.
 */
export { domMax as default } from "framer-motion";
