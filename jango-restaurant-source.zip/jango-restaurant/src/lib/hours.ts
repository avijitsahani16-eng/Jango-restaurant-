/**
 * Opening hours, evaluated in the restaurant's own time zone
 * (so a visitor in another zone still sees the right status).
 */
import { site } from "@/config/site";

import { formatClock } from "./format";

export interface DayHours {
  day: number;
  label: string;
  open: string;
  close: string;
}

export interface OpenStatus {
  isOpen: boolean;
  /** "Open now" / "Closed" */
  label: string;
  /** "Closes 11 PM" / "Opens 11 AM" / "Opens tomorrow, 11 AM" */
  detail: string;
  /** 0 (Sunday) … 6 (Saturday), in the restaurant's time zone. */
  today: number;
}

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const toMinutes = (time: string) => {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + (m || 0);
};

/** Weekday + minutes since midnight for `date` in `timeZone`. */
export function zonedClock(date: Date, timeZone: string): { day: number; minutes: number } {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const get = (type: string) => parts.find((part) => part.type === type)?.value ?? "";
  const day = Math.max(0, WEEKDAYS.indexOf(get("weekday")));
  const minutes = (Number(get("hour")) % 24) * 60 + Number(get("minute"));
  return { day, minutes };
}

export function getOpenStatus(
  date: Date,
  hours: readonly DayHours[] = site.hours,
  timeZone: string = site.timeZone,
): OpenStatus {
  const { day, minutes } = zonedClock(date, timeZone);
  const today = hours.find((entry) => entry.day === day);

  if (today && minutes >= toMinutes(today.open) && minutes < toMinutes(today.close)) {
    return { isOpen: true, label: "Open now", detail: `Closes ${formatClock(today.close)}`, today: day };
  }

  if (today && minutes < toMinutes(today.open)) {
    return { isOpen: false, label: "Closed", detail: `Opens ${formatClock(today.open)}`, today: day };
  }

  for (let offset = 1; offset <= 7; offset += 1) {
    const next = hours.find((entry) => entry.day === (day + offset) % 7);
    if (next) {
      const when = offset === 1 ? "tomorrow" : next.label;
      return { isOpen: false, label: "Closed", detail: `Opens ${when}, ${formatClock(next.open)}`, today: day };
    }
  }

  return { isOpen: false, label: "Closed", detail: "", today: day };
}

/** "YYYY-MM-DD" for `date` in the restaurant's time zone. */
export function zonedDateString(date: Date, timeZone: string = site.timeZone): string {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
  const get = (type: string) => parts.find((part) => part.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

/** Bookable slots between opening and one hour before closing, every 30 minutes. */
export function reservationSlots(hours: DayHours = site.hours[0]): string[] {
  const slots: string[] = [];
  for (let t = toMinutes(hours.open) + 30; t <= toMinutes(hours.close) - 60; t += 30) {
    slots.push(`${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`);
  }
  return slots;
}
