/**
 * Shared data shapes.
 *
 * Every screen speaks this vocabulary — a dish on the home page, in search,
 * in the cart and in an order is always the same `Dish`. See STRUCTURE.md.
 */
import type { StaticImageData } from "next/image";

import type { IconName } from "@/components/ui/icon";

/* ----------------------------------------------------------------------------
 * Catalogue
 * ------------------------------------------------------------------------- */

export type CategorySlug =
  | "indian"
  | "chinese"
  | "asian"
  | "pizza"
  | "burgers"
  | "pasta"
  | "sushi"
  | "desserts"
  | "drinks"
  | "healthy";

export interface Category {
  slug: CategorySlug;
  name: string;
  /** Short line shown on cards, e.g. "Tandoor, curries & biryani". */
  tagline: string;
  /** One or two sentences used on the category page and in meta descriptions. */
  description: string;
  icon: IconName;
  /** Optional photograph. Cards fall back to the icon tile until one is supplied. */
  image?: StaticImageData;
  imageAlt?: string;
}

export type Diet = "veg" | "non-veg";

/** 0 = not spicy … 3 = hot */
export type SpiceLevel = 0 | 1 | 2 | 3;

export type DishTag = "bestseller" | "chef-special" | "new" | "spicy";

export interface Dish {
  /** URL-safe, stable identifier. Cart lines and orders reference this. */
  id: string;
  name: string;
  category: CategorySlug;
  /** One line for cards (≈ 80 characters). */
  description: string;
  /** A fuller paragraph for the quick view. */
  details: string;
  /** Price in whole rupees. */
  price: number;
  /** Optional "was" price, in whole rupees. */
  compareAtPrice?: number;
  rating: number;
  ratingCount: number;
  diet: Diet;
  spice: SpiceLevel;
  prepMinutes: number;
  serves: string;
  calories: number;
  tags: DishTag[];
  /** Optional photograph. Dishes without one render as menu rows. */
  image?: StaticImageData;
  imageAlt?: string;
  /** Position in the "Popular dishes" grid (1-based). Omit to exclude. */
  popularRank?: number;
}

export interface Cocktail {
  id: string;
  name: string;
  notes: string;
  /** Price in whole rupees. */
  price: number;
  icon: IconName;
  image?: StaticImageData;
  imageAlt?: string;
}

/* ----------------------------------------------------------------------------
 * Cart, coupons & orders
 * ------------------------------------------------------------------------- */

export interface CartLine {
  dishId: string;
  quantity: number;
}

export interface CartState {
  lines: CartLine[];
  couponCode: string | null;
}

export type Fulfilment = "delivery" | "pickup";

export type CouponKind = "percent" | "flat";

export interface Coupon {
  code: string;
  title: string;
  description: string;
  kind: CouponKind;
  /** Percent (0-100) or flat rupees, depending on `kind`. */
  value: number;
  /** Minimum item subtotal, in rupees. */
  minSubtotal: number;
  /** Upper bound for percentage coupons, in rupees. */
  maxDiscount?: number;
}

export interface CartTotals {
  itemCount: number;
  subtotal: number;
  discount: number;
  deliveryFee: number;
  tax: number;
  total: number;
  /** Rupees still needed to unlock free delivery (0 once unlocked). */
  freeDeliveryRemaining: number;
  /** Progress towards free delivery, 0 → 1. */
  freeDeliveryProgress: number;
  /** The coupon that was actually applied, if any. */
  appliedCoupon: Coupon | null;
  /** Why a requested coupon could not be applied. */
  couponError: string | null;
}

export type PaymentMethod = "upi" | "card" | "cash";

export interface CustomerDetails {
  name: string;
  phone: string;
  email?: string;
  address?: string;
  landmark?: string;
  notes?: string;
}

export interface OrderLine {
  dishId: string;
  name: string;
  unitPrice: number;
  quantity: number;
}

export interface Order {
  id: string;
  /** ISO 8601 timestamp. */
  placedAt: string;
  fulfilment: Fulfilment;
  payment: PaymentMethod;
  customer: CustomerDetails;
  lines: OrderLine[];
  totals: Pick<CartTotals, "itemCount" | "subtotal" | "discount" | "deliveryFee" | "tax" | "total">;
  couponCode: string | null;
  etaMinutes: number;
}

export interface Profile {
  name: string;
  phone: string;
  email: string;
  address: string;
  landmark: string;
}

/* ----------------------------------------------------------------------------
 * Marketing content
 * ------------------------------------------------------------------------- */

export interface Feature {
  icon: IconName;
  title: string;
  description: string;
}

export interface Step {
  icon: IconName;
  title: string;
  description: string;
}

export interface Testimonial {
  id: string;
  name: string;
  /** Where they are from / how they order, e.g. "Krishnanagar · Regular". */
  context: string;
  rating: number;
  quote: string;
  /** What they ordered, shown as a small chip. */
  ordered: string;
  avatar?: StaticImageData;
}

export interface Faq {
  id: string;
  question: string;
  answer: string;
}

export interface GalleryImage {
  id: string;
  src: StaticImageData;
  alt: string;
  caption: string;
}

/* ----------------------------------------------------------------------------
 * Forms
 * ------------------------------------------------------------------------- */

export type FieldErrors<T> = Partial<Record<keyof T, string>>;

export type ValidationResult<T> = { ok: true; data: T } | { ok: false; errors: FieldErrors<T> };

export interface ContactInput {
  name: string;
  phone: string;
  email: string;
  topic: string;
  message: string;
}

export interface NewsletterInput {
  email: string;
}

export interface ReservationInput {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  occasion: string;
  notes: string;
}

export interface OrderInput {
  lines: CartLine[];
  couponCode: string | null;
  fulfilment: Fulfilment;
  payment: PaymentMethod;
  customer: CustomerDetails;
}

export type ApiResponse<T = undefined> =
  | ({ ok: true; message: string } & (T extends undefined ? object : { data: T }))
  | { ok: false; message: string; errors?: Record<string, string> };
