/**
 * Marketing content for the home page.
 *
 * SAMPLE CONTENT — testimonials, FAQs, cocktail list and feature copy are
 * illustrative. Replace with the restaurant's own words and real, permissioned
 * customer reviews before launch.
 */
import ananya from "@/assets/images/avatars/ananya.jpg";
import galleryBiryaniSlate from "@/assets/images/gallery/biryani-slate.jpg";
import galleryButterChicken from "@/assets/images/gallery/butter-chicken.jpg";
import galleryChickenBiryani from "@/assets/images/gallery/chicken-biryani.jpg";
import galleryMuttonKosha from "@/assets/images/gallery/mutton-kosha.jpg";
import galleryPaneerTikka from "@/assets/images/gallery/paneer-tikka.jpg";
import galleryPizzaPull from "@/assets/images/gallery/pizza-pull.jpg";
import feast from "@/assets/images/lifestyle/feast.jpg";
import freshIngredients from "@/assets/images/lifestyle/fresh-ingredients.jpg";
import { site } from "@/config/site";
import type { Cocktail, Faq, Feature, GalleryImage, Step, Testimonial } from "@/types";

const { delivery, phone } = site;

/* ── Trust features (below the hero) ─────────────────────────────────────── */
export const trustFeatures: readonly Feature[] = [
  {
    icon: "bike",
    title: "Fast Delivery",
    description: `Hot food at your door in about ${delivery.averageMinutes} minutes.`,
  },
  {
    icon: "leaf",
    title: "Fresh Ingredients",
    description: "Vegetables, meat and dairy bought fresh every morning.",
  },
  {
    icon: "award",
    title: "Premium Quality",
    description: "Recipes perfected by our chefs and cooked to order.",
  },
  {
    icon: "badge-rupee",
    title: "Affordable Pricing",
    description: "Generous portions at honest, everyday prices.",
  },
  {
    icon: "map-pinned",
    title: "Live Order Tracking",
    description: "Follow your order from our kitchen to your gate.",
  },
  {
    icon: "shield-check",
    title: "Secure Payment",
    description: "Pay by UPI, card or cash when your order arrives.",
  },
  {
    icon: "headset",
    title: "Customer Support",
    description: "Real people on the phone, 11 AM to 11 PM, every day.",
  },
  {
    icon: "ticket-percent",
    title: "Daily Offers",
    description: "Fresh deals and coupon codes, every single week.",
  },
];

/* ── Why choose us ───────────────────────────────────────────────────────── */
export const kitchenPromises: readonly Feature[] = [
  {
    icon: "sprout",
    title: "Fresh ingredients",
    description: "Produce, meat and dairy arrive every morning — nothing waits in a freezer for its turn.",
  },
  {
    icon: "chef-hat",
    title: "Experienced chefs",
    description: "Dedicated hands on the tandoor, the wok and the oven, so every cuisine gets a specialist.",
  },
  {
    icon: "sparkles",
    title: "Hygienic kitchen",
    description: "Daily deep-cleans, separate veg and non-veg prep, and sealed storage from start to finish.",
  },
];

export const servicePromises: readonly Feature[] = [
  {
    icon: "bike",
    title: "Fast delivery",
    description: `Your order leaves the pass the moment it is plated and reaches you in about ${delivery.averageMinutes} minutes.`,
  },
  {
    icon: "package-check",
    title: "Premium packaging",
    description: "Spill-proof, heat-holding boxes that keep gravies hot and crispy things crisp.",
  },
  {
    icon: "heart-handshake",
    title: "Customer satisfaction",
    description: "Something not right? Call us and we will fix it — no forms, no fuss.",
  },
];

export const whyImages = {
  kitchen: {
    src: freshIngredients,
    alt: "Fresh basil, vine tomatoes, red chilli, lime, coriander and star anise beside a bowl of butter chicken",
  },
  service: {
    src: feast,
    alt: "Butter chicken, margherita pizza and chicken biryani laid out for sharing, seen from above",
  },
} as const;

/* ── How it works ────────────────────────────────────────────────────────── */
export const steps: readonly Step[] = [
  {
    icon: "utensils",
    title: "Browse Menu",
    description: "Explore ten cuisines and jump straight to what you are craving.",
  },
  {
    icon: "shopping-bag",
    title: "Choose Food",
    description: "Add your favourites to the cart and set the quantities.",
  },
  {
    icon: "lock-keyhole",
    title: "Secure Checkout",
    description: "Confirm your address and pick UPI, card or cash.",
  },
  {
    icon: "bike",
    title: "Fast Delivery",
    description: `Sit back — we will be at your door in about ${delivery.averageMinutes} minutes.`,
  },
];

/* ── The bar (dine-in only) ──────────────────────────────────────────────── */
export const cocktails: readonly Cocktail[] = [
  {
    id: "gondhoraj-gin-fizz",
    name: "Gondhoraj Gin Fizz",
    notes: "Gin, fragrant gondhoraj lime, mint and soda.",
    price: 349,
    icon: "citrus",
  },
  {
    id: "smoked-old-fashioned",
    name: "Smoked Old Fashioned",
    notes: "Whisky, bitters and orange peel under a veil of oak smoke.",
    price: 399,
    icon: "flame",
  },
  {
    id: "highway-sunset",
    name: "Highway Sunset",
    notes: "Tequila, orange and pomegranate, layered like a 6 PM sky over NH12.",
    price: 379,
    icon: "martini",
  },
  {
    id: "jango-mule",
    name: "Jango Mule",
    notes: "Vodka, ginger, lime and a hit of green chilli, ice-cold in copper.",
    price: 349,
    icon: "glass-water",
  },
];

/* ── Testimonials (SAMPLE) ───────────────────────────────────────────────── */
export const testimonials: readonly Testimonial[] = [
  {
    id: "ananya",
    name: "Ananya Roy",
    context: "Krishnanagar",
    rating: 5,
    quote:
      "We order the biryani almost every Sunday. It arrives hot, the potato is perfect and the portions are generous. Easily the most reliable kitchen on this side of NH12.",
    ordered: "Kolkata-Style Chicken Biryani",
    avatar: ananya,
  },
  {
    id: "sourav",
    name: "Sourav Mondal",
    context: "Dhubulia",
    rating: 5,
    quote:
      "Ordered for six on a match night — everything reached in under half an hour and the chilli chicken was still crisp. The live tracking saved a lot of ‘where is it?’ phone calls.",
    ordered: "Dry Chilli Chicken",
  },
  {
    id: "priyanka",
    name: "Priyanka Dutta",
    context: "Bethuadahari",
    rating: 5,
    quote:
      "The butter chicken tastes like someone actually took their time over it. Smoky, creamy and not overly sweet. The packaging was spotless — not a single leak.",
    ordered: "Smoky Butter Chicken",
  },
  {
    id: "arjun",
    name: "Arjun Mukherjee",
    context: "Mayapur",
    rating: 4,
    quote:
      "Booked a table for my parents’ anniversary. Warm service, the paneer tikka was a hit, and the team plated the dessert with a little message. Thoughtful touch.",
    ordered: "Tandoori Paneer Tikka",
  },
  {
    id: "tanisha",
    name: "Tanisha Biswas",
    context: "Krishnanagar",
    rating: 5,
    quote:
      "Finally a place nearby that does a proper pizza and a good mojito. Friendly team, quick delivery — it has quietly become our Friday habit.",
    ordered: "Tandoori Chicken Pizza",
  },
  {
    id: "imran",
    name: "Imran Sheikh",
    context: "Plassey",
    rating: 5,
    quote:
      "Stopped on the highway for lunch and stayed two hours. Mutton kosha with luchi is the real deal. I have started planning my drives around it.",
    ordered: "Slow-Cooked Mutton Kosha",
  },
];

/* ── FAQ (SAMPLE policies) ───────────────────────────────────────────────── */
export const faqs: readonly Faq[] = [
  {
    id: "delivery-area",
    question: "Where do you deliver, and how long does it take?",
    answer: `We deliver across ${delivery.area}. Most orders arrive in about ${delivery.averageMinutes} minutes. During peak hours or heavy rain it can take a little longer — if it does, we will call to let you know.`,
  },
  {
    id: "delivery-fee",
    question: "Is there a minimum order or a delivery charge?",
    answer: `There is no minimum order. Delivery is free on orders over ₹${delivery.freeThreshold}; below that we add a flat ₹${delivery.fee} delivery fee. Pickup from the restaurant is always free.`,
  },
  {
    id: "payments",
    question: "Which payment methods do you accept?",
    answer:
      "You can pay by UPI, debit or credit card, or cash when your order arrives. The same options are available at your table when you dine in.",
  },
  {
    id: "veg-spice",
    question: "Do you have vegetarian options? Can you adjust the spice?",
    answer:
      "Yes. Every dish is clearly marked veg or non-veg, and vegetarian food is prepared separately. Add your spice preference in the order notes and our chefs will adjust it for you.",
  },
  {
    id: "reservations",
    question: "Can I book a table or a party?",
    answer: `Absolutely. Use the Reserve a table button to request a slot, or call us on ${phone.display}. For birthdays and groups of ten or more, please call a day ahead so we can set things up.`,
  },
  {
    id: "alcohol",
    question: "Do you deliver alcohol?",
    answer: `No. Cocktails, beer and spirits are served only in-house at the bar, to guests aged ${site.legalDrinkingAge} and above. Every drink on our delivery menu is zero-proof.`,
  },
  {
    id: "tracking",
    question: "How do I track my order?",
    answer:
      "Once your order is placed you will see its status — confirmed, being prepared, out for delivery — on the confirmation screen and under your account. Our rider also calls when they are close.",
  },
  {
    id: "issues",
    question: "What if something is wrong with my order?",
    answer: `Call us straight away on ${phone.display}. If we have made a mistake, we will replace the dish or refund it — whichever you prefer.`,
  },
];

/* ── Gallery ─────────────────────────────────────────────────────────────── */
export const gallery: readonly GalleryImage[] = [
  {
    id: "butter-chicken",
    src: galleryButterChicken,
    alt: "A bowl of smoky butter chicken with a swirl of cream beside a piece of garlic naan",
    caption: "Smoky butter chicken, garlic naan",
  },
  {
    id: "pizza-pull",
    src: galleryPizzaPull,
    alt: "A tandoori chicken pizza on a wooden board with a slice being pulled away",
    caption: "Tandoori chicken pizza, straight from the oven",
  },
  {
    id: "fresh-ingredients",
    src: freshIngredients,
    alt: "Vine tomatoes, basil, red chilli, lime, coriander and star anise on a cream surface",
    caption: "Fresh produce, every morning",
  },
  {
    id: "biryani-slate",
    src: galleryBiryaniSlate,
    alt: "Chicken biryani in a dark bowl on black slate, surrounded by star anise, chilli, coriander and lime",
    caption: "Biryani night",
  },
  {
    id: "chicken-biryani",
    src: galleryChickenBiryani,
    alt: "Kolkata-style chicken biryani with a boiled egg, potato and a bowl of raita",
    caption: "Kolkata-style chicken biryani",
  },
  {
    id: "mutton-kosha",
    src: galleryMuttonKosha,
    alt: "Dark, slow-cooked mutton kosha in a bowl with puffed luchi behind it",
    caption: "Mutton kosha with luchi",
  },
  {
    id: "paneer-tikka",
    src: galleryPaneerTikka,
    alt: "Charred paneer tikka skewers with mint chutney, onion rings and lemon",
    caption: "Paneer tikka off the tandoor",
  },
  {
    id: "feast",
    src: feast,
    alt: "Butter chicken, margherita pizza and biryani arranged on a table, seen from above",
    caption: "A table made for sharing",
  },
];
