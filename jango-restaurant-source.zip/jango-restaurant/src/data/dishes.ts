/**
 * The menu.
 *
 * SAMPLE CONTENT — dish names, prices, ratings and nutrition are illustrative.
 * Replace them with the restaurant's real menu before launch.
 *
 * To give a dish a photograph, drop the file in src/assets/images/dishes,
 * import it below and set `image` + `imageAlt`. Dishes with a photo render as
 * cards; dishes without one render as classic menu rows.
 */
import butterChicken from "@/assets/images/dishes/butter-chicken.jpg";
import chickenBiryani from "@/assets/images/dishes/chicken-biryani.jpg";
import margheritaPizza from "@/assets/images/dishes/margherita-pizza.jpg";
import muttonKosha from "@/assets/images/dishes/mutton-kosha.jpg";
import paneerTikka from "@/assets/images/dishes/paneer-tikka.jpg";
import tandooriChickenPizza from "@/assets/images/dishes/tandoori-chicken-pizza.jpg";
import type { CategorySlug, Dish } from "@/types";

import { categories } from "./categories";

export const dishes: readonly Dish[] = [
  /* ── Indian ─────────────────────────────────────────────────────────── */
  {
    id: "smoky-butter-chicken",
    name: "Smoky Butter Chicken",
    category: "indian",
    description: "Tandoor-charred chicken in a velvety tomato-butter gravy, finished with cream.",
    details:
      "Chicken thigh is marinated overnight, charred in the tandoor and simmered in a slow-cooked tomato, butter and kasuri methi gravy. Best with garlic naan or steamed rice.",
    price: 329,
    compareAtPrice: 379,
    rating: 4.9,
    ratingCount: 412,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 25,
    serves: "Serves 1–2",
    calories: 540,
    tags: ["bestseller"],
    image: butterChicken,
    imageAlt: "Smoky butter chicken in a dark bowl with a swirl of cream, coriander and a piece of naan",
    popularRank: 1,
  },
  {
    id: "kolkata-chicken-biryani",
    name: "Kolkata-Style Chicken Biryani",
    category: "indian",
    description: "Fragrant long-grain rice layered with tender chicken, a golden potato and egg.",
    details:
      "Light on heat, big on aroma — cooked dum-style with saffron, rose water and our house biryani masala. Comes with the potato Kolkata insists on, a boiled egg and a bowl of raita.",
    price: 279,
    rating: 4.8,
    ratingCount: 538,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 30,
    serves: "Serves 1",
    calories: 720,
    tags: ["bestseller"],
    image: chickenBiryani,
    imageAlt: "Kolkata-style chicken biryani with a chicken leg, potato and boiled egg, served with raita",
    popularRank: 2,
  },
  {
    id: "tandoori-paneer-tikka",
    name: "Tandoori Paneer Tikka",
    category: "indian",
    description: "Charred cubes of malai paneer with peppers, onion and mint chutney.",
    details:
      "Soft paneer in a hung-curd and Kashmiri chilli marinade, skewered with capsicum and onion and roasted until the edges blister. Six pieces, served with mint chutney and onion rings.",
    price: 249,
    rating: 4.7,
    ratingCount: 263,
    diet: "veg",
    spice: 2,
    prepMinutes: 20,
    serves: "6 pieces",
    calories: 410,
    tags: ["chef-special"],
    image: paneerTikka,
    imageAlt: "Skewers of charred tandoori paneer tikka with mint chutney, lemon and onion rings",
    popularRank: 3,
  },
  {
    id: "mutton-kosha",
    name: "Slow-Cooked Mutton Kosha",
    category: "indian",
    description: "Bengal's Sunday classic — mutton braised for hours with caramelised onion and spices.",
    details:
      "Braised on a low flame until the gravy turns dark and clings to the meat. Rich, deeply spiced and best mopped up with luchi or plain rice.",
    price: 389,
    rating: 4.8,
    ratingCount: 197,
    diet: "non-veg",
    spice: 2,
    prepMinutes: 30,
    serves: "Serves 1–2",
    calories: 610,
    tags: ["chef-special"],
    image: muttonKosha,
    imageAlt: "Dark, glossy mutton kosha in a bowl with two puffed luchi on the side",
    popularRank: 4,
  },

  /* ── Chinese ────────────────────────────────────────────────────────── */
  {
    id: "chicken-hakka-noodles",
    name: "Chicken Hakka Noodles",
    category: "chinese",
    description: "Wok-tossed noodles with shredded chicken, crunchy vegetables and soy.",
    details:
      "Thin noodles tossed over a high flame with chicken, cabbage, carrot, capsicum and spring onion. Smoky, light and never greasy.",
    price: 189,
    rating: 4.7,
    ratingCount: 486,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 15,
    serves: "Serves 1",
    calories: 520,
    tags: ["bestseller"],
  },
  {
    id: "dry-chilli-chicken",
    name: "Dry Chilli Chicken",
    category: "chinese",
    description: "Crispy chicken tossed with peppers, onion and green chillies in a soy-chilli glaze.",
    details:
      "Double-fried chicken bites wok-tossed with capsicum, onion petals and slit green chillies. The starter every table orders twice.",
    price: 229,
    rating: 4.8,
    ratingCount: 371,
    diet: "non-veg",
    spice: 3,
    prepMinutes: 18,
    serves: "Serves 1–2",
    calories: 460,
    tags: ["spicy"],
  },
  {
    id: "honey-chilli-potato",
    name: "Crispy Honey Chilli Potato",
    category: "chinese",
    description: "Golden potato fingers in a sticky sweet-heat glaze with sesame.",
    details:
      "Twice-fried potato fingers tossed in honey, chilli and garlic, finished with toasted sesame and spring onion. Stays crunchy all the way home.",
    price: 169,
    rating: 4.6,
    ratingCount: 224,
    diet: "veg",
    spice: 2,
    prepMinutes: 15,
    serves: "Serves 1–2",
    calories: 430,
    tags: [],
  },

  /* ── Asian ──────────────────────────────────────────────────────────── */
  {
    id: "steamed-chicken-momos",
    name: "Steamed Chicken Momos",
    category: "asian",
    description: "Eight juicy, hand-pleated dumplings with a fiery tomato-chilli chutney.",
    details:
      "Minced chicken, ginger and spring onion wrapped in thin dough and steamed to order. Served with our roasted tomato and red chilli chutney.",
    price: 149,
    rating: 4.8,
    ratingCount: 455,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 15,
    serves: "8 pieces",
    calories: 320,
    tags: ["bestseller"],
  },
  {
    id: "thai-green-curry",
    name: "Thai Green Curry Bowl",
    category: "asian",
    description: "Coconut green curry with tofu and vegetables, served with jasmine rice.",
    details:
      "House-ground green curry paste simmered in coconut milk with tofu, baby corn, beans and Thai basil. Comes with a portion of steamed jasmine rice.",
    price: 299,
    rating: 4.6,
    ratingCount: 142,
    diet: "veg",
    spice: 2,
    prepMinutes: 22,
    serves: "Serves 1",
    calories: 560,
    tags: ["new"],
  },

  /* ── Pizza ──────────────────────────────────────────────────────────── */
  {
    id: "tandoori-chicken-pizza",
    name: "Tandoori Chicken Pizza",
    category: "pizza",
    description: "Chicken tikka, roasted peppers, onion and mozzarella on a hand-stretched base.",
    details:
      "Our tandoor meets the pizza oven: smoky chicken tikka, roasted peppers and red onion over slow-cooked tomato sauce and stretchy mozzarella. Nine inches, six slices.",
    price: 349,
    rating: 4.8,
    ratingCount: 318,
    diet: "non-veg",
    spice: 2,
    prepMinutes: 20,
    serves: "9-inch · Serves 1–2",
    calories: 820,
    tags: ["bestseller"],
    image: tandooriChickenPizza,
    imageAlt: "Tandoori chicken pizza on a wooden board with one slice pulled away and stretchy cheese",
    popularRank: 5,
  },
  {
    id: "classic-margherita",
    name: "Classic Margherita",
    category: "pizza",
    description: "Blistered crust, slow-cooked tomato sauce, mozzarella and fresh basil.",
    details:
      "The one that proves the dough: hand-stretched, sauced with slow-cooked tomatoes and finished with mozzarella and whole basil leaves. Nine inches, six slices.",
    price: 249,
    rating: 4.7,
    ratingCount: 289,
    diet: "veg",
    spice: 0,
    prepMinutes: 18,
    serves: "9-inch · Serves 1–2",
    calories: 680,
    tags: [],
    image: margheritaPizza,
    imageAlt: "Margherita pizza with melted mozzarella and basil leaves on a dark slate, seen from above",
    popularRank: 6,
  },

  /* ── Burgers ────────────────────────────────────────────────────────── */
  {
    id: "crispy-chicken-burger",
    name: "Jango Crispy Chicken Burger",
    category: "burgers",
    description: "Crunchy chicken fillet, cheese, lettuce and house sauce in a toasted brioche bun.",
    details:
      "A buttermilk-brined chicken fillet fried until craggy and golden, stacked with cheese, pickles, lettuce and our smoky house sauce.",
    price: 199,
    rating: 4.7,
    ratingCount: 342,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 15,
    serves: "Serves 1",
    calories: 590,
    tags: ["bestseller"],
  },
  {
    id: "smoky-paneer-burger",
    name: "Smoky Paneer Burger",
    category: "burgers",
    description: "Grilled paneer steak, mint mayo, onion rings and lettuce in a sesame bun.",
    details:
      "A thick slab of tandoori-spiced paneer grilled until charred at the edges, layered with mint mayo, crisp onion rings and lettuce.",
    price: 179,
    rating: 4.5,
    ratingCount: 128,
    diet: "veg",
    spice: 1,
    prepMinutes: 15,
    serves: "Serves 1",
    calories: 540,
    tags: [],
  },

  /* ── Pasta ──────────────────────────────────────────────────────────── */
  {
    id: "creamy-chicken-alfredo",
    name: "Creamy Chicken Alfredo",
    category: "pasta",
    description: "Fettuccine in a parmesan cream sauce with grilled chicken and cracked pepper.",
    details:
      "Ribbons of fettuccine folded through a garlic and parmesan cream sauce, topped with sliced grilled chicken and plenty of black pepper.",
    price: 269,
    rating: 4.6,
    ratingCount: 176,
    diet: "non-veg",
    spice: 0,
    prepMinutes: 18,
    serves: "Serves 1",
    calories: 690,
    tags: [],
  },
  {
    id: "penne-arrabbiata",
    name: "Penne Arrabbiata",
    category: "pasta",
    description: "Penne in a garlicky, chilli-kissed tomato sauce with basil and parmesan.",
    details:
      "A bright, properly spicy tomato sauce with garlic and red chilli, tossed with penne and finished with basil and parmesan.",
    price: 229,
    rating: 4.5,
    ratingCount: 119,
    diet: "veg",
    spice: 2,
    prepMinutes: 16,
    serves: "Serves 1",
    calories: 560,
    tags: [],
  },

  /* ── Sushi ──────────────────────────────────────────────────────────── */
  {
    id: "prawn-tempura-roll",
    name: "Crispy Prawn Tempura Roll",
    category: "sushi",
    description: "Eight pieces with tempura prawn, cucumber and spicy mayo.",
    details:
      "Crisp tempura prawn and cucumber rolled in seasoned rice, topped with spicy mayo and toasted sesame. Served with soy, wasabi and pickled ginger.",
    price: 349,
    rating: 4.6,
    ratingCount: 94,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 20,
    serves: "8 pieces",
    calories: 420,
    tags: ["new"],
  },
  {
    id: "avocado-cucumber-roll",
    name: "Avocado Cucumber Roll",
    category: "sushi",
    description: "Eight sesame-crusted vegetarian rolls with avocado, cucumber and carrot.",
    details:
      "Creamy avocado, crunchy cucumber and carrot in seasoned rice with a toasted sesame crust. Served with soy, wasabi and pickled ginger.",
    price: 279,
    rating: 4.5,
    ratingCount: 71,
    diet: "veg",
    spice: 0,
    prepMinutes: 18,
    serves: "8 pieces",
    calories: 340,
    tags: [],
  },

  /* ── Desserts ───────────────────────────────────────────────────────── */
  {
    id: "molten-lava-cake",
    name: "Molten Chocolate Lava Cake",
    category: "desserts",
    description: "Warm dark chocolate cake with a flowing centre and vanilla ice cream.",
    details:
      "Baked to order so the centre stays molten. Packed with the ice cream on the side so it reaches you exactly as it should.",
    price: 159,
    rating: 4.9,
    ratingCount: 301,
    diet: "veg",
    spice: 0,
    prepMinutes: 14,
    serves: "Serves 1",
    calories: 450,
    tags: ["bestseller"],
  },
  {
    id: "nolen-gur-cheesecake",
    name: "Nolen Gur Cheesecake",
    category: "desserts",
    description: "Baked cheesecake glazed with Bengal's winter date-palm jaggery.",
    details:
      "A dense baked cheesecake on a biscuit base, finished with a smoky-sweet nolen gur caramel. Bengal on a dessert plate.",
    price: 189,
    rating: 4.8,
    ratingCount: 163,
    diet: "veg",
    spice: 0,
    prepMinutes: 5,
    serves: "1 slice",
    calories: 410,
    tags: ["chef-special"],
  },
  {
    id: "warm-gulab-jamun",
    name: "Warm Gulab Jamun",
    category: "desserts",
    description: "Soft, syrup-soaked dumplings with pistachio and saffron.",
    details:
      "Three khoya dumplings fried slowly and soaked in cardamom syrup, served warm with pistachio slivers and saffron.",
    price: 99,
    rating: 4.7,
    ratingCount: 254,
    diet: "veg",
    spice: 0,
    prepMinutes: 5,
    serves: "3 pieces",
    calories: 300,
    tags: [],
  },

  /* ── Drinks (zero-proof, delivered) ─────────────────────────────────── */
  {
    id: "alphonso-mango-lassi",
    name: "Alphonso Mango Lassi",
    category: "drinks",
    description: "Thick, chilled yoghurt blended with Alphonso mango pulp and saffron.",
    details:
      "Fresh-set yoghurt churned with Alphonso mango pulp, a pinch of cardamom and saffron. Sealed cold for the ride.",
    price: 99,
    rating: 4.8,
    ratingCount: 233,
    diet: "veg",
    spice: 0,
    prepMinutes: 5,
    serves: "300 ml",
    calories: 240,
    tags: [],
  },
  {
    id: "gondhoraj-virgin-mojito",
    name: "Gondhoraj Virgin Mojito",
    category: "drinks",
    description: "Fragrant gondhoraj lime, mint and soda over crushed ice. Zero alcohol.",
    details:
      "Bengal's most aromatic lime muddled with mint and a touch of sugar, topped with soda. Zero-proof and very refreshing.",
    price: 119,
    rating: 4.7,
    ratingCount: 187,
    diet: "veg",
    spice: 0,
    prepMinutes: 5,
    serves: "300 ml",
    calories: 110,
    tags: ["new"],
  },

  /* ── Healthy meals ──────────────────────────────────────────────────── */
  {
    id: "grilled-chicken-bowl",
    name: "Grilled Chicken Protein Bowl",
    category: "healthy",
    description: "Chargrilled chicken, brown rice, chickpeas, greens and a yoghurt-herb dressing.",
    details:
      "Lean chargrilled chicken over brown rice with chickpeas, cucumber, tomato, sweet corn and greens. Dressing packed separately.",
    price: 279,
    rating: 4.6,
    ratingCount: 138,
    diet: "non-veg",
    spice: 1,
    prepMinutes: 18,
    serves: "Serves 1",
    calories: 480,
    tags: [],
  },
  {
    id: "rainbow-buddha-bowl",
    name: "Rainbow Buddha Bowl",
    category: "healthy",
    description: "Quinoa, roasted sweet potato, crunchy vegetables, hummus and sesame.",
    details:
      "Quinoa with roasted sweet potato, purple cabbage, carrot, edamame and a generous spoon of hummus, finished with toasted sesame.",
    price: 249,
    rating: 4.5,
    ratingCount: 92,
    diet: "veg",
    spice: 0,
    prepMinutes: 15,
    serves: "Serves 1",
    calories: 430,
    tags: [],
  },
];

/* ----------------------------------------------------------------------------
 * Selectors — every screen reads the menu through these.
 * ------------------------------------------------------------------------- */

const byId = new Map<string, Dish>(dishes.map((dish) => [dish.id, dish]));

export function getDish(id: string): Dish | undefined {
  return byId.get(id);
}

export function getDishesByCategory(slug: CategorySlug): Dish[] {
  return dishes.filter((dish) => dish.category === slug);
}

/** Dishes for the "Popular dishes" grid, in rank order. Only dishes with a photo qualify. */
export const popularDishes: readonly Dish[] = dishes
  .filter((dish) => dish.popularRank !== undefined && dish.image !== undefined)
  .sort((a, b) => (a.popularRank ?? 0) - (b.popularRank ?? 0));

/** Number of dishes in each category — always in sync with the menu. */
export const categoryCounts: Readonly<Record<CategorySlug, number>> = categories.reduce(
  (counts, category) => {
    counts[category.slug] = dishes.filter((dish) => dish.category === category.slug).length;
    return counts;
  },
  {} as Record<CategorySlug, number>,
);

export const totalDishes = dishes.length;
