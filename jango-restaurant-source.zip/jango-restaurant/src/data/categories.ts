import type { Category, CategorySlug } from "@/types";

/**
 * Menu categories, in display order.
 *
 * `image` is optional: add `image` + `imageAlt` to a category and its card
 * switches from the icon tile to a full-bleed photograph automatically.
 */
export const categories: readonly Category[] = [
  {
    slug: "indian",
    name: "Indian",
    tagline: "Tandoor, curries & biryani",
    description:
      "Smoky tandoori, slow-cooked curries and Kolkata-style biryani, cooked the way Bengal likes them.",
    icon: "cooking-pot",
  },
  {
    slug: "chinese",
    name: "Chinese",
    tagline: "Wok-tossed favourites",
    description:
      "Indo-Chinese classics tossed on a roaring wok — noodles, chilli chicken and crispy starters.",
    icon: "soup",
  },
  {
    slug: "asian",
    name: "Asian",
    tagline: "Momos, curries & bowls",
    description: "Hand-pleated momos and fragrant coconut curries from across Asia.",
    icon: "shrimp",
  },
  {
    slug: "pizza",
    name: "Pizza",
    tagline: "Hand-stretched & blistered",
    description:
      "Hand-stretched bases, slow-cooked tomato sauce and generous toppings, baked until the crust blisters.",
    icon: "pizza",
  },
  {
    slug: "burgers",
    name: "Burgers",
    tagline: "Stacked & saucy",
    description: "Toasted buns, crunchy fillings and house sauces — built to be eaten with both hands.",
    icon: "hamburger",
  },
  {
    slug: "pasta",
    name: "Pasta",
    tagline: "Creamy or fiery",
    description: "Comforting bowls of pasta, from silky Alfredo to a chilli-kissed arrabbiata.",
    icon: "wheat",
  },
  {
    slug: "sushi",
    name: "Sushi",
    tagline: "Rolled to order",
    description: "Fresh rolls made to order, with vegetarian and tempura options.",
    icon: "fish",
  },
  {
    slug: "desserts",
    name: "Desserts",
    tagline: "Sweet endings",
    description: "Warm, gooey and worth saving room for — including a Bengal-inspired cheesecake.",
    icon: "cake-slice",
  },
  {
    slug: "drinks",
    name: "Drinks",
    tagline: "Lassis, coolers & mocktails",
    description:
      "Zero-proof coolers, lassis and mocktails that travel well. Cocktails are served in-house at the bar.",
    icon: "cup-soda",
  },
  {
    slug: "healthy",
    name: "Healthy Meals",
    tagline: "Light, bright bowls",
    description: "Balanced bowls with lean protein, whole grains and plenty of crunch.",
    icon: "salad",
  },
];

const bySlug = new Map<string, Category>(categories.map((category) => [category.slug, category]));

export function getCategory(slug: string): Category | undefined {
  return bySlug.get(slug);
}

export function isCategorySlug(value: string): value is CategorySlug {
  return bySlug.has(value);
}
