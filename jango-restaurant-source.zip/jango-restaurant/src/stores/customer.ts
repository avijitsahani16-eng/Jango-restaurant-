/**
 * Things remembered on this device: favourites, delivery details, recent orders.
 * Swap these for a real account backend (e.g. Supabase Auth) when one exists.
 */
import { getDish } from "@/data/dishes";
import { createPersistedStore } from "@/lib/store";
import type { Order, Profile } from "@/types";

/* ── Favourites ──────────────────────────────────────────────────────────── */
export const favoritesStore = createPersistedStore<readonly string[]>([], {
  key: "jango.favorites.v1",
  parse(raw) {
    if (!Array.isArray(raw)) return [];
    return Array.from(new Set(raw.filter((id): id is string => typeof id === "string" && Boolean(getDish(id)))));
  },
});

/** Returns `true` when the dish is now a favourite. */
export function toggleFavorite(dishId: string): boolean {
  const has = favoritesStore.getState().includes(dishId);
  favoritesStore.setState((ids) => (has ? ids.filter((id) => id !== dishId) : [...ids, dishId]));
  return !has;
}

/* ── Profile ─────────────────────────────────────────────────────────────── */
export const EMPTY_PROFILE: Profile = { name: "", phone: "", email: "", address: "", landmark: "" };

const text = (value: unknown, max: number) => (typeof value === "string" ? value.slice(0, max) : "");

export const profileStore = createPersistedStore<Profile>(EMPTY_PROFILE, {
  key: "jango.profile.v1",
  parse(raw) {
    const value = (raw ?? {}) as Partial<Profile>;
    return {
      name: text(value.name, 80),
      phone: text(value.phone, 20),
      email: text(value.email, 254),
      address: text(value.address, 300),
      landmark: text(value.landmark, 120),
    };
  },
});

export function saveProfile(patch: Partial<Profile>) {
  profileStore.setState((profile) => ({ ...profile, ...patch }));
}

/* ── Recent orders ───────────────────────────────────────────────────────── */
const MAX_ORDERS = 10;

function isOrder(value: unknown): value is Order {
  if (!value || typeof value !== "object") return false;
  const order = value as Partial<Order>;
  return (
    typeof order.id === "string" &&
    typeof order.placedAt === "string" &&
    Array.isArray(order.lines) &&
    typeof order.totals === "object" &&
    order.totals !== null &&
    typeof order.totals.total === "number"
  );
}

export const ordersStore = createPersistedStore<readonly Order[]>([], {
  key: "jango.orders.v1",
  parse: (raw) => (Array.isArray(raw) ? raw.filter(isOrder).slice(0, MAX_ORDERS) : []),
});

export function rememberOrder(order: Order) {
  ordersStore.setState((orders) => [order, ...orders.filter((existing) => existing.id !== order.id)].slice(0, MAX_ORDERS));
}
