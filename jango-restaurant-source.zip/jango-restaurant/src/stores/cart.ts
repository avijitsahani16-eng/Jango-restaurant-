import { getDish } from "@/data/dishes";
import {
  addLine,
  calculateTotals,
  findCoupon,
  MAX_QUANTITY,
  normalizeCouponCode,
  removeLine,
  sanitizeLines,
  setLineQuantity,
} from "@/lib/cart";
import { createPersistedStore } from "@/lib/store";
import type { CartState } from "@/types";

import { showToast } from "./toast";
import { ui } from "./ui";

const EMPTY: CartState = { lines: [], couponCode: null };

export const cartStore = createPersistedStore<CartState>(EMPTY, {
  key: "jango.cart.v1",
  parse(raw) {
    const value = (raw ?? {}) as Partial<CartState>;
    return {
      lines: sanitizeLines(value.lines),
      couponCode: typeof value.couponCode === "string" ? normalizeCouponCode(value.couponCode) || null : null,
    };
  },
});

/** Fired on every "add", so the header badge and the fly-to-cart layer can react. */
export const CART_ADD_EVENT = "jango:cart-add";

export interface CartAddDetail {
  dishId: string;
  /** Screen rectangle of the element the dish "flies" from. */
  from?: DOMRect;
  /** Already-loaded image URL to show while flying. */
  imageSrc?: string;
}

export interface AddOptions {
  quantity?: number;
  /** Element to animate from (usually the dish photo). */
  origin?: Element | null;
  /** Skip the toast, e.g. when the cart drawer is already open. */
  silent?: boolean;
}

export const cart = {
  add(dishId: string, { quantity = 1, origin, silent = false }: AddOptions = {}) {
    const dish = getDish(dishId);
    if (!dish) return;

    const before = cartStore.getState().lines.find((line) => line.dishId === dishId)?.quantity ?? 0;
    if (before >= MAX_QUANTITY) {
      showToast({ tone: "info", title: `That’s the limit — ${MAX_QUANTITY} per dish`, description: "Planning a party? Call us and we’ll sort it out." });
      return;
    }

    cartStore.setState((state) => ({ ...state, lines: addLine(state.lines, dishId, quantity) }));

    if (typeof window !== "undefined") {
      const image = origin instanceof HTMLImageElement ? origin : origin?.querySelector("img");
      const detail: CartAddDetail = {
        dishId,
        from: origin?.getBoundingClientRect(),
        imageSrc: image?.currentSrc || undefined,
      };
      window.dispatchEvent(new CustomEvent<CartAddDetail>(CART_ADD_EVENT, { detail }));
    }

    if (!silent) {
      showToast({
        title: "Added to your cart",
        description: dish.name,
        image: dish.image,
        action: { label: "View cart", onClick: () => ui.open("cart") },
      });
    }
  },

  setQuantity(dishId: string, quantity: number) {
    cartStore.setState((state) => ({ ...state, lines: setLineQuantity(state.lines, dishId, quantity) }));
  },

  remove(dishId: string) {
    cartStore.setState((state) => ({ ...state, lines: removeLine(state.lines, dishId) }));
  },

  clear() {
    cartStore.setState(EMPTY);
  },

  /** Returns a human-readable result so forms can show it inline. */
  applyCoupon(code: string): { ok: boolean; message: string } {
    const normalized = normalizeCouponCode(code);
    if (!normalized) return { ok: false, message: "Enter a coupon code." };

    const coupon = findCoupon(normalized);
    if (!coupon) return { ok: false, message: "That code isn’t valid." };

    const { lines } = cartStore.getState();
    const totals = calculateTotals(lines, { couponCode: normalized });
    if (totals.couponError) return { ok: false, message: totals.couponError };

    cartStore.setState((state) => ({ ...state, couponCode: normalized }));
    return { ok: true, message: `${coupon.code} applied — you save ₹${totals.discount}.` };
  },

  removeCoupon() {
    cartStore.setState((state) => ({ ...state, couponCode: null }));
  },
};
