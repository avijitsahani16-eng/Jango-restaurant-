import { createStore } from "@/lib/store";

/** Only one overlay can be open at a time — opening another replaces it. */
export type Overlay = "cart" | "search" | "account" | "nav" | "reservation" | "quick-view";

export interface UIState {
  overlay: Overlay | null;
  /** Dish shown in the quick view. */
  quickViewId: string | null;
}

export const uiStore = createStore<UIState>({ overlay: null, quickViewId: null });

export const ui = {
  open(overlay: Exclude<Overlay, "quick-view">) {
    uiStore.setState((state) => ({ ...state, overlay }));
  },
  openQuickView(dishId: string) {
    uiStore.setState({ overlay: "quick-view", quickViewId: dishId });
  },
  close() {
    uiStore.setState((state) => (state.overlay === null ? state : { ...state, overlay: null }));
  },
  toggle(overlay: Exclude<Overlay, "quick-view">) {
    uiStore.setState((state) => ({ ...state, overlay: state.overlay === overlay ? null : overlay }));
  },
};
