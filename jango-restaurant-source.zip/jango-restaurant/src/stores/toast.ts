import type { StaticImageData } from "next/image";

import { createStore } from "@/lib/store";

export type ToastTone = "success" | "info" | "error";

export interface Toast {
  id: number;
  title: string;
  description?: string;
  tone: ToastTone;
  image?: StaticImageData;
  action?: { label: string; onClick: () => void };
}

export const toastStore = createStore<readonly Toast[]>([]);

const DURATION = 3600;
const MAX_VISIBLE = 3;
let nextId = 1;

export function dismissToast(id: number) {
  toastStore.setState((toasts) => toasts.filter((toast) => toast.id !== id));
}

export function showToast(toast: Omit<Toast, "id" | "tone"> & { tone?: ToastTone }): number {
  const id = nextId++;
  toastStore.setState((toasts) => [...toasts.slice(-(MAX_VISIBLE - 1)), { tone: "success", ...toast, id }]);
  if (typeof window !== "undefined") {
    window.setTimeout(() => dismissToast(id), DURATION);
  }
  return id;
}
