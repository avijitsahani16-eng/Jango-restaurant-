"use client";

import { useCallback, useSyncExternalStore } from "react";

const subscribe = (notify: () => void) => {
  window.addEventListener("scroll", notify, { passive: true });
  window.addEventListener("resize", notify, { passive: true });
  return () => {
    window.removeEventListener("scroll", notify);
    window.removeEventListener("resize", notify);
  };
};

const getServerSnapshot = () => false;

/**
 * `true` once the page has scrolled past `threshold` pixels.
 * Backed by an external-store subscription, so components re-render only when
 * the boolean flips — not on every scroll frame.
 */
export function useScrolledPast(threshold: number): boolean {
  const getSnapshot = useCallback(() => window.scrollY > threshold, [threshold]);
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}
