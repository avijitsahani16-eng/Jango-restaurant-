"use client";

import { useMemo } from "react";

import { getDish } from "@/data/dishes";
import { calculateTotals } from "@/lib/cart";
import { cartStore } from "@/stores/cart";
import type { CartTotals, Dish, Fulfilment } from "@/types";

import { useStore } from "./use-store";

export interface DetailedLine {
  dish: Dish;
  quantity: number;
  lineTotal: number;
}

export interface CartView {
  lines: DetailedLine[];
  couponCode: string | null;
  totals: CartTotals;
  isEmpty: boolean;
}

/** The cart, joined with the menu and priced. Empty on the server and during hydration. */
export function useCart(fulfilment: Fulfilment = "delivery"): CartView {
  const state = useStore(cartStore);

  return useMemo(() => {
    const lines = state.lines.flatMap((line) => {
      const dish = getDish(line.dishId);
      return dish ? [{ dish, quantity: line.quantity, lineTotal: dish.price * line.quantity }] : [];
    });
    return {
      lines,
      couponCode: state.couponCode,
      totals: calculateTotals(state.lines, { couponCode: state.couponCode, fulfilment }),
      isEmpty: lines.length === 0,
    };
  }, [state, fulfilment]);
}

/** Just the number of items — cheap enough for the header badge. */
export function useCartCount(): number {
  return useStore(cartStore, (state) => state.lines.reduce((sum, line) => sum + line.quantity, 0));
}
