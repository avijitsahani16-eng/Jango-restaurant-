"use client";

import { useSyncExternalStore } from "react";

import type { Store } from "@/lib/store";

const identity = <T,>(value: T) => value;

/**
 * Subscribes a component to a store.
 *
 * The selector must return a referentially stable value for unchanged state
 * (a primitive, or an object that already lives in the store). Derive new
 * objects with `useMemo` in the component instead.
 */
export function useStore<T>(store: Store<T>): T;
export function useStore<T, S>(store: Store<T>, selector: (state: T) => S): S;
export function useStore<T, S>(store: Store<T>, selector: (state: T) => S = identity as (state: T) => S): S {
  return useSyncExternalStore(
    store.subscribe,
    () => selector(store.getState()),
    () => selector(store.getInitialState()),
  );
}

const noopSubscribe = () => () => {};

/** `false` on the server and during hydration, `true` afterwards. */
export function useHydrated(): boolean {
  return useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  );
}
