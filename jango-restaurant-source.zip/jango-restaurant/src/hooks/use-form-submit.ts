"use client";

import { useCallback, useRef, useState } from "react";

import { postJson } from "@/lib/api-client";

export type SubmitStatus = "idle" | "submitting" | "success" | "error";

export interface SubmitState<TData> {
  status: SubmitStatus;
  /** Server-side or network message. */
  message: string;
  /** Field-level errors (client or server). */
  errors: Record<string, string>;
  data: TData | null;
}

type Validation<TPayload> = { ok: true; data: TPayload } | { ok: false; errors: Record<string, string | undefined> };

function compact(errors: Record<string, string | undefined>): Record<string, string> {
  return Object.fromEntries(Object.entries(errors).filter((entry): entry is [string, string] => Boolean(entry[1])));
}

/**
 * Shared submit flow for every form on the site:
 * validate locally → POST as JSON → surface field errors or a success state.
 */
export function useFormSubmit<TPayload, TData = undefined>(endpoint: string) {
  const [state, setState] = useState<SubmitState<TData>>({ status: "idle", message: "", errors: {}, data: null });
  const busy = useRef(false);

  const submit = useCallback(
    async (validation: Validation<TPayload>, extra: Record<string, unknown> = {}): Promise<SubmitState<TData>> => {
      if (busy.current) return { status: "submitting", message: "", errors: {}, data: null };

      if (!validation.ok) {
        const next: SubmitState<TData> = { status: "error", message: "Please check the highlighted fields.", errors: compact(validation.errors), data: null };
        setState(next);
        return next;
      }

      busy.current = true;
      setState({ status: "submitting", message: "", errors: {}, data: null });

      const result = await postJson<TData>(endpoint, { ...validation.data, ...extra });
      busy.current = false;

      const next: SubmitState<TData> = result.ok
        ? { status: "success", message: result.message, errors: {}, data: result.data ?? null }
        : { status: "error", message: result.message, errors: result.errors ?? {}, data: null };
      setState(next);
      return next;
    },
    [endpoint],
  );

  const clearError = useCallback((field: string) => {
    setState((current) => {
      if (!current.errors[field]) return current;
      const errors = { ...current.errors };
      delete errors[field];
      return { ...current, errors, status: current.status === "error" && Object.keys(errors).length === 0 ? "idle" : current.status };
    });
  }, []);

  const reset = useCallback(() => setState({ status: "idle", message: "", errors: {}, data: null }), []);

  return { ...state, submit, clearError, reset };
}

/** Moves keyboard focus to the first invalid control inside a form. */
export function focusFirstError(form: HTMLFormElement | null) {
  requestAnimationFrame(() => {
    form?.querySelector<HTMLElement>("[aria-invalid='true']")?.focus();
  });
}
